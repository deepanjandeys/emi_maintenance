;
<?php $__env->startSection('page_title','Order'); ?>
<?php $__env->startSection('order_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_TYPE=session()->get('ADMIN_TYPE')); ?>

</span>

<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script> 
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<h2 class="title-1 m-b-10">Orders</h2>
<div class="row">
    <div class="col-3">
<a href='<?php echo e(url("$typeName/order/edit_order")); ?>' >
<button type="button" class="btn btn-success">Add Order</button>
</a>
    
    </div>
    <div class="col-2">
<a href='<?php echo e(url("$typeName/order/trash")); ?>' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()"><?php echo e($a_search_text); ?></a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style=<?php echo e($displaySearch); ?> >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Order Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="id" id="id" class="form-control" placeholder="Order Id" value="<?php echo e($id); ?>">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($product_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="product_ids" name="product_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Products)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $product_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                          <br>
                          <a href="javascript:void(0)" onclick="clear_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="Order Date from" value="<?php echo e($Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         Date to<br>
                         <a href="javascript:void(0)" onclick="clear_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="Order Date To" value="<?php echo e($Date_To); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="<?php echo e($cust_name); ?>">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="<?php echo e($cust_mobile); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        
                        <div class="col-lg-3">
                          Village
                          <?php if($ADMIN_TYPE !=4): ?>
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          <?php endif; ?>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($village_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="village_ids" name="village_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Villages)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $village_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>    
</div>
                  <div class="col-lg-3">
                          Sale agents
                          <?php if($ADMIN_TYPE==1): ?>
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                          <?php endif; ?>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($sale_agent_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="sale_agent_ids" name="sale_agent_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<option value="">(all) </option>
<?php $__currentLoopData = $SalesAgents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $sale_agent_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-6 text-right">
Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="<?php echo e($rows); ?>" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='<?php echo e(url("$typeName/orders")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Order Date</th>
                                                <th>Product</th>
                                                <th>Customer ID/Name</th>
                                                <th>Village</th>
                                                <th>Sale Agent Code/Name</th>
                                                <th>Sale Price</th>
                                                <th>Down Payment</th>
                                                <th>Advance Booking</th>
                                                <th>EMI</th>
                                                <th>EMI Mode</th>
                                                <th>EMI Period</th>
                                                <th>Status</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="d-none">
                                            <?php if(isset($list->bill_id)): ?>
                                                <?php echo e($btnClass="btn-primary"); ?>

                                                <?php echo e($actionBill="Edit "); ?>

                                            <?php else: ?>
                                                <?php echo e($btnClass="btn-warning"); ?>

                                                <?php echo e($actionBill="Generate "); ?>

                                            <?php endif; ?>
                                            </span>    
                                            <tr>
                                                <td>
                                                    <?php if($list->bill_id==''): ?>
                                                    <a href='<?php echo e(url("$typeName/order/edit_order")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($list->id); ?>

                                                 <a href='<?php echo e(url("$typeName/bill/edit_bill")); ?>/<?php echo e($list->bill_id??"0"); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" title="<?php echo e($actionBill); ?>" class="btn <?php echo e($btnClass); ?>">&nbsp;&nbsp;Bill&nbsp;&nbsp;</button>
                                                    </a> <?php echo e($actionBill); ?>

                                                </td>
                                                <td><?php echo e($list->order_date); ?></td>
                                                <td><?php echo e($list->getProduct[0]->name); ?></td>
                                                <td><?php echo e($list->customer_id); ?>/ <?php echo e($list->getCustomers[0]->name); ?> <?php echo e($list->getCustomers[0]->mobile); ?></td>
                                                <td><?php echo e($list->getCustomers[0]->getVillages[0]->name); ?>  <?php echo e($list->getCustomers[0]->address); ?></td>
                                                <td><?php echo e($list->getSalesAgent[0]->id); ?>/ <?php echo e($list->getSalesAgent[0]->name); ?></td>        
                                                <td><?php echo e($list->sale_price); ?></td>
                                                <td  style="text-align:right;font-weight: bold;"><?php echo e($list->down_payment); ?></td>
                                                <td style="text-align:right;font-weight: bold;"><?php echo e($list->booking_advance); ?></td>
                                                <td><?php echo e($list->EMI); ?></td>
                                                <td>                                        <?php $__currentLoopData = $calcmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($list->EMI_mode==$list1->id): ?>
                                                        <?php echo e($list1->name); ?>

                                                    <?php break; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                                <td><?php echo e($list->EMI_Period); ?></td>
                                                <td>
                                                    <?php if($list->status==1): ?>
                                                    <span class="text-primary"> Active</span>
                                                    <a href="<?php echo e(url('admin/order/status/0/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-warning">Deactivate</button>
                                                    </a>
                                                    <?php elseif($list->status==0): ?>
                                                    <span class="text-danger">Inactive</span>
                                                    <a href="<?php echo e(url('admin/order/status/1/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-primary">Activate</button>
                                                    </a>
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                <td>
                                                    <?php if($list->bill_id==''): ?>
                                                    <a href='<?php echo e(url("$typeName/order/delete")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                              <td colspan="9" style="text-align:right;color: red;font-weight: bold;">
                                                  Total Advance Booking
                                              </td>
                                              <td style="text-align:right;color: blue;font-weight: bold;"><?php echo e($sumAdvBooking); ?></td>
                                              <td colspan="5"></td>
                                          </tr>  
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($orders->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


<?php if($Date_From==''): ?>
    $('#Date_From').val('');
<?php endif; ?>
<?php if($Date_To==''): ?>
    $('#Date_To').val('');
<?php endif; ?>

});


function clear_date_from()
    {
    $('#Date_From').val('');
    }
function clear_date_to()
    {
    $('#Date_To').val('');
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/order.blade.php ENDPATH**/ ?>