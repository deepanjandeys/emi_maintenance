;
<?php $__env->startSection('page_title','Customer'); ?>
<?php $__env->startSection('customer_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"><?php echo e($typeName=session()->get('typeName')); ?></span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_id').attr('multiple','multiple');
        $('#spnMessage').show();
    }

</script> 
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  <?php echo e(session('error')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Customer</h2>
<div class="row">
    <div class="col-3">
<a href='<?php echo e(url("$typeName/customer/edit_customer")); ?>' >
<button type="button" class="btn btn-success">Add Customer</button>
</a>
    
    </div>
    <div class="col-2">
<a href='<?php echo e(url("$typeName/customer/trash")); ?>' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()"><?php echo e($a_search_text); ?></a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style=<?php echo e($displaySearch); ?> >
                    <fieldset class="p-2 rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="name" id="name" class="form-control" value="<?php echo e($name); ?>">
                        </div>
                        <div class="col-lg-3">
                          Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="mobile" id="mobile" value="<?php echo e($mobile); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        
                        <div class="col-lg-3">
                          Village
                          <a href="javascript:void(0)" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($village_id)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="village_id" name="village_id[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Villages)>1): ?>
<option value="">select </option>
<?php endif; ?>
<?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $village_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>    
</div>
<div class="col-lg-3">
    Customer  id
</div>
<div class="col-lg-3 col-sm-9 col-xs-9">
<input type="text" name="id" id="id" class="form-control" value="<?php echo e($id); ?>">
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="<?php echo e($rows); ?>" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='<?php echo e(url("$typeName/customer")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
 <div class="row m-t-30">
    <div class="col-md-12">
    <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
<table class="table table-borderless table-data3">
<thead>
<tr>
<th rowspan="2">Action</th> 
<th rowspan="2">ID</th>
<th rowspan="2">Name</th>
<th rowspan="2">Mobile</th>
<th rowspan="2">PIN</th>
<th rowspan="2">Address</th>
<th rowspan="2">Village</th>
<th colspan="2" class="text-center">ID Proof</th>
<th colspan="2" class="text-center">address proof</th>
<th rowspan="2">Approved</th>
<th rowspan="2">Status</th>
</tr>
<tr>
<th>type</th>
<th>Image</th>
<th>Type</th>
<th>Image</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td>
<a href='<?php echo e(url("$typeName/customer/edit_customer/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
</a>          
<a href='<?php echo e(url("$typeName/customer/delete/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-danger">Trash</button>
</a>
</td>
<td><?php echo e($list->id); ?></td>
<td><?php echo e($list->name); ?></td>
<td><?php echo e($list->mobile); ?></td>
<td><?php echo e($list->pin); ?></td>
<td><?php echo e($list->address); ?></td>
<td>                                      
    <?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($list->village_id==$list1->id): ?>
<?php echo e($list1->name); ?>

<?php break; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td>
<?php $__currentLoopData = $id_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($list->IdProofType==$list1->id): ?>
<?php echo e($list1->name); ?>

<?php break; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td>
<img src="<?php echo e(asset('/storage/media').'/'.$list->IdProofImage); ?>" alt="<?php echo e(asset('/storage/media').'/'.$list->IdProofImage); ?>" style="width: 100px;height: 100px;"/>
</td>
<td>
<?php $__currentLoopData = $address_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($list->AddressProofType == $list1->id): ?>
<?php echo e($list1->AddressProofType); ?>

<?php break; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td>
<img src="<?php echo e(asset('/storage/media').'/'.$list->AddressProofImage); ?>" alt="<?php echo e(asset('/storage/media').$list->AddressProofImage); ?>" style="width: 100px;height: 100px;"/>
</td>
<td>
<?php if($list->isApproved==1): ?>
<span class="text-primary"> Approved</span>
<?php if(session()->get('ADMIN_TYPE')=='1'): ?>
<a href="<?php echo e(url('admin/customer/approve/0/')); ?>/<?php echo e($list->id); ?>">
<button type="button" class="btn btn-warning">Disapprove</button>
</a>
<?php endif; ?>
<?php elseif($list->isApproved==0): ?>
<span class="text-danger">Disapproved</span>
<?php if(session()->get('ADMIN_TYPE')=='1'): ?>
<a href="<?php echo e(url('admin/customer/approve/1/')); ?>/<?php echo e($list->id); ?>">
<button type="button" class="btn btn-primary">Approve</button>
</a>
<?php endif; ?>
<?php endif; ?>
</td>
<td>
<?php if($list->status==1): ?>
<span class="text-primary"> Active</span>
<?php if(session()->get('ADMIN_TYPE')=='1'): ?>
<a href="<?php echo e(url('admin/customer/status/0/')); ?>/<?php echo e($list->id); ?>">
<button type="button" class="btn btn-warning">Deactivate</button>
</a>
<?php endif; ?>
<?php elseif($list->status==0): ?>
<span class="text-danger">Inactive</span>
<?php if(session()->get('ADMIN_TYPE')=='1'): ?>
<a href="<?php echo e(url('admin/customer/status/1/')); ?>/<?php echo e($list->id); ?>">
<button type="button" class="btn btn-primary">Activate</button>
</a>
<?php endif; ?>
<?php endif; ?>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<?php echo e($customers->links()); ?>

<!-- END DATA TABLE-->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/customer.blade.php ENDPATH**/ ?>