<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    <!-- Title Page-->
    <title>Login</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin_assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo e(asset('admin_assets/css/theme.css')); ?>" rel="stylesheet" media="all">
<script type="text/javascript">
function forget_password()
  {
//debugger;
    var type=$('#type').val();

    if(type=='1')
        window.location='/admin/forget_password';
    else if(type=='3')    
        window.location='/sale_agent/forget_password';
    else if(type=='4')
        window.location='/village_agent/forget_password';
  }
</script>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">

                            <a href="/">
                                <?php echo e(Config::get('constants.SITE_NAME')); ?>

                                <img class="d-none" src="<?php echo e(asset('admin_assets/images/icon/logo.png')); ?>" alt="CoolAdmin">
                            </a>
                        </div>
                        <div class="login-form">
                            <form action="<?php echo e(route('admin.auth')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label>User Id/Mobile No.</label>
                                    <input class="au-input au-input--full" type="text" name="name" placeholder="User Id/ Mobile No." value="<?php echo e(old('name')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password" required>
                                </div>
                                <input type="hidden" id="type" name="type" value="<?php echo e($type); ?>">
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                      <a href="javascript:void(0)" onclick="forget_password()">Forget Password?</a>         
                               
                            <?php if(session()->has('error')): ?>
<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Message</span>
  <?php echo e(session('error')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
                            </form>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>
    <!-- Main JS-->
    <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>

</body>

</html>
<!-- end document--><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/login.blade.php ENDPATH**/ ?>