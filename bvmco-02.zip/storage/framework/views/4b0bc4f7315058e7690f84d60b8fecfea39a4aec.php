;
<?php $__env->startSection('page_title','EMI Receive'); ?>
<?php $__env->startSection('emi_receive','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_TYPE=session()->get('ADMIN_TYPE')); ?>

</span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
var totalAmount=0;
var str='';
function checkAll()
{
    //debugger;
    if($('#chkAll').prop('checked'))
    {
        $(".chk").prop('checked', true);      
    }
    else
    {
        $(".chk").prop('checked', false);      
    }

    var chks = $('.chk');
    var value=0;
    totalAmount =0;

     $.each(chks, function() {
        var $this = $(this);
    // check if the checkbox is checked
    if($this.is(":checked")) {
    // put the checked animal value to the html list
        value=parseFloat($('#spnPaidAmt'+$this.val()).html());
                    //str += ""+$this.val()+" ";
        totalAmount +=value;
                }
            }); 
   $('#tdTotalAmount').html(totalAmount.toFixed(2));
}

function chk_click(v)
{
    //console.log(v);
    var value=parseFloat($('#spnPaidAmt'+v).html());

    if($('#chk'+v).prop('checked'))
    {
        //$(".chk").prop('checked', true);      
        totalAmount +=value;
    }
    else
    {
        //$(".chk").prop('checked', false);      
        totalAmount -=value;
    }
    //console.log('totalAmount '+totalAmount);
    $('#tdTotalAmount').html(totalAmount.toFixed(2));
}    
</script> 
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      

<h2 class="title-1 m-b-10">EMI Receive by Sale Agent</h2>
<div class="row">
    <div class="col-3 d-none">
<a href='<?php echo e(url("$typeName/emis/edit_collection")); ?>' >
<button type="button" class="btn btn-success">Collect EMI</button>
</a>
    
    </div>
    <div class="col-2 d-none">
<a href='<?php echo e(url("$typeName/order/trash")); ?>' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()"><?php echo e($a_search_text); ?></a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style=<?php echo e($displaySearch); ?> >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Bill Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="bill_id" id="bill_id" class="form-control" placeholder="Bill Id" value="<?php echo e($bill_id); ?>">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($product_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="product_ids" name="product_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Products)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $product_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                        <a href="javascript:void(0)" onclick="clear_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="EMI Collect Date from" value="<?php echo e($Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         Date to
                         <a href="javascript:void(0)" onclick="clear_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="EMI Collect Date To" value="<?php echo e($Date_To); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="<?php echo e($cust_name); ?>">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="<?php echo e($cust_mobile); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                    
                        <div class="col-lg-3">
                          Village
                          <?php if($ADMIN_TYPE !=4): ?>
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          <?php endif; ?>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($village_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="village_ids" name="village_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Villages)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $village_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>    
</div>
<div class="col-lg-3">

                      Sale agents
                      <?php if($ADMIN_TYPE !=4): ?>
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                    <?php endif; ?>
</div>
<div class="col-lg-3">

<div class="form-group">
<?php if(count($sale_agent_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>
<select id="sale_agent_ids" name="sale_agent_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($SalesAgents)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $SalesAgents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $sale_agent_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="<?php echo e($rows); ?>" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='<?php echo e(url("$typeName/emis")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
<form action='<?php echo e(route("$typeName.manage_emi_receive")); ?>' method="post">
<?php echo csrf_field(); ?>                            
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th><input type="checkbox" id="chkAll" onclick="checkAll()"><label for="chk">check All</label></th>
                                            <th>Paid Amount</th>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Due Amount</th>
                                            </tr>
            
                                        </thead>
                                        <tbody>
                                <?php $__currentLoopData = $emi_collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                    <td>
                                        <input type="checkbox" id="chk<?php echo e($list->id); ?>" name="chk<?php echo e($list->id); ?>" value="<?php echo e($list->id); ?>" onclick="chk_click(this.value)" class="chk">
                                    </td>
                                    <td style="text-align:right;"><span id="spnPaidAmt<?php echo e($list->id); ?>"><?php echo e($list->paid_amt); ?></span></td>
                                    <td><?php echo e($list->bill_id); ?>

                                    </td>
                                    <td><?php echo e($list->emi_date); ?></td>
                    <td>                                       <?php echo e($list->getBills[0]->getCustomers[0]->name); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->getVillages[0]->name??''); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->mobile??''); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_Loan); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_interest); ?></td>
                    <td style="text-align:right;"><?php echo e($list->emi_amount); ?></td>
                    <td style="text-align:right;"><?php echo e($list->fine_amount); ?></td>
                    
                    <td style="text-align:right;"><?php echo e($list->due_amt); ?></td>
                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(count($emi_collections)): ?>                                        
            <tr>
                <td>Total</td>
                <td id="tdTotalAmount" style="text-align:right;">
                </td>                
                <td colspan="2">
<input id="receive_time" name="receive_time" type="text" class="form-control text-right" aria-required="true" aria-invalid="false" required>
                </td>
                <td colspan="3">
                    <input type="submit" name="submit" class="btn btn-success">            
                </td>
                <td colspan="5"></td>
            </tr>
<?php endif; ?>
                                        </tbody>

                                    </table>
        
                                </div>
                                <?php echo e($emi_collections->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#receive_time').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

<?php if($Date_From==''): ?>
    $('#Date_From').val('');
<?php endif; ?>
<?php if($Date_To==''): ?>
    $('#Date_To').val('');
<?php endif; ?>
});

function clear_date_from()
    {
    $('#Date_From').val('');
    }
function clear_date_to()
    {
    $('#Date_To').val('');
    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/emi_recieve_bySA.blade.php ENDPATH**/ ?>