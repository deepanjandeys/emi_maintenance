<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Micr finance bvmco.in">
    <meta name="author" content="Deepanjan Dey">
    <meta name="keywords" content="Short term loan">

    <!-- Title Page-->
    <title><?php echo $__env->yieldContent('page_title'); ?></title>

    <link rel="icon" href="<?php echo e(asset('admin_assets/images/favicon_io/')); ?>/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="<?php echo e(asset('admin_assets/images/favicon_io/')); ?>/apple-touch-icon.png">


    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('admin_assets/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">
    
    <link href="<?php echo e(asset('admin_assets/css/theme.css')); ?>?v=1" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('admin_assets/css/style.css')); ?>" rel="stylesheet" media="all">

<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>


<!--
<link href="<?php echo e(asset('admin_assets/dataList/dataList.css')); ?>" rel="stylesheet" media="all">
<script src="<?php echo e(asset('admin_assets/dataList/dataList.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/dataList/dataList-stable.js')); ?>"></script>
-->
<script type="text/javascript">

    function docReady(fn) {
    // see if DOM is already available
    if (document.readyState === "complete" || document.readyState === "interactive") {
        // call on next available tick
        setTimeout(fn, 1);
    } else {
        document.addEventListener("DOMContentLoaded", fn);
    }
}    
</script>
</head>

<body class="animsition">
    <span class="d-none">
<?php echo e($id=session()->get('ADMIN_ID')); ?>

<?php echo e($image=session()->get('ADMIN_IMAGE')); ?>

<?php echo e($name=session()->get('ADMIN_NAME')); ?>

<?php echo e($refer_name=session()->get('ADMIN_REFER_NAME')); ?>

<?php echo e($email=session()->get('ADMIN_EMAIL')); ?>

<?php echo e($type=session()->get('ADMIN_TYPE')); ?>

<?php if($image==''): ?>
<?php echo e($image="NoImage.png"); ?>

<?php endif; ?>

<?php echo e($typeName=session()->get('typeName')); ?>

<?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>

    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="<?php echo e(asset('admin_assets/images/icon/logo.png')); ?>" alt="BVMCO Admin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner">
<img src="<?php echo e(asset('admin_assets/images/icon/nav_bar.png')); ?>" alt="BVMCO Admin" />
                                </span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <?php if($type=='1'): ?>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                    <li >
                    <a href="<?php echo e(url('admin/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            
                        </li>
                        <li >
                            <a href="<?php echo e(url('admin/product_group')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Product Group</a>
                            
                        </li>
                        <li >
                            <a href="<?php echo e(url('admin/product_sub_group')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Product Sub Group</a>
                        </li>

                        <li class="d-none">
                            <a href="<?php echo e(url('admin/branch')); ?>">
                                <i class="fa-duotone fa-house-laptop"></i>Branch</a>
                            
                        </li>

                         <li>
                            <a href="<?php echo e(url('admin/sale_agent')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Sales Agent</a>
                            
                        </li>

                        <li>
                            <a href="<?php echo e(url('admin/product')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Product</a>
                            
                        </li>
                        <li class="d-none">
                            <a href="<?php echo e(url('admin/branchStock')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Stock</a>
                            
                        </li>

                         <li>
                            <a href="<?php echo e(url('admin/customer')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Customer</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/idProofType')); ?>">
                                <i class="fas fa-tachometer-alt"></i>ID Proof Type</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/addressProofType')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Address Proof Type</a>
                            
                        </li>
                        
                        <li>
                            <a href="<?php echo e(url('admin/village')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Village</a>
                            
                        </li>
                        
                        <li>
                            <a href="<?php echo e(url('admin/orders')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Orders</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/bills')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Bills</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/emis')); ?>">
                                <i class="fas fa-tachometer-alt"></i>EMIs</a>
                            
                        </li>                  
                    </ul>
                </div>
            </nav>
            <?php elseif($type==3): ?>
            
                        <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                    
                    <li>
                            <a href="<?php echo e(url('sale_agent/product_list')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Place order</a>
                            
                        </li>
                        <li>
                    <a href="<?php echo e(url('sale_agent/village')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Village</a>
                        </li>           
                         <li>
                        <a href="<?php echo e(url('sale_agent/customer')); ?>">
                <i class="fas fa-tachometer-alt"></i>Customer</a>
                            
                        </li>
                       
                        <li>
                            <a href="<?php echo e(url('sale_agent/orders')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Orders</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('sale_agent/bills')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Bills</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('sale_agent/emis/emi_collection')); ?>">
                                <i class="fas fa-tachometer-alt"></i>EMI Collection</a>
                            
                        </li>
                        <li>
                            <a href="<?php echo e(url('sale_agent/emis')); ?>">
                                <i class="fas fa-tachometer-alt"></i>EMI List</a>
                            
                        </li> 
                        <li>
                            <a href="<?php echo e(url('sale_agent/emis/receive')); ?>">
                                <i class="fas fa-tachometer-alt"></i>EMI receive</a>
                            
                        </li>                 
                    </ul>
                </div>
            </nav>
            <?php elseif($type==4): ?>
            
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                  <!--     <li>
                            <a href="<?php echo e(url('village_agent/product_list')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Place order</a>
                            
                        </li>
                         <li>
                            <a href="<?php echo e(url('village_agent/customer')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Customer</a>
                            
                        </li>
                       
                        <li>
                    <a href="<?php echo e(url('village_agent/orders')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Orders</a>      
                        </li>
                        <li>
                    <a href="<?php echo e(url('village_agent/bills')); ?>">
                    <i class="fas fa-tachometer-alt"></i>Bills</a>
                        </li>
                      -->
                    <li>
                        <a href="<?php echo e(url('village_agent/emis/emi_collection')); ?>">
                        <i class="fas fa-tachometer-alt"></i>EMI Collection </a>
                    </li>    
                    <li>
                        <a href="<?php echo e(url('village_agent/emis')); ?>">
                        <i class="fas fa-tachometer-alt"></i>EMI  list</a>
                    </li>             
                    <li>
                        <a href="<?php echo e(url('village_agent/emis/collected')); ?>">
                        <i class="fas fa-tachometer-alt"></i>EMI Collected list</a>
                    </li>                         
                    </ul>
                </div>
            </nav>
            <?php endif; ?>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="<?php echo e(asset('admin_assets/images/icon/logo.png')); ?>" alt="XCL Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <?php if($type=='1'): ?>
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="<?php echo $__env->yieldContent('dashboard_select'); ?>">
                            <a href="<?php echo e(url('admin/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

                        <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_master">
                                <i class="fas fa-tachometer-alt"></i>Master</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <li class="<?php echo $__env->yieldContent('ProductGroup_select'); ?>">
                            <a href="<?php echo e(url('admin/product_group')); ?>">
                                <i class="fas fa-list"></i>Product Group</a>
                        </li>

                        <li class="<?php echo $__env->yieldContent('ProductSubGroup_select'); ?>">
                            <a href="<?php echo e(url('admin/product_sub_group')); ?>">
                                <i class="fas fa-list"></i>Sub Group</a>
                        </li>


                        <li class="<?php echo $__env->yieldContent('product_select'); ?>">
                            <a href="<?php echo e(url('admin/product')); ?>">
                                <i class="fa fa-television" aria-hidden="true"></i>Product</a>
                        </li>
                        
                        <li class="<?php echo $__env->yieldContent('Branch_select'); ?> d-none">
                            <a href="<?php echo e(url('admin/branch')); ?>">
                               <i class="fas fa-home"></i>Branch</a>
                        </li>

                        <li class="<?php echo $__env->yieldContent('sale_agent_select'); ?>">
                            <a href="<?php echo e(url('admin/sale_agent')); ?>">
                                <i class='fas fa-clipboard-check'></i>Sales Agent</a>
                        </li>
                                               
                        <li class="<?php echo $__env->yieldContent('customer_select'); ?>">
                            <a href="<?php echo e(url('admin/customer')); ?>">
                            <i class="fas fa-user"></i>Customer</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('IdProofType_select'); ?>">
                            <a href="<?php echo e(url('admin/idProofType')); ?>">
                            <i class="fas fa-user"></i>ID Proofs</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('AddressProofType_select'); ?>">
                            <a href="<?php echo e(url('admin/addressProofType')); ?>">
                            <i class="fas fa-user"></i>Address Proofs</a>
                        </li>

                        <li class="<?php echo $__env->yieldContent('village_select'); ?>">
                            <a href="<?php echo e(url('admin/village')); ?>">
                            <i class="fas fa-map-marker"></i>Village</a>
                        </li>

                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_transaction">
                                <i class="fas fa-tachometer-alt"></i>Transactions</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <li class="<?php echo $__env->yieldContent('BranchStock_select'); ?>">
                            <a href="<?php echo e(url('admin/branchStock')); ?>">
                                <i class="fa fa-television" aria-hidden="true"></i>Stock</a>
                        </li>
                        
                        <li class="<?php echo $__env->yieldContent('order_select'); ?>">
                            <a href="<?php echo e(url('admin/orders')); ?>">
                            <i class="fas fa-address-card"></i>Orders</a>
                        </li>
                        
                        <li class="<?php echo $__env->yieldContent('bill_select'); ?>">
                            <a href="<?php echo e(url('admin/bills')); ?>">
                            <i class="fas fa-address-card"></i>Bills</a>
                        </li>
                        </ul>
                    </li>
                    <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_report">
                                <i class="fas fa-tachometer-alt"></i>Reports</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                        <li class="<?php echo $__env->yieldContent('emi_list'); ?>">
                            <a href="<?php echo e(url('admin/emis')); ?>">
                            <i class="fas fa-address-card"></i>EMI list</a>
                        </li>
                    </ul>
                </li>
                    </ul>
                </nav>
                <?php elseif($type=='3'): ?>
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="<?php echo $__env->yieldContent('dashboard_select'); ?>">
                            <a href="<?php echo e(url('sale_agent/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>

                        <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_master">
                                <i class="fas fa-tachometer-alt"></i>Master</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                       <li class="<?php echo $__env->yieldContent('village_select'); ?>">
                            <a href="<?php echo e(url('sale_agent/village')); ?>">
                            <i class="fas fa-map-marker"></i>Village</a>
                        </li>    
                    
                        <li class="<?php echo $__env->yieldContent('customer_select'); ?>">
                        <a href="<?php echo e(url('sale_agent/customer')); ?>">
                            <i class="fas fa-user"></i>Customer</a>
                        </li>
                        
                            </ul>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_transaction">
                                <i class="fas fa-tachometer-alt"></i>Transactions</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                        <li class="<?php echo $__env->yieldContent('product_select'); ?>">
                            <a href="<?php echo e(url('sale_agent/product_list')); ?>">
                                <i class="fa fa-television" aria-hidden="true"></i>Place order</a>
                        </li>
                       
                        <li class="<?php echo $__env->yieldContent('order_select'); ?>">
                            <a href="<?php echo e(url('sale_agent/orders')); ?>">
                            <i class="fas fa-address-card"></i>Orders</a>
                        </li>
                        
                        <li class="<?php echo $__env->yieldContent('bill_select'); ?>">
                            <a href="<?php echo e(url('sale_agent/bills')); ?>">
                            <i class="fas fa-address-card"></i>Bills</a>
                        </li>
                
                        <li class="<?php echo $__env->yieldContent('emi_collect'); ?>">
                            <a href="<?php echo e(url('sale_agent/emis/emi_collection')); ?>">
                            <i class="fas fa-address-card"></i>EMI Collection</a>
                        </li>
                        <li class="<?php echo $__env->yieldContent('emi_receive'); ?>">
                            <a href="<?php echo e(url('sale_agent/emis/receive')); ?>">
                            <i class="fas fa-address-card"></i>EMI Recieve</a>
                        </li>
                        
                        </ul>
                    </li>
                    <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_report">
                                <i class="fas fa-tachometer-alt"></i>Reports</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                        <li class="<?php echo $__env->yieldContent('emi_list'); ?>">
                            <a href="<?php echo e(url('sale_agent/emis')); ?>">
                            <i class="fas fa-address-card"></i>EMI list</a>
                        </li>
                    </ul>
                </li>
                </ul>
                </nav>
                <?php elseif($type=='4'): ?>
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="<?php echo $__env->yieldContent('dashboard_select'); ?>">
                            <a href="<?php echo e(url('village_agent/dashboard')); ?>">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_transaction">
                                <i class="fas fa-tachometer-alt"></i>Transactions</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">       
                        <li class="<?php echo $__env->yieldContent('emi_select'); ?>">
                            <a href="<?php echo e(url('village_agent/emis/emi_collection')); ?>">
                            <i class="fas fa-address-card"></i>EMI Collection</a>
                        </li>                        
                        </ul>
                    </li>
                    <li class="has-sub">
                            <a class="js-arrow" href="javascript:void(0)" id="a_report">
                                <i class="fas fa-tachometer-alt"></i>Reports</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                        <li class="<?php echo $__env->yieldContent('emi_list'); ?>">
                            <a href="<?php echo e(url('village_agent/emis')); ?>">
                            <i class="fas fa-address-card"></i>EMI list</a>
                        </li>
                    </ul>
                </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header d-none d-lg-block" action="" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button w-100" >

                            </div>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <!--
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity">2</span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                <p>You have 2 news records need to approve</p>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Sale agent " />
                                                </div>
                                                <div class="content">
                                                    <h6>Sale agent 1 create an account</h6>
                                                    <p>Approve this</p>
                                                    <span class="time">3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Diane Myers" />
                                                </div>
                                                <div class="content">
                                                    <h6>Sale agent 1 </h6>
                                                    <p>Make sale to Customer 1</p>
                                                    <span class="time">Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="mess__footer">
                                                <a href="#">View all messages</a>
                                            </div>
                                        </div>
                                    </div>
                                    -->
                                    <!--
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-email"></i>
                                        <span class="quantity">1</span>
                                        <div class="email-dropdown js-dropdown">
                                            <div class="email__title">
                                                <p>You have 3 New Emails</p>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, 3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="<?php echo e(asset('/storage/media').'/'.$image); ?>" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, April 12,,2018</span>
                                                </div>
                                            </div>
                                            <div class="email__footer">
                                                <a href="#">See all emails</a>
                                            </div>
                                        </div>
                                    </div>
                                -->
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-notifications"></i>
                                        <span class="quantity">0</span>
                                        <div class="notifi-dropdown js-dropdown">
                                            <div class="notifi__title">
                                                <p>You have 0 Notifications</p>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c1 img-cir img-40">
                                                    <i class="zmdi zmdi-email-open"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a email notification</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c2 img-cir img-40">
                                                    <i class="zmdi zmdi-account-box"></i>
                                                </div>
                                                <div class="content">
                                                    <p>Your account has been blocked</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c3 img-cir img-40">
                                                    <i class="zmdi zmdi-file-text"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a new file</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__footer">
                                                <a href="#">All notifications</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="<?php echo e(asset('admin_assets/images/icon/avatar-01.jpg')); ?>" alt="<?php echo e($typeName); ?>" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#"><?php echo e($typeName); ?></a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="<?php echo e(asset('admin_assets/images/icon/avatar-01.jpg')); ?>" alt="Admin" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#"><?php echo e($refer_name); ?></a>
                                                    </h5>
                                                    <span class="mobile"><?php echo e($name); ?></span>
                                                    <span class="email"><?php echo e($email); ?></span>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__body">
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-account"></i>Account</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="#">
                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                </div>
                                                <div class="account-dropdown__item">
                                                    <a href="/<?php echo e($typeName); ?>/changePassword/<?php echo e($id); ?>">
                                                        <i class="zmdi zmdi-money-box"></i>Change Password</a>
                                                </div>
                                            </div>
                                            <div class="account-dropdown__footer">
                                                <a href='<?php echo e(url("$typeName/logout")); ?>'>
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->
           <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <?php $__env->startSection('container'); ?>
                        <?php echo $__env->yieldSection(); ?>
                   
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/vendor/wow/wow.min.js')); ?>"></script>
    <!-- Main JS-->
    <script src="<?php echo e(asset('admin_assets/js/main.js')); ?>"></script>
    
<script type="text/javascript">
    var mt='<?php echo $__env->yieldContent('master_tran'); ?>';
    $("#a_"+mt)[0].click();
    //$('#a_transaction')[0].click();

    function show_hide_search()
    {
        if($('#a_search').html()=='Show Search')
        {
            $('#divSearch').show();
            $('#a_search').html('Hide Search');
        }
        else
        {
            $('#divSearch').hide();
            $('#a_search').html('Show Search');
        }
    }

</script>
<link href="<?php echo e(asset('admin_assets/plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
<!--
<link rel="stylesheet" href="http://statusdeal.in/admin_assets/plugins/daterangepicker/daterangepicker.css">
-->
<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

</body>

</html>
<!-- end document-->
<?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/layout.blade.php ENDPATH**/ ?>