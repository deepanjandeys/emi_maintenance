    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Paid Amount</th>
                                            <th>Due Amount</th>
                                            <th>Due Date</th>
                                            <th>Collect Date</th>
                                            <th>Receive Date</th>
                                                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $emis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                               <td><?php echo e($list->bill_id); ?>

                                    </td>
                                    <td><?php echo e($list->emi_date); ?></td>
                    <td>                                       <?php echo e($list->getBills[0]->getCustomers[0]->name); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->getVillages[0]->name??''); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->mobile??''); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_Loan); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_interest); ?></td>
                    <td style="text-align:right;"><?php echo e($list->emi_amount); ?></td>
                    <td style="text-align:right;"><?php echo e($list->fine_amount); ?></td>
                    <td style="text-align:right;"><?php echo e($list->paid_amt); ?></td>
                    <td style="text-align:right;"><?php echo e($list->due_amt); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($list->emi_date)->format('d/m/Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($list->collect_time)->format('d/m/Y')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($list->receive_time)->format('d/m/Y')); ?></td>
                                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/emi-export.blade.php ENDPATH**/ ?>