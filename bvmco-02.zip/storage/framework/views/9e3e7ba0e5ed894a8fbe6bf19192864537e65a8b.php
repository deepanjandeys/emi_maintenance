;
<?php $__env->startSection('page_title','Edit Village'); ?>
<?php $__env->startSection('village_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none">
<?php if($id>0): ?>
    <?php echo e($image_required=""); ?>

    <?php echo e($password_class="d-none"); ?>

<?php else: ?>
    <?php echo e($image_required="required"); ?>

    <?php echo e($password_class=""); ?>

<?php endif; ?>
<?php echo e(@$typeName=session()->get('typeName')); ?>    
</span>
<script type="text/javascript">
function getCheckMobileUnique(value) {
   $.ajax({
    type: "POST",
    url: '/getCheckMobileUnique',
    data: { mobile: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html(obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

  function setDefaultPasswordVA(id) {
    if (confirm("do You wabt to reset password to default password !") == false) 
    { 
  return;
    } 
   $.ajax({
    type: "POST",
    url: '/setDefaultPasswordVA',
    data: { id: id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      

<h2 class="title-1 m-b-10">Edit Village</h2>
<a href='<?php echo e(url("$typeName/village")); ?>' >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action='<?php echo e(route("$typeName.manage_village_process")); ?>' method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-6">
    <div class="form-group">
<label for="Village_name" class="control-label mb-1">Village Name</label>
<input id="Village_name" name="name" type="text" value="<?php echo e(old('name', $name)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="pin" class="control-label mb-1">pin</label>
<input id="pin" name="pin" type="text" value="<?php echo e(old('pin', $pin)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="district" class="control-label mb-1">District</label>
<input id="district" name="district" type="text" value="<?php echo e(old('district', $district)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['district'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="sub_division" class="control-label mb-1">sub Division</label>
<input id="sub_division" name="sub_division" type="text" value="<?php echo e(old('sub_division', $sub_division)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['sub_division'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>        
<span class="d-none"><?php echo e($status=old('status', $status)); ?></span>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

</div>



<div class="col-6">
<div class="form-group">
<label for="agent_name" class="control-label mb-1">Village Agent Name</label>
<input id="agent_name" name="agent_name" type="text" value="<?php echo e(old('agent_name', $agent_name)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['agent_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">Address</label>
<input id="address" name="address" type="text" value="<?php echo e(old('address', $address)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile</label>
<input id="mobile" name="mobile" type="text" value="<?php echo e(old('mobile', $mobile)); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="getCheckMobileUnique(this.value)" required>
<span id="spnIsMobileNoUsedEarlier" class="text-danger font-weight-bold"style="display:none;"></span>
<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="email" class="control-label mb-1">email (Optional)</label>
<input id="email" name="email" type="text" value="<?php echo e(old('email', $email)); ?>" class="form-control" aria-required="true" aria-invalid="false" >
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<?php if($id==0): ?>
<div class="form-group <?php echo e($password_class); ?>">
<label for="password" class="control-label mb-1">Password</label>
<input id="password" name="password" type="text" value="<?php echo e($password); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php else: ?>
<a href="javascript:void(0)" 
  onclick="setDefaultPasswordVA(<?php echo e($agent_id); ?>)">Reset Password</a>
<div id="divPwd<?php echo e($agent_id); ?>"></div>
<?php endif; ?>

<span class="d-none"><?php echo e($IdProofType=old('IdProofType', $IdProofType)); ?></span>
<div class="form-group">
<label for="IdProofType" class="control-label mb-1">id proof type </label>
<select id="IdProofType" name="IdProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
<?php $__currentLoopData = $id_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($IdProofType==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['IdProofType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="IdProofImage" class="control-label mb-1">Id Proof Image</label>
<br>
<img for="IdProofImage" id="IdProofImagePreview" src="<?php echo e($IDProofImagePath); ?>" alt="ID Proof Image">
<input id="IdProofImage" name="IdProofImage" type="file" class="form-control" aria-required="true"  onchange="readURLidProof(this)" aria-invalid="false"  accept="image/*" <?php echo e($image_required); ?>>
<input type="hidden" name="hdIdProofImage" value="<?php echo e($IdProofImage); ?>">
<?php $__errorArgs = ['IdProofImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<span class="d-none"><?php echo e($AddressProofType=old('AddressProofType', $AddressProofType)); ?></span>
<div class="form-group">
<label for="AddressProofType" class="control-label mb-1">Address proof type </label>
<select id="AddressProofType" name="AddressProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
<?php $__currentLoopData = $address_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($AddressProofType==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->AddressProofType); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->AddressProofType); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['AddressProofType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="AddressProofImage" class="control-label mb-1">Address Proof Image</label><br/>
<img for="AddressProofImage" id="AddressProofImagePreview" src="<?php echo e($AddressProofImagePath); ?>" alt="Address Proof Image">

<input id="AddressProofImage" name="AddressProofImage" type="file"  class="form-control" aria-required="true" onchange="readURLaddress(this)" aria-invalid="false" <?php echo e($image_required); ?>  accept="image/*">
<input type="hidden" name="hdAddressProofImage" value="<?php echo e($AddressProofImage); ?>">
<?php $__errorArgs = ['AddressProofImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
    </div>
</div>
<div>
<input type="hidden" name="id" value="<?php echo e($id); ?>">
<input type="hidden" name="agent_id" value="<?php echo e($agent_id); ?>">
<input type="hidden" name="admin_id" value="<?php echo e($admin_id); ?>">
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
        
    
function readURLidProof(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#IdProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}

function readURLaddress(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#AddressProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/edit_Village.blade.php ENDPATH**/ ?>