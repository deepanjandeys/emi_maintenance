;
<?php $__env->startSection('page_title','Edit EMI Collection'); ?>
<?php $__env->startSection('emi_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>

<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_TYPE=session()->get('ADMIN_TYPE')); ?>

    <?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script type="text/javascript">

function getBillLastEMI(value) {

   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/getBillLastEMI',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        debugger;
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
         //$('#id').val(obj.sql);
            window.location.replace('/<?php echo e($AJAX_ROOT); ?>/'+obj.typeName+'/emis/emi_collection/'+obj.id);
            
        }
        else if(obj.found=='2')
        {
            $('#bill_id_message').html('<span class="text-danger">Bill Not Approved</span>');
        }
        else if(obj.found=='3')
        {
            $('#bill_id_message').html('EMI Paids');
            window.location.replace('/<?php echo e($AJAX_ROOT); ?>/'+obj.typeName+'/emis/emi_collection/'+obj.id);
        }
        else if(obj.found=='4')
        {
        $('#bill_id_message').html('Customer is Not Under You');
        }
        else if(obj.found=='5')
        {
            $('#bill_id_message').html('Bill ID Not Found');
        }
        else 
        {
            $('#bill_id_message').html('Something wrong happen');
        }

            $('#EMI_loan').val('');
            $('#EMI_Interest').val('');
            $('#emi_amount').val('');
            $('#fine_amount').val('');
            $('#due_amt').val('');
            $('#paybleAmt').val('');
            $('#paidAmt').val('');
            $('#cash').val('');
            $('#bank').val('');
            $('#remarks').val('');
            $('#submit-button').hide();
            $('#btn_calculate_emi_clear').hide();

   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function calculate_emi_clear() {
var bill_id=$('#bill_id').val();

   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/calculate_emi_clear',
    data: { id: bill_id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //debugger;
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
         $('#divEMI_Clear1').show();
         $('#divEMI_Clear2').show();
         $('#divEMI_Clear3').show();
         $('#divEMI_Clear4').show();
         $('#str').html(obj.str);
         $('#clearValue').val(obj.clearValue);

        }
        else 
        {
         //$('#id').val('0');
            $('#divEMI_Clear1').hide();
            $('#divEMI_Clear2').hide();
            $('#divEMI_Clear3').hide();
            $('#divEMI_Clear4').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function clearAll() {
var bill_id=$('#bill_id').val();

   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/clearAllEMI',
    data: { id: bill_id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //debugger;
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
        $('#divEMI_Clear4').html('<h3>EMI Collection closed</h3>');
        }
        else 
        {
        $('#divEMI_Clear4').html('not Cleared');
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function showHideFineDetails()
{
    $('#divFineDetails').toggle();
}

</script>
<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      
<div class="row">
    <div class="col-3">
    <a href='<?php echo e(url("$typeName/emis")); ?>' >
<button type="button" class="btn btn-success">Back</button>
</a>        
    </div>
    <div class="col-9">
      <h1 class="title-1 m-b-10">EMI Collection </h1>  
    </div>
</div>
<div class="bg-mycolor text-light p-2 mt-3">
<h6 class="text-success">EMI Details</h6>
<div class="row">
    <div class="col-2">
     id : <span class="text-primary font-weight-bold"><?php echo e($emi->id??''); ?></span>   
     </div>
    <div class="col-3">
     EMI Date : <span class="text-primary font-weight-bold"><?php echo e($emi->emi_date??''); ?></span>   
     </div>
     <div class="col-2">
     loan amount: <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->LoanAmount??''); ?></span>   
     </div>
    <div class="col-2">
     Interest: <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->IntOnLoan??''); ?></span>   
    </div>
    <div class="col-2">
     No. EMI  : <span class="text-primary font-weight-bold"><?php echo e($noOf_unPaidEMI); ?> / <?php echo e($emi->getBills[0]->EMI_Period??''); ?></span>   
    </div>
</div>
<h6 class="text-success">Customer Details</h6>
<div class="row">
    <div class="col-2">
     Name : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getCustomers[0]->name??''); ?></span>   
     </div>
    <div class="col-5">
     Address : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getCustomers[0]->address??''); ?></span>   
     </div>
     <div class="col-1">
     PIN : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getCustomers[0]->pin??''); ?></span>   
     </div>
    <div class="col-2">
     Phone : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getCustomers[0]->mobile??''); ?></span>   
    </div>
    <div class="col-2">
     Village : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getCustomers[0]->getVillages[0]->name??''); ?></span>   
    </div>
</div>
<h6 class="text-success">Product Details</h6>
<div class="row">
    <div class="col-2">
     Code : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getProduct[0]->code??''); ?></span>   
     </div>
    <div class="col-3">
     Name : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getProduct[0]->name??''); ?></span>   
     </div>
     <div class="col-2">
     Sale Price : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->sale_price??''); ?></span>
     </div>
    <div class="col-2">
     Group : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getProduct[0]->getGroups[0]->name??''); ?></span>   
    </div>
    <div class="col-2">
     Sub Group : <span class="text-primary font-weight-bold"><?php echo e($emi->getBills[0]->getProduct[0]->getSubGroups[0]->name??''); ?></span>   
    </div>
</div>    
</div>
<span class="d-none"><?php echo e($total_EMI_Period=$emi->getBills[0]->EMI_Period??''); ?></span> 
<div class="row">
<div class="col-xl-3">
<div class="form-group">
<label for="bill_id" class="control-label mb-1 text-danger font-weight-bold">Bill ID</label>
<input id="bill_id" name="bill_id" type="text" value="<?php echo e($emi->bill_id??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" onchange="getBillLastEMI(this.value)">
<span id="bill_id_message" class="text-danger font-weight-bold">
<?php if($noOf_unPaidEMI==$total_EMI_Period): ?> All EMI Paid <?php endif; ?>
</span>
<?php $__errorArgs = ['bill_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<form action='<?php echo e(route("$typeName.manage_emi_collect")); ?>' method="post">
<?php echo csrf_field(); ?>

<div class="form-group">
<label cfor="EMI_loan" class="control-label mb-1">EMI Loan</label>
<input id="EMI_loan" name="EMI_loan" type="text" value="<?php echo e($emi->getBills[0]->EMI_Loan??''); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" readonly>
<span id="EMI_loan_message" class="text-danger font-weight-bold"></span>
<?php $__errorArgs = ['EMI_loan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label cfor="EMI_Interest" class="control-label mb-1">EMI Interest</label>
<input id="EMI_Interest" name="EMI_Interest" type="text" value="<?php echo e($emi->getBills[0]->EMI_interest??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" readonly>
<span id="EMI_Interest_message" class="text-danger font-weight-bold"></span>
<?php $__errorArgs = ['EMI_Interest'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label cfor="emi_amount" class="control-label mb-1">EMI Amount</label>
<input id="emi_amount" name="emi_amount" type="text" value="<?php echo e($emi->emi_amount??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" readonly>
<?php $__errorArgs = ['emi_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="fine_amount" class="control-label mb-1">Fine Amount</label>
<?php if(isset($emi->fine_amount)): ?>
    <?php if($emi->fine_amount>0): ?>
    <a href="javascript:void(0)" onclick="showHideFineDetails()">Fine Details</a>
    <div id="divFineDetails" style="display:none;">
<br><span class="bg-primary text-light font-weight-bold px-5"><?php echo e($emi->emi_date); ?> - today : <?php echo e($noOfDays); ?> Days </span>
<br><span class="bg-warning text-danger font-weight-bold px-5"><?php echo e($noOfDays); ?> Days x 50 = <?php echo e($emi->fine_amount); ?></span>
    </div>
    <?php endif; ?>
<?php endif; ?>
<input id="fine_amount" name="fine_amount" type="text" value="<?php echo e($emi->fine_amount??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" >
<?php $__errorArgs = ['fine_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<?php if($due_amt !=0): ?>
<div class="form-group">
<label for="due_amt" class="control-label mb-1 text-danger font-weight-bold">Previous Due</label>
<input id="due_amt" name="due_amt" type="text" value="<?php echo e($due_amt??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" readonly >
<?php $__errorArgs = ['due_amt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php endif; ?>

<div class="form-group">
<label for="paybleAmt" class="control-label mb-1">Payble Amount</label>
<input id="paybleAmt" name="paybleAmt" type="text" value="<?php echo e($paybleAmt??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" readonly >
<?php $__errorArgs = ['paybleAmt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="paidAmt" class="control-label mb-1">Paid Amount</label>
<input id="paidAmt" name="paidAmt" type="text" value="<?php echo e($paidAmt??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" onkeyup="backCalCulatePaidAmt(this.value)">
<?php $__errorArgs = ['paidAmt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="cash" class="control-label mb-1">Cash</label>
<input id="cash" name="cash" type="text" value="<?php echo e($cash??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false">
<?php $__errorArgs = ['cash'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="bank" class="control-label mb-1">Bank</label>
<input id="bank" name="bank" type="text" value="<?php echo e($bank??'0'); ?>" class="form-control text-right" aria-required="true" aria-invalid="false">
<?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="remarks" class="control-label mb-1">Remarks</label>
<input id="remarks" name="remarks" type="text" value="<?php echo e($remarks??''); ?>" class="form-control text-right" aria-required="true" aria-invalid="false">
<?php $__errorArgs = ['remarks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="collect_time" class="control-label mb-1">EMI Collect Time </label>
<input id="collect_time" name="collect_time" type="text" value="<?php echo e($emi->collect_time??''); ?>" class="form-control text-right" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['collect_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php if($noOf_unPaidEMI!=$total_EMI_Period): ?>
  <button id="submit-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</button>
<?php endif; ?>
  <input type="hidden" id="id" name="id" value="<?php echo e($emi->id??'0'); ?>" >
</form>
        
    </div>
    <div class="col-xl-9">
        <h6>EMI Collection details</h6>
  <div class="table table-borderd table-responsive bg-mycolor" style="height: 100vh;overflow-y: scroll;">
      
        <table class="text-light">
                <thead>
                <tr>
                    <th>Sl</th>
                    <th>
                        Due Date
                    </th>
                    <th>
                        Recieved Date
                    </th>
                    <th>
                        EMI Loan
                    </th>
                    <th>EMI Interest</th>
                    <th>EMI
                        Amount
                    </th>
                    <th>
                        Fine
                    </th>
                    <th>
                        Payble Amount                        
                    </th>
                    <th>
                        Paid Amount
                    </th>
                    <th>Due </th>
                </tr>
    
                </thead>
                <tbody id="tbEMI">
        <span class="d-none"><?php echo e($i=0); ?></span>
        <?php $__currentLoopData = $previousEMIs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?>

<button type="button" class="btn btn-link" data-toggle="collapse" data-target="#emiDetails<?php echo e($ec->id); ?>" aria-expanded="false">
                    <i class="fas fa-chevron-down toggle-icon"></i>  <!-- Font Awesome Plus Icon -->
                </button>
            </td>
            <td><?php echo date('d-M', strtotime($ec->emi_date)); ?></td>
            <td> 
                <?php if($ec->details && $ec->details->first()->collect_time): ?>
                <?php echo date('d-m-Y', strtotime($ec->details->first()->collect_time)); ?>

            <?php else: ?>
                No Collection
            <?php endif; ?>
        </td>
            <td class="text-right"><?php echo e($ec->EMI_Loan); ?></td>
            <td class="text-right"><?php echo e($ec->EMI_interest); ?></td>
            <td class="text-right"><?php echo e($ec->emi_amount); ?></td>
            <td class="text-right"><?php echo e($ec->fine_amount); ?></td>
            <td class="text-right"><?php echo number_format((float)str_replace(",", "", $ec->paid_amt) + (float)str_replace(",", "", $ec->due_amt), 2); ?></td>
            <td class="text-right"><?php echo e($ec->paid_amt); ?></td>
            <td class="text-right"><?php echo e($ec->due_amt); ?></td>
        </tr>

        <!-- Child Accordion (details) -->
        <tr id="emiDetails<?php echo e($ec->id); ?>" class="collapse">
            <td colspan="10">
               <form action='<?php echo e(route("$typeName.add_emi_collect_details")); ?>' method="post">

                <?php echo csrf_field(); ?> bill
                 <input type="text" name="bill_id" value="<?php echo e($emi->bill_id??'0'); ?>">
                 emi id
                 <input type="text" name="emi_id" value="<?php echo e($ec->id); ?>">
                <table class="table table-bordered table-sm">
                    <thead>
                        <tr>
                            <th>Detail ID</th>
                            <th class="text-right">Amount</th>
                            <th>Cash</th>
                            <th>Bank</th>
                            <th>Date of Collection</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $ec->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detail->id); ?>


                            <button type="button" class="btn btn-link add-row">
                    <i class="fas fa-plus" title="Add New Record"></i> 
                </button>
            </td>

                            <td class="text-right"><?php echo e($detail->amount); ?></td>
                            <td class="text-right"><?php echo e($detail->cash); ?></td>
                            <td class="text-right"><?php echo e($detail->bank); ?></td>
                            <td><?php echo date('d-m-Y', strtotime($detail->collect_time)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <tr class="new-record-row d-none">
                        <td>
                            <button type="button" class="btn btn-link remove-row">
                                <i class="fas fa-times text-danger"></i> <!-- Remove icon -->
                            </button>
                            <button type="submit" class="btn btn-primary">
              <i class="fas fa-save"></i> Save</button>
                        </td>
                        <td>
                            
                            <input type="number" name="new_amount[]" class="form-control text-right" placeholder="Amount"></td>
                            <td>
                            
                            <input type="number" name="new_cash[]" class="form-control text-right" placeholder="Cash"></td>
                            <td>
                            
                            <input type="number" name="new_bank[]" class="form-control text-right" placeholder="Bank"></td>
                        <td><input type="text" name="new_date[]" class="form-control" placeholder="Date of Collection" value="<?php echo date('d-m-Y'); ?>"></td>
                        
                        </tr>
                    </tbody>
                </table>

                </form>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>               
            </table>
        </div>

<div class="row mt-5 form-group">

<div class="col-5">
    <?php if($noOf_unPaidEMI!=$total_EMI_Period): ?>
    <a href="javascript:void(0)" class="btn btn-warning text-danger font-weight-bold" id="btn_calculate_emi_clear" onclick="calculate_emi_clear()">Calculate EMI Closure Value</a>
    <?php endif; ?>
</div>
<div class="col-2" id="divEMI_Clear1" style="display:none;"><label for="clearValue" id="str" class="control-label mb-1 text-danger font-weight-bold"></label></div>
<div class="col-2" id="divEMI_Clear2" style="display:none;">
<input id="clearValue" name="clearValue" type="text" class="form-control text-right" aria-required="true" aria-invalid="false" readonly >
</div>
<div class="col-2" id="divEMI_Clear3" style="display:none;">
<a href="javascript:void(0)" onclick="clearAll()" class="btn btn-success">Close EMI</a>
</div>

<div class="col-12" id="divEMI_Clear4" style="display:none;">
if you want to close EMI collection, click on <span class="text-success font-weight-bold">Closer</span> Button    
</div>
</div>
</div>
<br/>
<script type="text/javascript">

docReady(function() {

$('#collect_time').daterangepicker({
      singleDatePicker: true,
      timePicker: true,
      showDropdowns: true,
       locale: {
        format: 'DD-MM-YYYY HH:mm'
      }
    });
    
});


</script>
<script>
    $(document).on('click', '.btn-link', function () {
        var icon = $(this).find('.toggle-icon');
        icon.toggleClass('fa-chevron-down fa-chevron-up');
    });

   $(document).ready(function() {
    // Add new record row when plus icon is clicked
    $('.add-row').on('click', function() {
        // Clone the hidden row for adding new records
        var newRow = $('.new-record-row').first().clone().removeClass('d-none');
        $(this).closest('tr').after(newRow); // Insert the new row after the clicked row
    });

    // Remove row when remove icon is clicked
    $(document).on('click', '.remove-row', function() {
        $(this).closest('tr').remove(); // Remove the new record row
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/edit_emiCollection.blade.php ENDPATH**/ ?>