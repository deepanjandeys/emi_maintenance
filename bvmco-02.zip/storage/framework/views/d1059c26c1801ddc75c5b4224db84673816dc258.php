;
<?php $__env->startSection('page_title','Customer trash'); ?>
<?php $__env->startSection('customer_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"><?php echo e($typeName=session()->get('typeName')); ?></span>
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Customer Trash</h2>
<a href='<?php echo e(url("$typeName/customer")); ?>' >
<button type="button" class="btn btn-success">Go to Customer</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>PIN</th>
                                                <th>Address</th>
                                                <th>Village</th>
                                                <th>Approved</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href='<?php echo e(url("$typeName/customer/restore/")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    <a href='<?php echo e(url("$typeName/customer/forceDelete/")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-danger">&nbsp;Delete&nbsp;</button>
                                                    </a>
                                                    
                                                </td>
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->mobile); ?></td>
                                                <td><?php echo e($list->pin); ?></td>
                                                <td><?php echo e($list->address); ?></td>
                                                <td>                                      <?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($list->village_id==$list1->id): ?>
                                                        <?php echo e($list1->name); ?>

                                                    <?php break; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php if($list->isApproved==1): ?>
                                                    <span class="text-primary"> Approved</span>
                                                    
                                                    <?php elseif($list->isApproved==0): ?>
                                                    <span class="text-danger">Disapproved</span>
                                                   
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                <td>
                                                    <?php if($list->status==1): ?>
                                                    <span class="text-primary"> Active</span>
                                                    
                                                    <?php elseif($list->status==0): ?>
                                                    <span class="text-danger">Inactive</span>
                                                   
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/customer-trash.blade.php ENDPATH**/ ?>