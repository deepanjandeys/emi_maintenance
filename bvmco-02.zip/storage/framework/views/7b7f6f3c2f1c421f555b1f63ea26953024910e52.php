;
<?php $__env->startSection('page_title','Edit Branch Stock'); ?>
<?php $__env->startSection('BranchStock_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<h2 class="title-1 m-b-10">Purchase</h2>
<a href="<?php echo e(url('admin/branchStock')); ?>" >
<button type="button" class="btn btn-success">Back </button>
</a>

<script type="text/javascript">

function getBranchDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getBranchDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnBranchName').html('<b>Name : </b>'+obj.name);
            $('#spnBranchAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnBranchMobile').html(' <b>Mobile</b> :'+obj.mobile);
            }
        else
        {
            $('#spnBranchName').html('');
            $('#spnBranchAddress').html('');
            $('#spnBranchMobile').html('');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getProductDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnGroup').html(' <b>Group</b> :'+obj.GroupId);
            $('#spnSubGroup').html(' <b>Sub Group</b> :'+obj.SubGroupId);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#spnProdSubGroupName').html(' <b>Product Sub Group :</b>'+obj.product_sub_group_name);
            $('#sale_price').val(obj.MRP);
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnGroup').html('');
            $('#spnSubGroup').html('');
            $('#spnProdGroupName').html('');
            $('#spnProdSubGroupName').html('');
            $('#sale_price').val('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
</script>

<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action="<?php echo e(route('manage_branchStock_process')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="form-group d-none">
<label for="branch_id" class="control-label mb-1">Branch id</label>
<input list="Branches" id="branch_id" name="branch_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getBranchDetails(this.value)" value="1" required>
<datalist id="Branches">
<?php $__currentLoopData = $Branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<span id="spnBranchName"></span>
<span id="spnBranchAddress"></span>
 <span id="spnBranchMobile"></span>
 <?php $__errorArgs = ['Sale_agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
 <div class="alert alert-danger" role="alert">
 <?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
<datalist id="products">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<span id="spnProdName"></span>
<span id="spnCode"></span>
<span id="spnImage"></span>
<span id="spnGroup"></span>
<span id="spnProdGroupName"></span>
<span id="spnSubGroup"></span>
<span id="spnProdSubGroupName"></span>
<?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="qty" class="control-label mb-1">Quantity</label>
<input id="qty" name="qty" type="text" value="" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="purchase_date" class="control-label mb-1">Purchase Date</label>
<input id="purchase_date" name="purchase_date" type="text" value="<?php echo e($purchase_date); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['purchase_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="<?php echo e($id); ?>">
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
    

docReady(function() {

$('#purchase_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/purchase.blade.php ENDPATH**/ ?>