;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

	<div class="row">
			<h2 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> Dashboard</h2>

        <div class="col-lg-6 d-none">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
     		</div>
         </div>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>