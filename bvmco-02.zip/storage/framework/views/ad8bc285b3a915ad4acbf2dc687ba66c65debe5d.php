;
<?php $__env->startSection('page_title','View Bill'); ?>
<?php $__env->startSection('bill_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<h2 class="title-1 m-b-10">View Bill</h2>
<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      
<span class="d-none"><?php echo e(@$typeName=session()->get('typeName')); ?></span>
<a href='<?php echo e(url("$typeName/bills")); ?>' >
<button type="button" class="btn btn-success">Back</button>
</a>

<script type="text/javascript">
    Date.prototype.addDays = function(days) {
    var date = new Date(this.valueOf());
    date.setDate(date.getDate() + days);
    return date;
    }

function getCustomerDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getCustomerDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
         $('#Customer_name').html(obj.name);
         $('#address').html(obj.address);
         $('#mobile').html(obj.mobile);
         //getBookingDetails(value);
        }
        else 
        {
         $('#Customer_name').html('');
         $('#address').html('');
         $('#mobile').html('');      
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
var myArray;
function getBookingDetails(value) {
    //debugger;
   $.ajax({
    type: "POST",
    url: '/getBookingDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        console.log('getBookingDetails'+data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found>0)
        {
         $('#spnCustOrders').html("this Customer has follwing orders, select one of these <br>"+obj.str);
         $('#arr').val(obj.arr[0].customer_id);
         myArray=obj.arr;

        }
        else 
        {
         $('#spnCustOrders').html('');
         
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function setOrderDetails(i)
{
    //$('#customer_id').val(myArray[i].customer_id);
    $('#Sale_agent_id').val(myArray[i].Sale_agent_id);
    $('#product_id').val(myArray[i].product_id);
    $('#sale_price').val(myArray[i].sale_price);
    $('#down_payment').val(myArray[i].down_payment);
    $('#LoanAmount').val(myArray[i].LoanAmount);
    $('#IntOnLoan').val(myArray[i].IntOnLoan);
    $('#EMI_mode').val(myArray[i].EMI_mode);
    $('#EMI_Period').val(myArray[i].EMI_Period);
    $('#EMI').val(myArray[i].EMI);
    $('#booking_advance').val(myArray[i].booking_advance);
   $('#balanced_downpayment').val(myArray[i].balanced_downpayment);
    
    //getCustomerDetails(myArray[i].customer_id);
    getSaleAgentDetails(myArray[i].Sale_agent_id);
    getProductDetails(myArray[i].product_id);
}

function getSaleAgentDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getSaleAgentDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnName').html('<b>Name : </b>'+obj.name);
            $('#spnAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnMobile').html(' <b>Mobile</b> :'+obj.mobile);
         /*   $('#spnBranch').html(' <b>Branch ID :</b>'+obj.branch_id + ' <b> Branch Name </b>'+obj.branch_name);
            $('#branch_id').val(obj.branch_id);
            */
        }
        else
        {
            $('#spnName').html('');
            $('#spnAddress').html('');
            $('#spnMobile').html('');
            //$('#spnBranch').html('');
            //$('#branch_id').val(0);
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getProductDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnCategory').html(' <b>category</b> :'+obj.category);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#sale_price').val(obj.MRP);

            $('#spnLoanType').html('<b>Loan Type : </b> '+obj.loan_type_name);
            if(obj.loan_type==1)
            {
                $('#divIntest').hide();
            }
            else 
            {
                $('#divIntest').show();
            }

            getStockDetails();
            //calculate_LoanAmount();
            //calculate_EMI();
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnCategory').html('');
            $('#spnProdGroupName').html('');
            $('#sale_price').val('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function getStockDetails() {
    var branch_id=$('#branch_id').val();
    var product_id =$('#product_id').val();
   $.ajax({
    type: "POST",
    url: '/getStockDetails',
    data: { branch_id: branch_id, product_id:product_id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
          $('#spnAvlStock').html('<span style="color:green;font-weight:bold;">Available stock </span>'+'<span style="color:blue;font-weight:bold;" id="spnAvlStockQty">'+obj.stock+'</span>');
          $('#submit-button').show();
        }
        else
        {
           $('#spnAvlStock').html('<span style="color:red;font-weight:bold;">stock is not Available </span>');
           $('#submit-button').hide();
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
function calculate_LoanAmount()
{
    var sale_price  = parseFloat($('#sale_price').val());
    if(isNaN(sale_price))
        sale_price=0;

    /*var down_payment= parseFloat($('#down_payment').val());
    if(isNaN(down_payment))
        down_payment=0;
        */
    var balanced_downpayment= parseFloat($('#balanced_downpayment').val());
    if(isNaN(balanced_downpayment))
        balanced_downpayment=0;
      
    var LoanAmount  = sale_price - balanced_downpayment;

    $('#LoanAmount').val(LoanAmount);
    calculate_Interest();
}
function calculate_EMI(calcu_emi_period=true)
{    
        //debugger;
    console.log('calculate_EMI');

    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;

    var IntOnLoan   = parseFloat($('#IntOnLoan').val());
    if(isNaN(IntOnLoan))
        IntOnLoan=0;
    
    var EMI_in_Months   = parseInt($('#EMI_in_Months').val());
    if(isNaN(EMI_in_Months))
        EMI_in_Months=0;
    
    var EMI_mode    = $('#EMI_mode').val();
    var EMI_Period=1;
    var EMI=0;
    var EMI_Interest=0;

    if(!calcu_emi_period)
    {
    EMI_Period=$('#EMI_Period').val();     
    }

    if(EMI_mode==1)
    {   // daily
        if(calcu_emi_period) EMI_Period =EMI_in_Months*30;
        EMI_Interest=IntOnLoan/30;
    }
    else if(EMI_mode==2)
    {
        // weekly
        if(calcu_emi_period) EMI_Period =EMI_in_Months*4;
        EMI_Interest=IntOnLoan/4;
    }
    else if(EMI_mode==3)
    {
        // Fort night
        if(calcu_emi_period) EMI_Period =EMI_in_Months*2;
        EMI_Interest=IntOnLoan/2;
    }
    else if(EMI_mode==4)
    {
        // Mobthly
        if(calcu_emi_period) EMI_Period =EMI_in_Months;
        EMI_Interest=IntOnLoan;
    }
var EMI_Loan=LoanAmount / EMI_Period;

    EMI=EMI_Loan+EMI_Interest;

    $('#spnEMI_Loan').html(EMI_Loan.toFixed(2));
    $('#spnEMI_Interest').html(EMI_Interest.toFixed(2));
    $('#hdEMI_Loan').val(EMI_Loan.toFixed(2));
    $('#hdEMI_Interest').val(EMI_Interest.toFixed(2));
    
    $('#EMI').val(EMI.toFixed(2));
    //calculate_Interest();
    if(calcu_emi_period) $('#EMI_Period').val(EMI_Period);
    
    //calculate_Interest();  
    calculate_EMI_list();
    //calculate_EMI_period();
}

/*
function calculate_EMI_period()
{
    
    var EMI_in_Months   = parseInt($('#EMI_in_Months').val());
    if(isNaN(EMI_in_Months))
        EMI_in_Months=0;
    
    var EMI_mode    = $('#EMI_mode').val();
    var EMI_Period=0;

    if(EMI_mode==1)
    {   // daily
        EMI_Period =EMI_in_Months*30;
    }
    else if(EMI_mode==2)
    {
        // weekly
        EMI_Period =EMI_in_Months*4;
    }
    else if(EMI_mode==3)
    {
        // Fort night
        EMI_Period =EMI_in_Months*2;
    }
    else if(EMI_mode==4)
    {
        // Mobthly
        EMI_Period =EMI_in_Months;
    }

    $('#EMI_Period').val(EMI_Period);
    calculate_EMI_list();
}
*/

function calculate_Interest()
{
    //debugger;
    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;
    
var interestPercntage  = parseInt($('#interestPercntage').val());
    if(isNaN(interestPercntage))
        interestPercntage=0;
  
    var IntOnLoan   = 0;
    if(interestPercntage>0)
        IntOnLoan=LoanAmount * interestPercntage /100;

    $('#IntOnLoan').val(IntOnLoan.toFixed(2));
    calculate_EMI();
}

function calculate_EMI_list()
{
    var id=$('#id').val();
    var emi_collections_count = $('#emi_collections_count').val();
    if(id=='0' || emi_collections_count =='0')
    {
        console.log('id '+id+ ' emi_collections_count '+emi_collections_count);

    var EMI_Period = parseInt($('#EMI_Period').val());
    var EMI=parseFloat($('#EMI').val()).toFixed(2);
    var i=0; str='';
    var bill_date = $('#bill_date').val();
    var bill_dates=bill_date.split('-');
    var d=''; m=''; y='';
//console.log(' bill_date '+bill_date);
    if(bill_dates.length==3)
    {
        d=bill_dates[0];
        m=bill_dates[1];
        y=bill_dates[2];
    }
//console.log('d '+d+' m '+m +'y '+y);

    var date = new Date(y+'-'+m+'-'+d);
//console.log(date);

    var EMI_mode=$('#EMI_mode').val();
    
    for (var i = 1; i <=EMI_Period; i++) 
    {
        if(EMI_mode=='1')
            date=date.addDays(1);    
        else if(EMI_mode=='2')
            date=date.addDays(7);
        else if(EMI_mode=='3')
            date=date.addDays(14);
        else if(EMI_mode=='4')
            date=date.addDays(30);
  //      console.log('date '+date);
        d=date.getDate();
        if(d<10)
            d='0'+d;
        m=date.getMonth();
        m++;
        if(m<10)
            m='0'+m;
        y=date.getFullYear();
        dtStr=d+'-'+m+'-'+y;

        str +='<tr><td>'+i+'</td><td><input type="text" value="'+dtStr+'" name="EMI_Date'+i+'" class="EMI_date" ></td><td>'+EMI+'</td><td>0</td><td></td></tr>';
    }
    $('#tbEMI').html(str);

    $('.EMI_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
    
    }
    
}

function calculate_total_downpayment()
{
    var booking_advance=parseFloat($('#booking_advance').val());
    if(isNaN(booking_advance))
        booking_advance=0;

    var down_payment=parseFloat($('#down_payment').val());
    if(isNaN(down_payment))
        down_payment=0;
    
    var balanced_downpayment=booking_advance+down_payment;
    $('#balanced_downpayment').val(balanced_downpayment);
     calculate_LoanAmount();
}
</script>
<span class="d-none"><?php echo e(@$typeName=session()->get('typeName')); ?></span>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action='<?php echo e(route("$typeName.manage_bill_process")); ?>' method="post">
<?php echo csrf_field(); ?>
<div class="form-group">
<label for="bill_date" class="control-label mb-1">Bill Date</label>
<input id="bill_date" name="bill_date" type="text" value="<?php echo e($bill_date); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['bill_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div> 
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="customer_id" class="control-label mb-1">Customer</label>
<input list="customers" id="customer_id" name="customer_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getCustomerDetails(this.value)" required>
<datalist id="customers">
<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="row">

<div class="col-2 font-weight-bold">Name</div>
<div class="col-2" id="Customer_name"></div>
<div class="col-2 font-weight-bold">Address</div>
<div class="col-2" id="address"></div>
<div class="col-2 font-weight-bold">Mobile</div>
<div class="col-2" id="mobile" ></div>
</div>
<hr>

<input type="hidden" id="arr">
<span id="spnCustOrders"></span>
<div class="form-group">
<label for="Sale_agent_id" class="control-label mb-1">Sale agent id</label>
<input list="SaleAgents" id="Sale_agent_id" name="Sale_agent_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getSaleAgentDetails(this.value)" required>
<datalist id="SaleAgents">
<?php $__currentLoopData = $sales_agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<span id="spnName"></span>
<span id="spnAddress"></span>
<span id="spnMobile"></span>
<span id="spnBranch"></span>
<?php $__errorArgs = ['Sale_agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<hr>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
<datalist id="products">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<span id="spnProdName"></span>
<span id="spnCode"></span>
<span id="spnImage"></span>
<span id="spnCategory"></span>
<span id="spnProdGroupName"></span>
<?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<span id="spnAvlStock"></span>
<div class="form-group">
<label for="sale_price" class="control-label mb-1">Product price</label>
<input id="sale_price" name="sale_price" type="text" value="<?php echo e($sale_price); ?>" class="form-control" onchange="calculate_LoanAmount()" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="booking_advance" class="control-label mb-1">Booking Advance</label>
<input id="booking_advance" name="booking_advance" type="text" value="<?php echo e($booking_advance); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_total_downpayment()" required>
<?php $__errorArgs = ['booking_advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="down_payment" class="control-label mb-1">Current Down payment</label>
<input id="down_payment" name="down_payment" type="text" value="<?php echo e($down_payment); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_total_downpayment()" required>
<?php $__errorArgs = ['down_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="balanced_downpayment" class="control-label mb-1">Total Down payment</label>
<input id="balanced_downpayment" name="balanced_downpayment" type="text" value="<?php echo e($balanced_downpayment); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['balanced_downpayment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="row">
    <div class="col-6">
<h6>Loan details</h6>
<div class="form-group">
<label for="LoanAmount" class="control-label mb-1">Loan Amount</label>
<input id="LoanAmount" name="LoanAmount" type="text" value="<?php echo e($LoanAmount); ?>" class="form-control" aria-required="true" aria-invalid="false" required onchange="calculate_EMI()">
<?php $__errorArgs = ['LoanAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="EMI_in_Months" class="control-label mb-1">EMI in Months</label>
<input id="EMI_in_Months" name="EMI_in_Months" type="number" value="<?php echo e($EMI_in_Months); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<?php $__errorArgs = ['EMI_in_Months'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="EMI_mode" class="control-label mb-1">EMI Mode</label>
<select id="EMI_mode" name="EMI_mode" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<option value="">select</option>
<?php $__currentLoopData = $calcmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($EMI_mode==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['EMI_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="EMI_Period" class="control-label mb-1">EMI_Period</label>
<input id="EMI_Period" name="EMI_Period" type="text" value="<?php echo e($EMI_Period); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI(false)" required>
<?php $__errorArgs = ['EMI_Period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group" id="divIntest">
<label for="interestPercntage" class="control-label mb-1">Interest Percentage (%)</label>
<input id="interestPercntage" name="interestPercntage" type="number" value="<?php echo e($interestPercntage); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_Interest()" required>
<?php $__errorArgs = ['interestPercntage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="IntOnLoan" class="control-label mb-1">Interest On Loan</label>
<input id="IntOnLoan" name="IntOnLoan" type="text" value="<?php echo e($IntOnLoan); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<?php $__errorArgs = ['IntOnLoan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="EMI" class="control-label mb-1">EMI</label>
<input id="EMI" name="EMI" type="text" value="<?php echo e($EMI); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI_list()" required>
<span class="text-primary">EMI Loan <span  id="spnEMI_Loan" class="text-danger"><?php echo e($EMI_Loan); ?></span><input id="hdEMI_Loan" name="EMI_Loan" type="hidden" value="<?php echo e($EMI_Loan); ?>"></span>
<span class="text-primary">EMI Interest <span id="spnEMI_Interest" class="text-danger"><?php echo e($EMI_Interest); ?></span><input id="hdEMI_Interest" name="EMI_Interest" type="hidden" value="<?php echo e($EMI_Interest); ?>"></span>

<?php $__errorArgs = ['EMI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
        
    </div>
    <div class="col-6">
        <h6>EMI Details</h6>        
        <div class="table table-borderd table-responsive bg-mycolor" style="height: 100vh;overflow-y: scroll;">
            <table class="text-light">
                <thead>
                <tr>
                    <th>
                        Sl
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Fine
                    </th>
                    <th>
                        
                    </th>

                </tr>
    
                </thead>
                                <tbody>
                    <span class="d-none"><?php echo e($i=0); ?></span>
                    <?php $__currentLoopData = $emi_collected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <td>
                            <?php echo e(++$i); ?>

                        </td>
                        <td>
                          <?php echo e($ec->emi_date); ?> 
                        </td>
                        <td>
                            <?php echo e($ec->emi_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->fine_amount); ?>

                        </td>
                </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                </tbody> 

                <tbody id="tbEMI">
                    <span class="d-none"><?php echo e($i=0); ?></span>
                    <?php $__currentLoopData = $emi_collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="d-none"><?php echo e(@$i++); ?></span>
                <tr>
                        <td>
                            <?php echo e($i); ?>

                        </td>
                        <td>
                        <?php echo e($ec->emi_date); ?> 
                        </td>
                        <td>
                            <?php echo e($ec->emi_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->fine_amount); ?>

                        </td>
                </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                </tbody>                
            </table>
        </div>
    </div>
</div>

<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div>

</div>
<input type="hidden" id="id" name="id" value="<?php echo e($id); ?>" >
<input type="hidden" id="order_id" name="order_id" value="<?php echo e($order_id); ?>" >
<input type="hidden" id="emi_collections_count" name="emi_collections_count" value="<?php echo e($emi_collections_count); ?>" >

<input type="hidden" id="branch_id" name="branch_id" value="1" >
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">

docReady(function() {
    // DOM is loaded and ready for manipulation here
    getCustomerDetails(<?php echo $customer_id; ?>);
    getSaleAgentDetails(<?php echo $Sale_agent_id; ?>);
    getProductDetails(<?php echo $product_id; ?>);
    $('#customer_id').val(<?php echo $customer_id; ?>);
    $('#product_id').val(<?php echo $product_id; ?>);
    $('#Sale_agent_id').val(<?php echo $Sale_agent_id; ?>);

$('#bill_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('.EMI_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/view_bill.blade.php ENDPATH**/ ?>