;
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>

	<div class="row">
			<h2 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> Sale Agent Dashboard</h2>
<div class="col-12">
    <h3>Welcome <?php echo e(session()->get('ADMIN_REFER_NAME')); ?></h3>
</div>
        <div class="col-lg-12">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
                <span class="text-primary font-weight-bold">Total Collected Amount</span><span class="text-danger font-weight-bold"> <?php echo e($collected_amount); ?></span> <br> 
            <span class="text-primary font-weight-bold">Total Recieved Amount</span><span class="text-danger font-weight-bold"> <?php echo e($recieved_amount); ?></span>  
            
     		</div>
         </div>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/dashboard_sa.blade.php ENDPATH**/ ?>