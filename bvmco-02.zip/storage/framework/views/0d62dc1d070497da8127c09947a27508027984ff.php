;
<?php $__env->startSection('page_title','Admin Forget Password'); ?>
<?php $__env->startSection('dashboard_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  function forget_password()
  {
    window.location='/admin/forget_password';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title"><?php echo e(Config::get('constants.SITE_NAME')); ?> Admin Forget Password</h1> 
        <form action="<?php echo e(route('admin.forget.password')); ?>" method="post">
            <?php echo csrf_field(); ?>
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>

<div class="form-group">
<label for="name" class="control-label mb-1">User name</label>
<input id="name" name="name" type="text" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="user name of admin" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
            <div class="contact-form d-flex flex-column-reverse flex-lg-row ">
              
               <div class="form-field col-lg-6 text-center">
               </div>
               <div class="form-field col-lg-6">
                <input class="btn btn-lg btn-info btn-block" type="submit" value="Submit" name="Submit">
               </div>
            </div>
            
        </div>
      </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/admin_forget_password.blade.php ENDPATH**/ ?>