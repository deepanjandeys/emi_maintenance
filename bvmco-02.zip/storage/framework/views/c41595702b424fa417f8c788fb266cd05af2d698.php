
<?php $__env->startSection('content'); ?>
<style type="text/css">
 .table1  th{
        text-align: left;
    }
 .table1   td {
        padding-right: 10px;
    }
.table2  th{
        text-align: right;
    }
.table2  td{
        text-align: right;
        padding-right: 10px;
    }
</style>

<table style="width:100%">
    <tr>
        <td style="vertical-align: top;">
            <h2 style="text-align:center;">Loan Details</h2> 
<table class="table1" style="width:100%">
    <tr>
    <th>Bill No.</th>
    <td><?php echo e($id); ?></td>    
    <th>
        Bill Date
    </th>        
    <td>
        <?php echo e($bill_date); ?>

    </td>
    <th>
        Product
    </th>        
    <td colspan="3">
        <?php echo e($product_name); ?>

    </td>
    </tr>
    <tr>
    <th>
        Customer
    </th>        
    <td colspan="3">
        <?php echo e($Customer_name); ?>

    </td>    
    <th>
        Price 
    </th>        
    <td style="text-align:right;">
        <?php echo e($product_price); ?>

    </td>
    
    </tr>
    <tr>
    <th rowspan="3" style="vertical-align: top;">
        Address
    </th>        
    <td rowspan="3" colspan="3" style="vertical-align: top;">
        <?php echo e($Address); ?>

    </td>
    <th>
         Advance Payment
    </th>        
    <td style="text-align:right;">
         <?php echo e($booking_advance); ?>

    </td>
    <th>
        EMI in Months
    </th>        
    <td style="text-align:right;">
        <?php echo e($EMI_in_Months); ?>

    </td>
    </tr>  
    <tr>
    <th>
        Current payment
    </th>        
    <td style="text-align:right;">
        <?php echo e($balanced_downpayment); ?>

    </td>
     <th>
        EMI Period
    </th>        
    <td style="text-align:right;">
        <?php echo e($EMI_Period); ?>

    </td>
    </tr>
    <tr>
        <th>
            Down payment 
        </th>
        <td style="text-align:right;">
            <?php echo e($down_payment); ?> 
        </td>
        <td>
            
        </td>
        <td>
            
        </td>
    </tr>
    <tr>    
    <th>
        Mobile
    </th>        
    <td>
        <?php echo e($mobile); ?>

    </td>
    <th>
        
    </th>        
    <td>
        
    </td>
    <th>
        Loan Amount
    </th>        
    <td style="text-align:right;">
        <?php echo e($LoanAmount); ?>

    </td>
    <th>
        EMI 
    </th>        
    <td style="text-align:right;">
        <?php echo e($EMI); ?>

    </td>
    </tr>
    <tr>
        <th>Sale agent </th>
        <td colspan="3"><?php echo e($sale_agent); ?> </td>
    <th>
        Interest (%)
    </th>        
    <td style="text-align:right;">
        <?php echo e($interestPercntage); ?>

    </td>
    <th>
        Interest On Loan
    </th>        
    <td style="text-align:right;">
        <?php echo e($IntOnLoan); ?>

    </td>
    </tr>
    
</table> 
</td>
</tr>
<tr>
        <td>
        <h2>EMI Details</h2>
        <table style="width:100%">
            <tr>
                <td style="vertical-align: top;">
                <table class="table2" style="width:100%;">
                <thead>
                <tr>
                    <th>
                        Sl
                    </th>
                    <th>
                    EMI  Date
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Fine
                    </th>
                    <th>
                        Paid Amount
                    </th>
                    <th>
                        Due Amount
                    </th>
                    <td>
                        status
                    </td>
                </tr>
    
                </thead>
                <tbody id="tbEMI">
                    <tr>
                        <td>
<span style="display:none;"><?php echo e($i=0); ?> <?php echo e($c=count($emi_collections)); ?> <?php echo e($c=$c%30); ?>

</span>
                    
                        </td>
                    </tr>
                    
                    <?php for($i=0; $i<$c;): ?>
                    <span style="display:none;"><?php echo e($ec=$emi_collections[$i]); ?>

                    </span>
                    
                <tr>
                        <td>
                            <?php echo e(++$i); ?>

                        </td>
                        <td>
                            <?php echo e($ec->emi_date); ?>

                        </td>
                        <td>
                            <?php echo e($ec->emi_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->fine_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->paid_amt); ?>

                        </td>
                        <td>
                            <?php echo e($ec->due_amt); ?>

                        </td>
                        <td>
                        <?php if($current_emi_no==$ec->id): ?>
                           <span class="text-success">Paid</span>
                        <?php endif; ?>

                        </td>
                </tr>    
                    <?php endfor; ?>              
                </tbody>                
            </table>        
                </td>
                <td style="vertical-align: top;">
                    <?php if($i<$c): ?>
            <table class="table2" style="width:100%;">
                <thead>
                <tr>
                    <th>
                        Sl
                    </th>
                    <th>
                    EMI  Date
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Fine
                    </th>
                    <th>
                        Paid Amount
                    </th>
                    <th>
                        Due Amount
                    </th>
                    <td>
                        status
                    </td>
                </tr>
    
                </thead>
                <tbody id="tbEMI">
                    
                    <?php for(; $i<$c;): ?>
                    $ec=$emi_collections[$i];

                <tr>
                        <td>
                            <?php echo e(++$i); ?>

                        </td>
                        <td>
                            <?php echo e($ec->emi_date); ?>

                        </td>
                        <td>
                            <?php echo e($ec->emi_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->fine_amount); ?>

                        </td>
                        <td>
                            <?php echo e($ec->paid_amt); ?>

                        </td>
                        <td>
                            <?php echo e($ec->due_amt); ?>

                        </td>
                        <td class="text-success">
                    <?php if($current_emi_no==$ec->id): ?>
                        Paid
                    <?php endif; ?>
                        </td>
                </tr>    
                    <?php endfor; ?>              
                </tbody>                
            </table>
                <?php endif; ?>
                </td>
            </tr>
        </table>        
            
        </td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.pdf_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/print_emi.blade.php ENDPATH**/ ?>