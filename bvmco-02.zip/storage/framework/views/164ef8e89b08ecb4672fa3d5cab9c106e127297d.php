;
<?php $__env->startSection('page_title','Sale Agent Password Change successfully'); ?>
<?php $__env->startSection('login_select','active'); ?>
<?php $__env->startSection('container'); ?>
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> Sale Agent Password changed Successfully</h1>   
        <div class="container">
           <?php if(session('error')): ?>
<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
<?php endif; ?>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label"><?php echo e($name); ?> </label>
              </div>
              Now go to <a href="/"> Home </a> and login again
              <input type="hidden" name="id" value="<?php echo e($id); ?>">
            </div>
        </div>
     
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/sale_agent_password_change_success.blade.php ENDPATH**/ ?>