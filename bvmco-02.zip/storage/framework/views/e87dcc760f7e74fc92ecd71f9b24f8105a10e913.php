;
<?php $__env->startSection('page_title','EMI List'); ?>
<?php $__env->startSection('emi_list','active'); ?>
<?php $__env->startSection('master_tran','report'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($ADMIN_TYPE=session()->get('ADMIN_TYPE')); ?>

</span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script> 
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      

<h2 class="title-1 m-b-10">EMI List</h2>

<div class="row">
    <div class="col-3 d-none">
<a href='<?php echo e(url("$typeName/emis/edit_collection")); ?>' >
<button type="button" class="btn btn-success">Collect EMI</button>
</a>

    </div>
    <div class="col-2 d-none">
<a href='<?php echo e(url("$typeName/order/trash")); ?>' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()"><?php echo e($a_search_text); ?></a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style=<?php echo e($displaySearch); ?> >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Bill Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="bill_id" id="bill_id" class="form-control" placeholder="Bill Id" value="<?php echo e($bill_id); ?>">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($product_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="product_ids" name="product_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Products)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $product_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
                      </div>
<div class="row py-1">
                        <div class="col-lg-3">
                          Due Date From
                        <a href="javascript:void(0)" onclick="clear_due_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Due_Date_From" id="Due_Date_From" class="form-control" placeholder="EMI Due Date from" value="<?php echo e($Due_Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         Due Date to
                         <a href="javascript:void(0)" onclick="clear_due_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Due_Date_To" id="Due_Date_To" placeholder="EMI Due Date To" value="<?php echo e($Due_Date_To); ?>" class="form-control">
                        </div>
                      </div>
<div class="row py-1">
                        <div class="col-lg-3">
                          Collection Date From
                        <a href="javascript:void(0)" onclick="clear_collect_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Collect_Date_From" id="Collect_Date_From" class="form-control" placeholder="EMI Collection Date from" value="<?php echo e($Collect_Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         EMI Collection Date to
                         <a href="javascript:void(0)" onclick="clear_collect_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Collect_Date_To" id="Collect_Date_To" placeholder="EMI Collection Date To" value="<?php echo e($Collect_Date_To); ?>" class="form-control">
                        </div>
                      </div>      
<div class="row py-1">
                        <div class="col-lg-3">
                          Receive Date From
                        <a href="javascript:void(0)" onclick="clear_receive_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Receive_Date_From" id="Receive_Date_From" class="form-control" placeholder="EMI Receive Date from" value="<?php echo e($Receive_Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         EMI Receive Date to
                         <a href="javascript:void(0)" onclick="clear_receive_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Receive_Date_To" id="Receive_Date_To" placeholder="EMI Receive Date To" value="<?php echo e($Receive_Date_To); ?>" class="form-control">
                        </div>
                      </div>                                          
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="<?php echo e($cust_name); ?>">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="<?php echo e($cust_mobile); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                    
                        <div class="col-lg-3">
                          Village
                          <?php if($ADMIN_TYPE !=4): ?>
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          <?php endif; ?>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($village_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="village_ids" name="village_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Villages)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $village_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>    
</div>
<div class="col-lg-3">

                      Sale agents
                      <?php if($ADMIN_TYPE !=4): ?>
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                    <?php endif; ?>
</div>
<div class="col-lg-3">

<div class="form-group">
<?php if(count($sale_agent_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>
<select id="sale_agent_ids" name="sale_agent_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($SalesAgents)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $SalesAgents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $sale_agent_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
<div class="col-6 text-right"></div>
<div class="col-6 text-right">
<input type="radio" name="rdb" id="rdb1" value="1" <?php if($rdb==1): ?>checked <?php endif; ?>><label for="rdb1" class="btn btn-success"> Not Collected</label>
<input type="radio" name="rdb" id="rdb2" value="2" <?php if($rdb==2): ?>checked <?php endif; ?>><label class="btn btn-primary" for="rdb2"> Collected</label>
<input type="radio" name="rdb" id="rdb3" value="3" <?php if($rdb==3): ?>checked <?php endif; ?>><label for="rdb3" class="btn btn-danger"> Received</label>
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="<?php echo e($rows); ?>" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='<?php echo e(url("$typeName/emis")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<a href='<?php echo e(url("/EMIExport")); ?>?<?php echo e($getURL); ?>' >
<button type="button" class="btn btn-primary">Export to Excel</button>
</a>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                            <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th style="display: none;">Action</th>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Paid Amount</th>
                                            <th>Cash</th>
                                            <th>Bank</th>
                                            <th>Due Amount</th>
                                            <th>Due Date</th>
                                            <th>Collect Date</th>
                                            <th>Receive Date</th>
                                            <th>Remarks</th>
                                            </tr>
             
                                        </thead>
                                        <tbody>
                                <?php $__currentLoopData = $emi_collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="display:none;">
                                        
                                    <?php if($ADMIN_TYPE==1): ?>
                                <a href='<?php echo e(url("$typeName/emis/emi_collection")); ?>/<?php echo e($list->id); ?>'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;View EMI&nbsp;&nbsp;</button>
                                    </a>
                                    <?php elseif($ADMIN_TYPE==3): ?>
                                    <a href='<?php echo e(url("$typeName/emis/emi_collection")); ?>/<?php echo e($list->id); ?>'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Recieve EMI&nbsp;&nbsp;</button>
                                    </a>
                                    <?php elseif($ADMIN_TYPE==4): ?>
                                     <?php if($list->collect_time==''): ?>
                                    <a href='<?php echo e(url("$typeName/emis/emi_collection")); ?>/<?php echo e($list->id); ?>'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Collect EMI&nbsp;&nbsp;</button>
                                    </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    </td>
                                    <td><?php echo e($list->bill_id); ?>

                                    </td>
                                    <td><?php echo e($list->emi_date); ?></td>
                    <td>                                       <?php echo e($list->getBills[0]->getCustomers[0]->name); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->getVillages[0]->name??''); ?></td>
                    <td><?php echo e($list->getBills[0]->getCustomers[0]->mobile??''); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_Loan); ?></td>
                    <td style="text-align:right;"><?php echo e($list->EMI_interest); ?></td>
                    <td style="text-align:right;"><?php echo e($list->emi_amount); ?></td>
                    <td style="text-align:right;"><?php echo e($list->fine_amount); ?></td>
                    <td style="text-align:right;"><?php echo e($list->paid_amt); ?></td>
                    <td style="text-align:right;"><?php echo e($list->cash); ?></td>
                    <td style="text-align:right;"><?php echo e($list->bank); ?></td>
                    <td style="text-align:right;"><?php echo e($list->due_amt); ?></td>
                    <td><?php echo e($list->emi_date); ?></td>
                    <td><?php echo e($list->collect_time); ?></td>
                    <td><?php echo e($list->receive_time); ?></td>
                    <td><?php echo e($list->remarks); ?></td>
                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($emi_collections->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Due_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Due_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#Collect_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Collect_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


$('#Receive_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Receive_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

<?php if($Due_Date_From==''): ?>
    $('#Due_Date_From').val('');
<?php endif; ?>
<?php if($Due_Date_To==''): ?>
    $('#Due_Date_To').val('');
<?php endif; ?>

<?php if($Collect_Date_From==''): ?>
    $('#Collect_Date_From').val('');
<?php endif; ?>
<?php if($Collect_Date_To==''): ?>
    $('#Collect_Date_To').val('');
<?php endif; ?>

<?php if($Receive_Date_From==''): ?>
    $('#Receive_Date_From').val('');
<?php endif; ?>
<?php if($Receive_Date_To==''): ?>
    $('#Receive_Date_To').val('');
<?php endif; ?>
});


function clear_due_date_from()
    {
    $('#Due_Date_From').val('');
    }
function clear_due_date_to()
    {
    $('#Due_Date_To').val('');
    }

function clear_collect_date_from()
    {
    $('#Collect_Date_From').val('');
    }
function clear_collect_date_to()
    {
    $('#Collect_Date_To').val('');
    }

function clear_receive_date_from()
    {
    $('#Receive_Date_From').val('');
    }
function clear_receive_date_to()
    {
    $('#Receive_Date_To').val('');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/emi_list.blade.php ENDPATH**/ ?>