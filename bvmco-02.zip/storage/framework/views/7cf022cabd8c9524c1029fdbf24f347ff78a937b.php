;
<?php $__env->startSection('page_title','Order'); ?>
<?php $__env->startSection('bill_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

</span>
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Bill Trash</h2>
<a href='<?php echo e(url("$typeName/bills")); ?>' >
<button type="button" class="btn btn-success">Go to Bill</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Bill date</th>
                                                <th>Customer ID</th>
                                            <th>Customer Name</th>
                                                <th>Address</th>
                                                <th>Sale Price</th>
                                            <th>Down Payment</th>
                                                <th>EMI</th>
                                                <th>EMI Mode</th>
                                                <th>EMI Period</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href='<?php echo e(url("$typeName/bill/restore")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    
                                                    <a href='<?php echo e(url("$typeName/bill/forceDelete")); ?>/<?php echo e($list->id); ?>'>
                                                    <button type="button" class="btn btn-danger">&nbsp;Delete&nbsp;</button>
                                                    </a>
                                                    
                                                </td>
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->bill_date); ?></td>
                                                <td><?php echo e($list->customer_id); ?></td>
                                                <td><?php echo e($list->getCustomers[0]->name); ?></td>
                                                <td><?php echo e($list->getCustomers[0]->address); ?></td>
                                                <td><?php echo e($list->sale_price); ?></td>
                                                <td><?php echo e($list->down_payment); ?></td>
                                                <td><?php echo e($list->EMI); ?></td>
                                                <td><?php $__currentLoopData = $calcmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($list->EMI_mode==$list1->id): ?>
                                                        <?php echo e($list1->name); ?>

                                                    <?php break; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                                <td><?php echo e($list->EMI_Period); ?></td>
                                                
                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/bill-trash.blade.php ENDPATH**/ ?>