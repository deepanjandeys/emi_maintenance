;
<?php $__env->startSection('page_title','Village'); ?>
<?php $__env->startSection('Village_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

</span>
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>


<?php if(session('error')): ?>
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  <?php echo e(session('error')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<h2 class="title-1 m-b-10">Village</h2>
<div class="row">
    <div class="col-3">
<a href='<?php echo e(url("$typeName/village/edit_village")); ?>' >
<button type="button" class="btn btn-success">Add Village</button>
</a>
    
    </div>
    <div class="col-2">
<a href='<?php echo e(url("$typeName/village/trash")); ?>' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="<?php echo e($rows); ?>" size="2"> per page
            <input type="search" name="search" class="form-control" placeholder="search by village name" value="<?php echo e($search); ?>">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href='<?php echo e(url("$typeName/village")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
<div class="row m-t-30">
<div class="col-md-12">
<!-- DATA TABLE-->
<div class="table-responsive m-b-40">
<table class="table table-borderless table-data3">
<thead>
<tr>
<th rowspan="2">Action</th>
<th rowspan="2">ID</th>
<th rowspan="2">Name</th>
<th rowspan="2">PIN</th>
<th rowspan="2">District</th>
<th rowspan="2">Sub-Division</th>
<th rowspan="2">Village Agent Name</th>
<th rowspan="2">Address</th>
<th rowspan="2">PIN</th>
<th rowspan="2">Mobile</th>
<th colspan="2">ID Proof</th>
<th colspan="2">Address Proof</th>
<th rowspan="2">Status</th>
</tr>
<tr>
<th>type</th>
<th>Image</th>
<th>Type</th>
<th>Image</th>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $village; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td>
<a href='<?php echo e(url("$typeName/village/edit_village/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
</a>
<a href='<?php echo e(url("$typeName/village/delete/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-danger">Trash</button>
</a>
</td>
<td><?php echo e($list->id); ?></td>
<td><?php echo e($list->name); ?></td>
<td><?php echo e($list->pin); ?></td>
<td><?php echo e($list->district); ?></td>
<td><?php echo e($list->sub_division); ?></td>
<td><?php echo e($list->VillageAgents->name); ?></td>
<td><?php echo e($list->VillageAgents->address); ?></td>
<td><?php echo e($list->VillageAgents->pin); ?></td>
<td><?php echo e($list->VillageAgents->mobile); ?></td>
<td>
<?php $__currentLoopData = $id_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($list->VillageAgents->IdProofType==$list1->id): ?>
    <?php echo e($list1->name); ?>

    <?php break; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td>
<img src="<?php echo e(asset('/storage/media').'/'.$list->VillageAgents->IdProofImage); ?>" alt="<?php echo e(asset('/storage/media').'/'.$list->VillageAgents->IdProofImage); ?>" style="width:100px;height:100px;" />
</td>
<td>
<?php $__currentLoopData = $address_proof_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($list->VillageAgents->AddressProofType == $list1->id): ?>
    <?php echo e($list1->AddressProofType); ?>

    <?php break; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</td>
<td>
<img src="<?php echo e(asset('/storage/media').'/'.$list->VillageAgents->AddressProofImage); ?>" alt="<?php echo e(asset('/storage/media').$list->VillageAgents->AddressProofImage); ?>" style="width: 100px;height: 100px;" />
</td>
<td>
<?php if($list->status==1): ?>
<span class="text-primary"> Active</span>
<a href='<?php echo e(url("$typeName/village/status/0/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-warning">Deactivate</button>
</a>
<?php elseif($list->status==0): ?>
<span class="text-danger">Inactive</span>
<a href='<?php echo e(url("$typeName/village/status/1/")); ?>/<?php echo e($list->id); ?>'>
<button type="button" class="btn btn-primary">Activate</button>
</a>
<?php endif; ?>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<?php echo e($village->links()); ?>

<!-- END DATA TABLE-->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/village.blade.php ENDPATH**/ ?>