;
<?php $__env->startSection('page_title','Place Order'); ?>
<?php $__env->startSection('order_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
    <?php echo e($typeName=session()->get('typeName')); ?>

    <?php echo e($AJAX_ROOT=Config::get('constants.AJAX_ROOT')); ?>

</span>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      

<h2 class="title-1 m-b-10">Place Order </h2>
<a href='<?php echo e(url("$typeName/orders")); ?>' >
<button type="button" class="btn btn-success">Back</button>
</a>
<script type="text/javascript">
function getCustomerDetails(value) {
   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/getCustomerDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
         $('#Customer_name').html(obj.name);
         $('#address').html(obj.address);
         $('#mobile').html(obj.mobile);
          $('#spnCustImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
        }
        else 
        {
         $('#Customer_name').html('');
         $('#address').html('');
         $('#mobile').html('');      
          $('#spnCustImage').html('');
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function getSaleAgentDetails(value) {
   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/getSaleAgentDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnName').html('<b>Name : </b>'+obj.name);
            $('#spnAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnMobile').html(' <b>Mobile</b> :'+obj.mobile);
         /*   $('#spnBranch').html(' <b>Branch ID :</b>'+obj.branch_id + ' <b> Branch Name </b>'+obj.branch_name);
            $('#branch_id').val(obj.branch_id);
            */
        }
        else
        {
            $('#spnName').html('');
            $('#spnAddress').html('');
            $('#spnMobile').html('');
            //$('#spnBranch').html('');
            //$('#branch_id').val(0);
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/getProductDetails',
    data: { id: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnCategory').html(' <b>GroupId</b> :'+obj.GroupId);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#sale_price').val(obj.MRP);
            $('#spnLoanType').html('<b>Loan Type : </b> '+obj.loan_type_name);
            if(obj.loan_type==1)
            {
                $('#divIntest').hide();
            }
            else 
            {
                $('#divIntest').show();
            }
            $('#spnDescrption').html(obj.description);
            getStockDetails();
            //calculate_LoanAmount();
            //calculate_EMI();
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnCategory').html('');
            $('#spnProdGroupName').html('');
            $('#sale_price').val('');
            $('#spnLoanType').html('');
            $('#spnDescrption').html('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function getStockDetails() {
//debugger;
    var branch_id=$('#branch_id').val();
    var product_id =$('#product_id').val();
   $.ajax({
    type: "POST",
    url: '/<?php echo e($AJAX_ROOT); ?>/getStockDetails',
    data: { branch_id: branch_id, product_id:product_id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
          $('#spnAvlStock').html('<span style="color:green;font-weight:bold;">Available stock </span>'+'<span style="color:blue;font-weight:bold;" id="spnAvlStockQty">'+obj.stock+'</span>');
          //$('#submit-button').show();
        }
        else
        {
           $('#spnAvlStock').html('<span style="color:red;font-weight:bold;">stock is not Available </span>');
           //$('#submit-button').hide();
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
function calculate_LoanAmount()
{
    console.log('calculate_LoanAmount');
    var sale_price  = parseFloat($('#sale_price').val());
    if(isNaN(sale_price))
        sale_price=0;

    var down_payment= parseFloat($('#down_payment').val());
    if(isNaN(down_payment))
        down_payment=0;
    var LoanAmount  = sale_price - down_payment;

    $('#LoanAmount').val(LoanAmount);
    calculate_Interest();
}

function calculate_Interest()
{
    //debugger;
    console.log('calculate_Interest');
    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;
    
    var interestPercntage  = parseInt($('#interestPercntage').val());
    if(isNaN(interestPercntage))
        interestPercntage=0;
  
    var IntOnLoan   = 0;
    if(interestPercntage>0)
        IntOnLoan=LoanAmount * interestPercntage /100;


    $('#IntOnLoan').val(IntOnLoan.toFixed(2));
    calculate_EMI();
}

function calculate_EMI(calcu_emi_period=true)
{    
        //debugger;
    console.log('calculate_EMI');

    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;

    var IntOnLoan   = parseFloat($('#IntOnLoan').val());
    if(isNaN(IntOnLoan))
        IntOnLoan=0;
    
    var EMI_in_Months   = parseInt($('#EMI_in_Months').val());
    if(isNaN(EMI_in_Months))
        EMI_in_Months=0;
    
    var EMI_mode    = $('#EMI_mode').val();
    var EMI_Period=1;
    var EMI=0;
    var EMI_Interest=0;

    if(!calcu_emi_period)
    {
    EMI_Period=$('#EMI_Period').val();     
    }

    if(EMI_mode==1)
    {   // daily
        if(calcu_emi_period) EMI_Period =EMI_in_Months*30;
        EMI_Interest=IntOnLoan/30;
    }
    else if(EMI_mode==2)
    {
        // weekly
        if(calcu_emi_period) EMI_Period =EMI_in_Months*4;
        EMI_Interest=IntOnLoan/4;
    }
    else if(EMI_mode==3)
    {
        // Fort night
        if(calcu_emi_period) EMI_Period =EMI_in_Months*2;
        EMI_Interest=IntOnLoan/2;
    }
    else if(EMI_mode==4)
    {
        // Mobthly
        if(calcu_emi_period) EMI_Period =EMI_in_Months;
        EMI_Interest=IntOnLoan;
    }
var EMI_Loan=LoanAmount / EMI_Period;

    EMI=EMI_Loan+EMI_Interest;

    $('#spnEMI_Loan').html(EMI_Loan.toFixed(2));
    $('#spnEMI_Interest').html(EMI_Interest.toFixed(2));
    $('#hdEMI_Loan').val(EMI_Loan.toFixed(2));
    $('#hdEMI_Interest').val(EMI_Interest.toFixed(2));
    
    $('#EMI').val(EMI.toFixed(2));
    //calculate_Interest();
    if(calcu_emi_period) $('#EMI_Period').val(EMI_Period);
    
    //calculate_Interest();  
    calculate_EMI_list();
    //calculate_EMI_period();
}

</script>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action='<?php echo e(route("$typeName.manage_order_process")); ?>' method="post">
<?php echo csrf_field(); ?>
<div class="form-group">
<label for="order_date" class="control-label mb-1">Order Date</label>
<input id="order_date" name="order_date" type="text" value="<?php echo e($order_date); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['order_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="customer_id" class="control-label mb-1">Customer</label>
<input list="customers" id="customer_id" name="customer_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getCustomerDetails(this.value)" required>
<datalist id="customers">
<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="row">
<div class="col-8">
    <div class="row">
    <div class="col-3 font-weight-bold">Name</div>
    <div class="col-3" id="Customer_name"></div>
    <div class="col-3 font-weight-bold">Mobile</div>
    <div class="col-3" id="mobile" ></div>    
    </div>
    <div class="row">
    <div class="col-3 font-weight-bold">Address</div>
    <div class="col-9" id="address"></div>    
    </div>
</div>
<div class="col-4" id="spnCustImage"></div>
</div>
<hr>
<div class="form-group">
<label for="Sale_agent_id" class="control-label mb-1">Sale agent id</label>
<input list="SaleAgents" id="Sale_agent_id" name="Sale_agent_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getSaleAgentDetails(this.value)" required>
<datalist id="SaleAgents">
<?php $__currentLoopData = $sales_agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<span id="spnName"></span>
<span id="spnAddress"></span>
<span id="spnMobile"></span>
<span id="spnBranch"></span>
<?php $__errorArgs = ['Sale_agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<hr>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
<datalist id="products">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</datalist>
<div class="row">
    <div class="col-8">
        <div class="row">
            <div class="col-6" id="spnProdName">
                
            </div>
            <div class="col-6" id="spnCode">
                
            </div>
        </div>
        <div class="row">
            <div class="col-6" id="spnCategory">
                
            </div>
            <div class="col-6" id="spnProdGroupName">
                
            </div>
        </div>
        <div class="row">
            <div class="col-6" id="spnLoanType">
                
            </div>
            <div class="col-6"></div>
        </div>
    </div>
    <div class="col-4" id="spnImage">
        
    </div>
</div>
<?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<span id="spnAvlStock"></span>
<span class="text-primary font-weight-bold">Description : </span>
<span id="spnDescrption"></span>
<div class="form-group">
<label for="sale_price" class="control-label mb-1">Product price</label>
<input id="sale_price" name="sale_price" type="text" value="<?php echo e($sale_price); ?>" class="form-control" onchange="calculate_LoanAmount()" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['sale_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="down_payment" class="control-label mb-1">Down payment</label>
<input id="down_payment" name="down_payment" type="text" value="<?php echo e($down_payment); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_LoanAmount()" required>
<?php $__errorArgs = ['down_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="LoanAmount" class="control-label mb-1">Loan Amount</label>
<input id="LoanAmount" name="LoanAmount" type="number" value="<?php echo e($LoanAmount); ?>" class="form-control" aria-required="true" aria-invalid="false" required onchange="calculate_EMI()">
<?php $__errorArgs = ['LoanAmount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="EMI_in_Months" class="control-label mb-1">EMI in Months</label>
<input id="EMI_in_Months" name="EMI_in_Months" type="number" value="<?php echo e($EMI_in_Months); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<?php $__errorArgs = ['EMI_in_Months'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="form-group">
<label for="EMI_mode" class="control-label mb-1">EMI Mode</label>
<select id="EMI_mode" name="EMI_mode" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<option value="">select</option>
<?php $__currentLoopData = $calcmode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($EMI_mode==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['EMI_mode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="EMI_Period" class="control-label mb-1">EMI_Period</label>
<input id="EMI_Period" name="EMI_Period" type="text" value="<?php echo e($EMI_Period); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI(false)" required>
<?php $__errorArgs = ['EMI_Period'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group" id="divIntest">
<label for="interestPercntage" class="control-label mb-1">Interest Percentage (%)</label>
<input id="interestPercntage" name="interestPercntage" type="number" value="<?php echo e($interestPercntage); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_Interest()" required>
<?php $__errorArgs = ['interestPercntage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="IntOnLoan" class="control-label mb-1">Monthly Interest</label>
<input id="IntOnLoan" name="IntOnLoan" type="text" value="<?php echo e($IntOnLoan); ?>" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<?php $__errorArgs = ['IntOnLoan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="form-group">
<label for="EMI" class="control-label mb-1">EMI</label>
<input id="EMI" name="EMI" type="text" value="<?php echo e($EMI); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<span class="text-primary">EMI Loan <span  id="spnEMI_Loan" class="text-danger"><?php echo e($EMI_Loan); ?></span><input id="hdEMI_Loan" name="EMI_Loan" type="hidden" value="<?php echo e($EMI_Loan); ?>"></span>
<span class="text-primary">EMI Interest <span id="spnEMI_Interest" class="text-danger"><?php echo e($EMI_Interest); ?></span><input id="hdEMI_Interest" name="EMI_Interest" type="hidden" value="<?php echo e($EMI_Interest); ?>"></span>
<?php $__errorArgs = ['EMI'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="booking_advance" class="control-label mb-1">Booking Advance</label>
<input id="booking_advance" name="booking_advance" type="text" value="<?php echo e($booking_advance); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['booking_advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div>

<button id="submit-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" id="id" name="id" value="<?php echo e($id); ?>" >
<input type="hidden" id="branch_id" name="branch_id" value="1" >
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">

docReady(function() {
    // DOM is loaded and ready for manipulation here
    getCustomerDetails(<?php echo $customer_id; ?>);
    getSaleAgentDetails(<?php echo $Sale_agent_id; ?>);
    getProductDetails(<?php echo $product_id; ?>);
    $('#customer_id').val(<?php echo $customer_id; ?>);
    $('#product_id').val(<?php echo $product_id; ?>);
    $('#Sale_agent_id').val(<?php echo $Sale_agent_id; ?>);


$('#order_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/place_Order.blade.php ENDPATH**/ ?>