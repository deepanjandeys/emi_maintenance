;
<?php $__env->startSection('page_title','Edit Sales Agent'); ?>
<?php $__env->startSection('sale_agent_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"> 
<?php if($id>0): ?>
    <?php echo e($password_required=""); ?>

    <?php echo e($password_class="d-none"); ?>

<?php else: ?>
    <?php echo e($password_required="required"); ?>

    <?php echo e($password_class=""); ?>

<?php endif; ?>
</span>
<script type="text/javascript">
function getCheckMobileUnique(value) {
   $.ajax({
    type: "POST",
    url: '/getCheckMobileUnique',
    data: { mobile: value, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html(obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function setDefaultPasswordSA(id) {
    if (confirm("do You wabt to reset password to default password !") == false) 
    { 
  return;
    } 
   $.ajax({
    type: "POST",
    url: '/setDefaultPasswordSA',
    data: { id: id, _token: '<?php echo e(csrf_token()); ?>' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
<?php if($errors->any()): ?>
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
<?php endif; ?>      

<h2 class="title-1 m-b-10">Edit Sales Agent</h2>
<a href="<?php echo e(url('admin/sale_agent')); ?>" >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
<form action="<?php echo e(route('product.manage_sale_agent_process')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="form-group">
<label for="SaleAgent_name" class="control-label mb-1">Sales Agent Name</label>
<input id="SaleAgent_name" name="name" type="text" value="<?php echo e(old('name', $name)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">address</label>
<input id="address" name="address" type="text" value="<?php echo e(old('address', $address)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="pin" class="control-label mb-1">pin</label>
<input id="pin" name="pin" type="text" value="<?php echo e(old('pin', $pin)); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="mobile" class="control-label mb-1">mobile</label>
<input id="mobile" name="mobile" type="text" value="<?php echo e(old('mobile', $mobile)); ?>" class="form-control" onchange="getCheckMobileUnique(this.value)" aria-required="true" aria-invalid="false" required>
<span id="spnIsMobileNoUsedEarlier" class="text-danger font-weight-bold"style="display:none;"></span>
<?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
<label for="email" class="control-label mb-1">email</label>
<input id="email" name="email" type="text" value="<?php echo e(old('email', $email)); ?>" class="form-control" aria-required="true" aria-invalid="false" >
<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<?php if($id==0): ?>
<div class="form-group <?php echo e($password_class); ?>">
<label for="password" class="control-label mb-1">Password</label>
<input id="password" name="password" type="text" value="<?php echo e($password); ?>" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php else: ?>
<a href="javascript:void(0)" 
  onclick="setDefaultPasswordSA(<?php echo e($id); ?>)">Reset Password</a>
<div id="divPwd<?php echo e($id); ?>"></div>
<?php endif; ?>


<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
<?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($status==$list->id): ?>
<option selected value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php else: ?>
<option value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger" role="alert">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="<?php echo e($id); ?>">
<input type="hidden" name="admin_id" value="<?php echo e($admin_id); ?>">
</form>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/edit_SalesAgent.blade.php ENDPATH**/ ?>