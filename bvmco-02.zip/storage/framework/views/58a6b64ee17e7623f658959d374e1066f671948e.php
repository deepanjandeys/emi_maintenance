;
<?php $__env->startSection('page_title','Order'); ?>
<?php $__env->startSection('BranchStock_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"><?php echo e($typeName=session()->get('typeName')); ?></span>
<script type="text/javascript">
function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            //$('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            //$('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script>
<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button> 
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Stock Transfer details</h2>
<div class="row">
    <div class="col-3">
        <a href="<?php echo e(url('admin/branchStock')); ?>" >
<button type="button" class="btn btn-success">Back</button>
</a>
    
    </div>
    <div class="col-2">
    
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()"><?php echo e($a_search_text); ?></a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style=<?php echo e($displaySearch); ?> >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Quantity
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                            <div class="row">
                                <div class="col-5">
                                <select id="operator" name="operator" class="form-control w-100" aria-required="true" aria-invalid="false" >
                        <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($operator==$list->name): ?>
                                <?php echo e($s='selected'); ?>

                            <?php else: ?> 
                                <?php echo e($s=''); ?>

                            <?php endif; ?>
    <option <?php echo e($s); ?> value="<?php echo e($list->name); ?>"><?php echo e($list->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>                            
                                </div>
                                <div class="col-7">
<input type="text" name="quantity" id="quantity" class="form-control" placeholder="Quantity" value="<?php echo e($quantity); ?>">
    
                                </div>
                            </div>
        
                        </div>
<div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
<?php if(count($product_ids)>1): ?>
    <?php echo e($m='multiple'); ?>

<?php else: ?>
    <?php echo e($m=''); ?>

<?php endif; ?>


<select id="product_ids" name="product_ids[]" <?php echo e($m); ?> class="form-control" aria-required="true" aria-invalid="false" >
<?php if(count($Products)>1): ?>
<option value="">(all) </option>
<?php endif; ?>
<?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($s=''); ?> 
    <?php $__currentLoopData = $product_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($list1==$list->id): ?>
            <?php echo e($s='selected'); ?>

            <?php break; ?>;
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<option <?php echo e($s); ?> value="<?php echo e($list->id); ?>"><?php echo e($list->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="Order Date from" value="<?php echo e($Date_From); ?>">
                        </div>
                        <div class="col-lg-3">
                         Date to
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="Order Date To" value="<?php echo e($Date_To); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
      
<div class="col-6 text-right">
    <button class="btn btn-primary">Search</button>   
    <a href='<?php echo e(url("$typeName/orders")); ?>' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>

 <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Branch</th>
                                                <th>Product</th>
                                                <th>Qty</th>
                                                <th>Date</th>
                                                <th>Current Stock</th>
                                                <th>Mode</th>
                                                <th>last Updated</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $branchStockDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->getBranch[0]->name); ?></td>
                                                <td><?php echo e($list->getProduct[0]->name); ?></td>
                                                <td><?php echo e($list->qty); ?></td>
                                                <td><?php echo e($list->txn_date); ?></td>
                                                <td><?php echo e($list->current_stock); ?></td>
                                                <td>
                                                    <?php if($list->mode==1): ?>
                                                    <span class="text-primary"> Purchase</span>
                                                   
                                                    <?php elseif($list->mode==2): ?>
                                                    <span class="text-danger"> sale</span>
                                                    <?php elseif($list->mode==3): ?>
                                                    <span class="text-primary font-weight-bold"> return </span>
                                                    <?php elseif($list->mode==4): ?>
                                                    <span class="text-success"> bill restored</span>
                                                    <?php endif; ?>
                                                    </td>
                                                <td><?php echo e($list->updated_at); ?></td>
                                                
                            
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($branchStockDetails->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u537469000/domains/bvmco.in/public_html/resources/views/admin/branchStockDetails.blade.php ENDPATH**/ ?>