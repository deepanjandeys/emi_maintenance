;
<?php $__env->startSection('page_title','BranchStock'); ?>
<?php $__env->startSection('BranchStock_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>
<h2 class="title-1 m-b-10">Stock</h2>
<div class="row">
    <div class="col-2">
<a href="<?php echo e(url('admin/branchStock/purchase')); ?>" >
<button type="button" class="btn btn-success">Purchase</button>
</a>
    
</div>
<div class="col-2">
<a href="<?php echo e(url('admin/branchStock/stockTransfer')); ?>" class="d-none">
<button type="button" class="btn btn-success">Stock Transfer</button>
</a>
</div>
<div class="col-2">
<a href="<?php echo e(url('admin/branchStockDetails')); ?>" >
<button type="button" class="btn btn-warning">Transaction Details</button>
</a>
</div>
<div class="col-6 d-none">
<form action="" method="get" >
    <div class="row">
        <div class="col-6">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="<?php echo e($search); ?>">        
        </div>
        <div class="col-6">
        <button class="btn btn-primary">Search</button>   
        <a href="<?php echo e(url('admin/branch')); ?>" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Branch</th>
                                                <th>Product</th>
                                                <th>Stock</th>
                                        <th>last Updated</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $BranchStock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->getBranch[0]->name); ?></td>
                                                <td><?php echo e($list->getProduct[0]->name); ?></td>
                                                <td><?php echo e($list->stock); ?></td>
                                                <td><?php echo e($list->updated_at); ?></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($BranchStock->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/branchStock.blade.php ENDPATH**/ ?>