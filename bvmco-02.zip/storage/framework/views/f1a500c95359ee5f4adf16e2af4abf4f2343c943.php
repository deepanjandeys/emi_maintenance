;
<?php $__env->startSection('page_title','Sales Agent'); ?>
<?php $__env->startSection('sale_agent_select','active'); ?>
<?php $__env->startSection('master_tran','master'); ?>
<?php $__env->startSection('container'); ?>

<?php if(session()->has('message')): ?>
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  <?php echo e(session('message')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  <?php echo e(session('error')); ?>

<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
<?php endif; ?>

<h2 class="title-1 m-b-10">Sales Agent</h2>
<div class="row">
    <div class="col-3">
<a href="<?php echo e(url('admin/sale_agent/edit_sale_agent')); ?>" >
<button type="button" class="btn btn-success">Add Sales Agent</button>
</a>
    
    </div>
    <div class="col-2">
<a href="<?php echo e(url('admin/sale_agent/trash')); ?>" >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="<?php echo e($search); ?>">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="<?php echo e(url('admin/sale_agent')); ?>" >
            <button type="button" class="btn btn-primary">reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th>Action</th>
                                               <th>ID</th>
                                                <th>Name</th>
                                                <th>Address</th>
                                                <th>PIN</th>
                                                <th>Mobile</th>
                                                <th>status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $salesAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="<?php echo e(url('admin/sale_agent/edit_sale_agent/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                                    </a>
                                                    
                                                    <a href="<?php echo e(url('admin/sale_agent/delete/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                </td>
                                                <td><?php echo e($list->id); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->address); ?></td>
                                                <td><?php echo e($list->pin); ?></td>
                                                <td><?php echo e($list->mobile); ?></td>
                                                <td>
                                                    <?php if($list->status==1): ?>
                                                    <span class="text-primary"> Active</span>
                                                    <a href="<?php echo e(url('admin/sale_agent/status/0/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-warning">Deactivate</button>
                                                    </a>
                                                    <?php elseif($list->status==0): ?>
                                                    <span class="text-danger">Inactive</span>
                                                    <a href="<?php echo e(url('admin/sale_agent/status/1/')); ?>/<?php echo e($list->id); ?>">
                                                    <button type="button" class="btn btn-primary">Activate</button>
                                                    </a>
                                                    <?php endif; ?>
                                                    
                                                </td>
                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>
                                <?php echo e($salesAgent->links()); ?>

                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/salesAgent.blade.php ENDPATH**/ ?>