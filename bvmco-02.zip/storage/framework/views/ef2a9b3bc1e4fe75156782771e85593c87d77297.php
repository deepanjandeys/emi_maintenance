;
<?php $__env->startSection('page_title','EMI Submitted'); ?>
<?php $__env->startSection('emi_select','active'); ?>
<?php $__env->startSection('master_tran','transaction'); ?>
<?php $__env->startSection('container'); ?>
<span class="d-none"><?php echo e(@$typeName=session()->get('typeName')); ?>    </span> 
	<div class="row">
			<h2 class="title-1 m-b-10"><?php echo e(Config::get('constants.SITE_NAME')); ?> EMI Submitted</h2>
<br>
        <div class="col-lg-12">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
<a href='<?php echo e(url("$typeName/emis/print_emi")); ?>/<?php echo e($emi_id); ?>' target="_blank">
                                                    <button type="button" class="btn btn-primary">&nbsp;Download Reciept&nbsp;</button>
                                                    </a>
                                                 
     		</div>
         </div>
     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\bvmco\resources\views/admin/emi_submitted.blade.php ENDPATH**/ ?>