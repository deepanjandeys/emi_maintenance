<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{Config::get('constants.SITE_NAME')}} </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style type="text/css">
.gradient-custom {
/* fallback for old browsers */
background: #6a11cb;

/* Chrome 10-25, Safari 5.1-6 */
background: -webkit-linear-gradient(to right, rgba(252, 243, 203, 1), rgba(240, 252,207, 1));

/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
background: linear-gradient(to right, rgba(252, 243, 203, 1), rgba(240,252,207, 1))
}
</style>
  </head>
  <body>
  <h1 style="background-color: #98144D;text-align: center; color: white;"> {{Config::get('constants.SITE_NAME')}}</h1>
  <section class="vh-100 gradient-custom">
  <div class="container py-5">
    <div class="row d-flex justify-content-center align-items-center h-100">

      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card bg-light" style="border-radius: 1rem;color:#98144D;">
          <div class="card-body p-3 text-center">

            <div class="mb-md-3 mt-md-1 pb-1">

              <h2 class="fw-bold mb-2 text-uppercase"><i class="bi bi-person-fill-lock"></i>Login </h2>
              
              <img src="{{asset('admin_assets/images/icon/xcl_lock.png')}}" alt="BVMCO Lock" style="width:50px;" />

              <div data-mdb-input-init class="form-outline form-white my-4">
  <a href="/sale_agent" class="btn w-100" style="background-color:#98144D;color: white;"><h2>Sale Agent</h2></a>  
              </div>

              <div data-mdb-input-init class="form-outline form-white mb-4">

            <a href="/village_agent" class="btn text-white w-100" style="background-color:#FF7F26">
            <h2>Village Agent</h2> </a>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div style="background-color:#98144D;height:30vh;">
</section>

  
</div>
<!-- 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
   -->
 </body>
</html>