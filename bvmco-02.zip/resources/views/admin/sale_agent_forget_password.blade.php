@extends('admin/layout');
@section('page_title','Sale Agent Forget Password')
@section('dashboard_select','active')
@section('container')
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  function forget_password()
  {
    window.location='/sale_agent/forget_password';
  }
 </script>
 
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Sale Agent Forget Password</h1> 
        <form action="{{route('sale_agent.forget.password')}}" method="post">
            @csrf
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif

<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile Number</label>
<input id="mobile" name="mobile" type="text" value="{{old('mobile')}}" class="form-control" placeholder="Mobile Number of sale agent" aria-required="true" aria-invalid="false" required>
@error('mobile')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
            <div class="contact-form d-flex flex-column-reverse flex-lg-row ">
              
               <div class="form-field col-lg-6 text-center">
               </div>
               <div class="form-field col-lg-6">
                <input class="btn btn-lg btn-info btn-block" type="submit" value="Submit" name="Submit">
               </div>
            </div>
            
        </div>
      </form>
    </section>
@endsection