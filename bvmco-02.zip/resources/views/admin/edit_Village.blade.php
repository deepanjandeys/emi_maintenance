@extends('admin/layout');
@section('page_title','Edit Village')
@section('village_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none">
@if($id>0)
    {{$image_required=""}}
    {{$password_class="d-none"}}
@else
    {{$image_required="required"}}
    {{$password_class=""}}
@endif
{{@$typeName=session()->get('typeName')}}  
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}  
</span>
<script type="text/javascript">
function getCheckMobileUnique(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getCheckMobileUnique',
    data: { mobile: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html(obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

  function setDefaultPasswordVA(id) {
    if (confirm("do You wabt to reset password to default password !") == false) 
    { 
  return;
    } 
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/setDefaultPasswordVA',
    data: { id: id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<h2 class="title-1 m-b-10">Edit Village</h2>
<a href='{{url("$typeName/village")}}' >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action='{{route("$typeName.manage_village_process")}}' method="post" enctype="multipart/form-data">
@csrf()
<div class="row">
    <div class="col-6">
    <div class="form-group">
<label for="Village_name" class="control-label mb-1">Village Name</label>
<input id="Village_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('name')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="pin" class="control-label mb-1">pin</label>
<input id="pin" name="pin" type="text" value="{{old('pin', $pin)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('pin')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="district" class="control-label mb-1">District</label>
<input id="district" name="district" type="text" value="{{old('district', $district)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('district')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="sub_division" class="control-label mb-1">sub Division</label>
<input id="sub_division" name="sub_division" type="text" value="{{old('sub_division', $sub_division)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('sub_division')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>        
<span class="d-none">{{$status=old('status', $status)}}</span>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('status')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

</div>



<div class="col-6">
<div class="form-group">
<label for="agent_name" class="control-label mb-1">Village Agent Name</label>
<input id="agent_name" name="agent_name" type="text" value="{{old('agent_name', $agent_name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('agent_name')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">Address</label>
<input id="address" name="address" type="text" value="{{old('address', $address)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('address')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile</label>
<input id="mobile" name="mobile" type="text" value="{{old('mobile', $mobile)}}" class="form-control" aria-required="true" aria-invalid="false" onchange="getCheckMobileUnique(this.value)" required>
<span id="spnIsMobileNoUsedEarlier" class="text-danger font-weight-bold"style="display:none;"></span>
@error('mobile')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="email" class="control-label mb-1">email (Optional)</label>
<input id="email" name="email" type="text" value="{{old('email', $email)}}" class="form-control" aria-required="true" aria-invalid="false" >
@error('email')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>


@if($id==0)
<div class="form-group {{$password_class}}">
<label for="password" class="control-label mb-1">Password</label>
<input id="password" name="password" type="text" value="{{$password}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('password')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
@else
<a href="javascript:void(0)" 
  onclick="setDefaultPasswordVA({{$agent_id}})">Reset Password</a>
<div id="divPwd{{$agent_id}}"></div>
@endif

<span class="d-none">{{$IdProofType=old('IdProofType', $IdProofType)}}</span>
<div class="form-group">
<label for="IdProofType" class="control-label mb-1">id proof type </label>
<select id="IdProofType" name="IdProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($id_proof_types as $list)
@if($IdProofType==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('IdProofType')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="IdProofImage" class="control-label mb-1">Id Proof Image</label>
<br>
<img for="IdProofImage" id="IdProofImagePreview" src="{{$IDProofImagePath}}" alt="ID Proof Image">
<input id="IdProofImage" name="IdProofImage" type="file" class="form-control" aria-required="true"  onchange="readURLidProof(this)" aria-invalid="false"  accept="image/*" {{$image_required}}>
<input type="hidden" name="hdIdProofImage" value="{{$IdProofImage}}">
@error('IdProofImage')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$AddressProofType=old('AddressProofType', $AddressProofType)}}</span>
<div class="form-group">
<label for="AddressProofType" class="control-label mb-1">Address proof type </label>
<select id="AddressProofType" name="AddressProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($address_proof_types as $list)
@if($AddressProofType==$list->id)
<option selected value="{{$list->id}}">{{$list->AddressProofType}}</option>
@else
<option value="{{$list->id}}">{{$list->AddressProofType}}</option>
@endif
@endforeach
</select>
@error('AddressProofType')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="AddressProofImage" class="control-label mb-1">Address Proof Image</label><br/>
<img for="AddressProofImage" id="AddressProofImagePreview" src="{{$AddressProofImagePath}}" alt="Address Proof Image">

<input id="AddressProofImage" name="AddressProofImage" type="file"  class="form-control" aria-required="true" onchange="readURLaddress(this)" aria-invalid="false" {{$image_required}}  accept="image/*">
<input type="hidden" name="hdAddressProofImage" value="{{$AddressProofImage}}">
@error('AddressProofImage')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
    </div>
</div>
<div>
<input type="hidden" name="id" value="{{$id}}">
<input type="hidden" name="agent_id" value="{{$agent_id}}">
<input type="hidden" name="admin_id" value="{{$admin_id}}">
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
        
    
function readURLidProof(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#IdProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}

function readURLaddress(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#AddressProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}


</script>
@endsection