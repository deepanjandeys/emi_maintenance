@extends('admin/layout');
@section('page_title','Order')
@section('order_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none">{{$id=session()->get('ADMIN_ID')}}</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Order</h2>
<div class="row">
    <div class="col-3">
<a href="{{url('sale_agent/order/place_order/')}}/{{$id}}" >
<button type="button" class="btn btn-success">Add Order</button>
</a>
    
    </div>
    <div class="col-2 d-none">
<a href="{{url('sale_agent/order/trash')}}" >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-9">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="{{url('sale_agent/orders')}}" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
</div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>   <th>ID</th>
                                                <th>Date</th>
                                                <th>Customer ID</th>
                                                <th>Customer Name</th>
                                                <th>Address</th>
                                                <th>Sale agent</th>
                                                <th>Product</th>
                                                <th>Sale Price</th>
                                                <th>Down Payment</th>
                                                <th>EMI</th>
                                                <th>EMI Mode</th>
                                            <th>EMI Period</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($order as $list)
                                            <tr>
                                                <td>
                                                    <a href="{{url('sale_agent/order/edit_order/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                                    </a>
                                                    <a href="{{url('sale_agent/order/delete/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger w-100">Trash</button>
                                                    </a>
                                                    
                                                </td>
                                                <td>{{$list->id}}
                                                <a href="{{url('sale_agent/order/edit_order/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Bill</button>
                                                    </a></td>
                                                <td>{{$list->order_date}}</td>
                                                <td>{{$list->customer_id}}</td>
                                                <td>{{$list->getCustomers[0]->name}}</td>
                                                <td>{{$list->getCustomers[0]->address}}</td>
                                                <td>{{$list->getSalesAgent[0]->name}}</td>
                                                <td>{{$list->getProduct[0]->name}}</td>
                                                <td>{{$list->sale_price}}</td>
                                                <td>{{$list->down_payment}}</td>
                                                <td>{{$list->EMI}}</td>
                                                <td>                                        @foreach($calcmode as $list1)
                                                    @if($list->EMI_mode==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach</td>
                                                <td>{{$list->EMI_Period}}</td>
                                                
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $order->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection