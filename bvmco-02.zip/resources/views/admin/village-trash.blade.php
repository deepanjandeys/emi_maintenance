@extends('admin/layout');
@section('page_title','Village')
@section('Village_select','active')
@section('master_tran','master')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Village Trash</h2>
<a href="{{url('admin/village')}}" >
<button type="button" class="btn btn-success">Go to Village</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                 <th>ID</th>
                                                <th>Name</th>
                                                <th>PIN</th>
                                                <th>District</th>
                                                <th>Sub-Division</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($data as $list)
                                            <tr>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->pin}}</td>
                                                <td>{{$list->district}}</td>
                                                <td>{{$list->sub_division}}</td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                    
                                                    @endif
                                                    
                                                </td>
                                                <td>
                                                    <a href="{{url('admin/village/restore/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    
                                                    <a href="{{url('admin/village/forceDelete/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">Delete</button>
                                                    </a>
                                                    
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection