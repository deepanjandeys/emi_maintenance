@extends('admin/layout');
@section('page_title','Customer')
@section('customer_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none">{{$typeName=session()->get('typeName')}}</span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_id').attr('multiple','multiple');
        $('#spnMessage').show();
    }

</script> 
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

@if (session('error'))
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  {{session('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Customer</h2>
<div class="row">
    <div class="col-3">
<a href='{{url("$typeName/customer/edit_customer")}}' >
<button type="button" class="btn btn-success">Add Customer</button>
</a>
    
    </div>
    <div class="col-2">
<a href='{{url("$typeName/customer/trash")}}' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()">{{$a_search_text}}</a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style={{$displaySearch}} >
                    <fieldset class="p-2 rounded"><legend>Search</legend>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="name" id="name" class="form-control" value="{{$name}}">
                        </div>
                        <div class="col-lg-3">
                          Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="mobile" id="mobile" value="{{$mobile}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        
                        <div class="col-lg-3">
                          Village
                          <a href="javascript:void(0)" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($village_id)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="village_id" name="village_id[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Villages)>1)
<option value="">select </option>
@endif
@foreach($Villages as $list)
    {{$s=''}} 
    @foreach($village_id as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>    
</div>
<div class="col-lg-3">
    Customer  id
</div>
<div class="col-lg-3 col-sm-9 col-xs-9">
<input type="text" name="id" id="id" class="form-control" value="{{$id}}">
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="{{$rows}}" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='{{url("$typeName/customer")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
 <div class="row m-t-30">
    <div class="col-md-12">
    <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
<table class="table table-borderless table-data3">
<thead>
<tr>
<th rowspan="2">Action</th> 
<th rowspan="2">ID</th>
<th rowspan="2">Name</th>
<th rowspan="2">Mobile</th>
<th rowspan="2">PIN</th>
<th rowspan="2">Address</th>
<th rowspan="2">Village</th>
<th colspan="2" class="text-center">ID Proof</th>
<th colspan="2" class="text-center">address proof</th>
<th rowspan="2">Approved</th>
<th rowspan="2">Status</th>
</tr>
<tr>
<th>type</th>
<th>Image</th>
<th>Type</th>
<th>Image</th>
</tr>
</thead>
<tbody>
@foreach($customers as $list)
<tr>
<td>
<a href='{{url("$typeName/customer/edit_customer/")}}/{{$list->id}}'>
<button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
</a>          
<a href='{{url("$typeName/customer/delete/")}}/{{$list->id}}'>
<button type="button" class="btn btn-danger">Trash</button>
</a>
</td>
<td>{{$list->id}}</td>
<td>{{$list->name}}</td>
<td>{{$list->mobile}}</td>
<td>{{$list->pin}}</td>
<td>{{$list->address}}</td>
<td>                                      
    @foreach($Villages as $list1)
@if($list->village_id==$list1->id)
{{$list1->name}}
@break
@endif
@endforeach
</td>
<td>
@foreach($id_proof_types as $list1)
@if($list->IdProofType==$list1->id)
{{$list1->name}}
@break
@endif
@endforeach
</td>
<td>
<img src="{{asset('/storage/media').'/'.$list->IdProofImage}}" alt="{{asset('/storage/media').'/'.$list->IdProofImage}}" style="width: 100px;height: 100px;"/>
</td>
<td>
@foreach($address_proof_types as $list1)
@if($list->AddressProofType == $list1->id)
{{$list1->AddressProofType}}
@break
@endif
@endforeach
</td>
<td>
<img src="{{asset('/storage/media').'/'.$list->AddressProofImage}}" alt="{{asset('/storage/media').$list->AddressProofImage}}" style="width: 100px;height: 100px;"/>
</td>
<td>
@if($list->isApproved==1)
<span class="text-primary"> Approved</span>
@if(session()->get('ADMIN_TYPE')=='1')
<a href="{{url('admin/customer/approve/0/')}}/{{$list->id}}">
<button type="button" class="btn btn-warning">Disapprove</button>
</a>
@endif
@elseif($list->isApproved==0)
<span class="text-danger">Disapproved</span>
@if(session()->get('ADMIN_TYPE')=='1')
<a href="{{url('admin/customer/approve/1/')}}/{{$list->id}}">
<button type="button" class="btn btn-primary">Approve</button>
</a>
@endif
@endif
</td>
<td>
@if($list->status==1)
<span class="text-primary"> Active</span>
@if(session()->get('ADMIN_TYPE')=='1')
<a href="{{url('admin/customer/status/0/')}}/{{$list->id}}">
<button type="button" class="btn btn-warning">Deactivate</button>
</a>
@endif
@elseif($list->status==0)
<span class="text-danger">Inactive</span>
@if(session()->get('ADMIN_TYPE')=='1')
<a href="{{url('admin/customer/status/1/')}}/{{$list->id}}">
<button type="button" class="btn btn-primary">Activate</button>
</a>
@endif
@endif
</td>
</tr>
@endforeach
</tbody>
</table>
</div>
{{
$customers->links();
}}
<!-- END DATA TABLE-->
</div>
</div>
@endsection