@extends('admin/layout');
@section('page_title','Edit IdProofType')
@section('IdProofType_select','active')
@section('master_tran','master')
@section('container')
<h2 class="title-1 m-b-10">Edit IdProofType</h2>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<a href="{{url('admin/idProofType')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card">
                                    <div class="card-body">
                                        <form action="{{route('product.manage_idProofType_process')}}" method="post">
                                            @csrf()
                                            <div class="form-group">
                                                <label for="IdProofType_name" class="control-label mb-1">Id Proof Type Name</label>
                                                <input id="IdProofType_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                
                                                    @error('name')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                                
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                            <input type="hidden" name="id" value="{{$id}}">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
@endsection