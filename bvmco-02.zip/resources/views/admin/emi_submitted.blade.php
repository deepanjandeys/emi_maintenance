@extends('admin/layout');
@section('page_title','EMI Submitted')
@section('emi_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none">{{@$typeName=session()->get('typeName')}}    </span> 
	<div class="row">
			<h2 class="title-1 m-b-10">{{Config::get('constants.SITE_NAME')}} EMI Submitted</h2>
<br>
        <div class="col-lg-12">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
<a href='{{url("$typeName/emis/print_emi")}}/{{$emi_id}}' target="_blank">
                                                    <button type="button" class="btn btn-primary">&nbsp;Download Reciept&nbsp;</button>
                                                    </a>
                                                 
     		</div>
         </div>
     </div>
@endsection