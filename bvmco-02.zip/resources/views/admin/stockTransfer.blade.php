@extends('admin/layout');
@section('page_title','Edit Branch Stock')
@section('BranchStock_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none">
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
</span>
<h2 class="title-1 m-b-10">Stock Transfer</h2>
<a href="{{url('admin/branchStock')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>

<script type="text/javascript">

function getFrmBranchDetails(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getBranchDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnFrmBranchName').html('<b>Name : </b>'+obj.name);
            $('#spnFrmBranchAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnFrmBranchMobile').html(' <b>Mobile</b> :'+obj.mobile);
            }
        else
        {
            $('#spnFrmBranchName').html('');
            $('#spnFrmBranchAddress').html('');
            $('#spnFrmBranchMobile').html('');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getToBranchDetails(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getBranchDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnToBranchName').html('<b>Name : </b>'+obj.name);
            $('#spnToBranchAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnToBranchMobile').html(' <b>Mobile</b> :'+obj.mobile);
        
            getStockDetails();    
        }
        else
        {
            $('#spnToBranchName').html('');
            $('#spnToBranchAddress').html('');
            $('#spnToBranchMobile').html('');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getProductDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnCategory').html(' <b>category</b> :'+obj.category);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#sale_price').val(obj.MRP);

            getStockDetails();
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnCategory').html('');
            $('#spnProdGroupName').html('');
            $('#sale_price').val('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
function getStockDetails() {
    var frm_branch_id=$('#frm_branch_id').val();
    var product_id =$('#product_id').val();
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getStockDetails',
    data: { branch_id: frm_branch_id, product_id:product_id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
          $('#spnAvlStock').html('<span style="color:green;font-weight:bold;">Available stock </span>'+'<span style="color:blue;font-weight:bold;" id="spnAvlStockQty">'+obj.stock+'</span>');
          $('#transfer-button').show();
        }
        else
        {
           $('#spnAvlStock').html('<span style="color:red;font-weight:bold;">stock is not Available </span>');
           $('#transfer-button').hide();
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function validation()
{
   // debugger;
var avlQty=$('#spnAvlStockQty').html();
if(avlQty==undefined)
    avlQty=0;
else
    avlQty=parseInt(avlQty);

var qty=$('#qty').val();
qty=parseInt(qty);
if(isNaN(qty))
    {
    qty=0;
    }

var to_branch_id=$('#to_branch_id').val();
var frm_branch_id=$('#frm_branch_id').val();

    if(qty==0)
    {
        $('#msg').html('<span style="color:red;font-weight:bold">Enter proper Quantity value, then proccede</span>');
        return false;
    }
    else if(avlQty<qty)
    {
    $('#msg').html('<span style="color:red;font-weight:bold">Quantity value is greater than available quantity , change quantity value then proccede</span>');
        return false;
        
    }
    else if(frm_branch_id==to_branch_id)
    {
    $('#msg').html('<span style="color:red;font-weight:bold">from Branch ID and To Branch Id is same, change Branch ID then proccede</span>');
        return false;    
    }
    else
    {
    $('#msg').html('');
    return true;
    }
}
</script>

         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card">
                                    <div class="card-body">
                                        <form action="{{route('manage_branchStock_transfer')}}" method="post" onsubmit="return validation();">
                                            @csrf()
                                            <div class="form-group">
                                   <label for="frm_branch_id" class="control-label mb-1">from Branch id</label>
                                    <input list="Branches" id="frm_branch_id" name="frm_branch_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getFrmBranchDetails(this.value)" required>
                                    <datalist id="Branches">
      
                                              @foreach($Branches as $list)
                                                
                                                <option value="{{$list->id}}">{{$list->name}}</option>
                                            @endforeach
                                    </datalist>
                                    <span id="spnFrmBranchName"></span>
                                    <span id="spnFrmBranchAddress"></span>
                                    <span id="spnFrmBranchMobile"></span>
                                    @error('frm_branch_id')
                                    <div class="alert alert-danger" role="alert">
                                    {{$message}}
                                    </div>
                                    @enderror
                                    </div>
                                    <div class="form-group">
                                <label for="product_id" class="control-label mb-1">Product</label>
                                    <input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
                                    <datalist id="products">
      
                                              @foreach($products as $list)
                                                
                                                <option value="{{$list->id}}">{{$list->name}}</option>
                                            @endforeach
                                    </datalist>
                                    <span id="spnProdName"></span>
                                    <span id="spnCode"></span>
                                    <span id="spnImage"></span>
                                    <span id="spnCategory"></span>
                                    <span id="spnProdGroupName"></span>
                                    @error('product_id')
                                    <div class="alert alert-danger" role="alert">
                                    {{$message}}
                                    </div>
                                    @enderror
                                    </div>
                                    <span id="spnAvlStock"></span>
                                    <div class="form-group">
                                                <label for="qty" class="control-label mb-1">Quantity</label>
                                                <input id="qty" name="qty" type="text" value="" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    @error('qty')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                    </div>
                                    <div class="form-group">
                                   <label for="to_branch_id" class="control-label mb-1">to Branch id</label>
                                    <input list="toBranches" id="to_branch_id" name="to_branch_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getToBranchDetails(this.value)" required>
                                    <datalist id="toBranches">
      
                                              @foreach($Branches as $list)
                                                
                                                <option value="{{$list->id}}">{{$list->name}}</option>
                                            @endforeach
                                    </datalist>
                                    <span id="spnToBranchName"></span>
                                    <span id="spnToBranchAddress"></span>
                                    <span id="spnToBranchMobile"></span>
                                    @error('to_branch_id')
                                    <div class="alert alert-danger" role="alert">
                                    {{$message}}
                                    </div>
                                    @enderror
                                    </div>
                    
                                    <div>
                                        <div id="msg"></div>
                                                <button id="transfer-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                        
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
@endsection