@extends('admin/layout');
@section('page_title','ProductGroup')
@section('Product_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Product Trash</h2>
<a href="{{url('admin/product')}}" >
<button type="button" class="btn btn-success">Go to Product </button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                             <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Code</th>
                                                <th>Name</th>
                                                <th>Category</th>
                                                <th>MRP</th>
                                                <th>Image</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           @foreach($data as $list)
                                            <tr>
                                                                                                <td>
                                                    <a href="{{url('admin/product/restore/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">restore</button>
                                                    </a>
                                                    <a href="{{url('admin/product/forceDelete')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">&nbsp;Delete&nbsp;</button>
                                                    </a>
                                                    
                                                </td>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->code}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>                                      @foreach($Groups as $list1)
                                                    @if($list->category==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach
                                                </td>
                                                <td>{{$list->MRP}}</td>
                                                <td><img src="{{asset('/storage/media').'/'.$list->image}}" alt="{{asset('/storage/media').'/'.$list->image}}" /></td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                    
                                                    @endif
                                                    
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection