@extends('admin/layout');
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')

	<div class="row">
			<h2 class="title-1 m-b-10">{{Config::get('constants.SITE_NAME')}} Sale Agent Dashboard</h2>
<div class="col-12">
    <h3>Welcome {{session()->get('ADMIN_REFER_NAME')}}</h3>
</div>
        <div class="col-lg-12">
            <div class="au-card--no-shadow au-card--no-pad m-b-40">
                <span class="text-primary font-weight-bold">Total Collected Amount</span><span class="text-danger font-weight-bold"> {{$collected_amount}}</span> <br> 
            <span class="text-primary font-weight-bold">Total Recieved Amount</span><span class="text-danger font-weight-bold"> {{$recieved_amount}}</span>  
            
     		</div>
         </div>
     </div>
@endsection