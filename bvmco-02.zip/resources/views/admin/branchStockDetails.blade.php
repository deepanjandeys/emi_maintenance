@extends('admin/layout');
@section('page_title','Order')
@section('BranchStock_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none">{{$typeName=session()->get('typeName')}}</span>
<script type="text/javascript">
function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            //$('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            //$('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button> 
</div>
@endif
<h2 class="title-1 m-b-10">Stock Transfer details</h2>
<div class="row">
    <div class="col-3">
        <a href="{{url('admin/branchStock')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
    
    </div>
    <div class="col-2">
    
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()">{{$a_search_text}}</a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style={{$displaySearch}} >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Quantity
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                            <div class="row">
                                <div class="col-5">
                                <select id="operator" name="operator" class="form-control w-100" aria-required="true" aria-invalid="false" >
                        @foreach($operators as $list)
                            @if($operator==$list->name)
                                {{$s='selected'}}
                            @else 
                                {{$s=''}}
                            @endif
    <option {{$s}} value="{{$list->name}}">{{$list->name}}</option>
    @endforeach
</select>                            
                                </div>
                                <div class="col-7">
<input type="text" name="quantity" id="quantity" class="form-control" placeholder="Quantity" value="{{$quantity}}">
    
                                </div>
                            </div>
        
                        </div>
<div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($product_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="product_ids" name="product_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Products)>1)
<option value="">(all) </option>
@endif
@foreach($Products as $list)
    {{$s=''}} 
    @foreach($product_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="Order Date from" value="{{$Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         Date to
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="Order Date To" value="{{$Date_To}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
      
<div class="col-6 text-right">
    <button class="btn btn-primary">Search</button>   
    <a href='{{url("$typeName/orders")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>

 <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Branch</th>
                                                <th>Product</th>
                                                <th>Qty</th>
                                                <th>Date</th>
                                                <th>Current Stock</th>
                                                <th>Mode</th>
                                                <th>last Updated</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($branchStockDetails as $list)
                                            <tr>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->getBranch[0]->name}}</td>
                                                <td>{{$list->getProduct[0]->name}}</td>
                                                <td>{{$list->qty}}</td>
                                                <td>{{$list->txn_date}}</td>
                                                <td>{{$list->current_stock}}</td>
                                                <td>
                                                    @if($list->mode==1)
                                                    <span class="text-primary"> Purchase</span>
                                                   
                                                    @elseif($list->mode==2)
                                                    <span class="text-danger"> sale</span>
                                                    @elseif($list->mode==3)
                                                    <span class="text-primary font-weight-bold"> return </span>
                                                    @elseif($list->mode==4)
                                                    <span class="text-success"> bill restored</span>
                                                    @endif
                                                    </td>
                                                <td>{{$list->updated_at}}</td>
                                                
                            
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $branchStockDetails->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection