@extends('admin/layout');
@section('page_title','Product List')
@section('product_select','active')
@section('master_tran','master')
@section('container')
 
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<span class="d-none">
{{$id=session()->get('ADMIN_ID')}}
</span>
<h2 class="title-1 m-b-10">Product </h2>
<div class="row">
    <div class="col-3">

    </div>
    <div class="col-2">
    
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
        <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href='{{url("$typeName/product_list")}}' >
    <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                             <tr>
                                                <th>Action</th>
                                                <th>Code</th>
                                                <th>Name</th>
                                                <th>Group</th>
                                                <th>Sub Group</th>
                                                <th>Product Price</th>
                                                <th>Image</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           @foreach($product as $list)
                                            <tr>
                                                <td>
                                                     <a href='{{url("$typeName/order/place_order/")}}/{{$sale_agent_id}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-success">Place Order</button>
                                                    </a>          
                                                </td>
                                                <td>{{$list->code}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>                                      @foreach($Groups as $list1)
                                                    @if($list->GroupId==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach
                                                </td>
                                                <td>
                                            @foreach($subGroups as $list1)
                                                    @if($list->SubGroupId==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach
                                                </td>
                                                <td>{{$list->MRP}}</td>
                                                <td><img src="{{asset('/storage/media').'/'.$list->image}}" alt="{{asset('/storage/media').'/'.$list->image}}"  style="width:100px;" />
                                                </td> 
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                {{
                                    $product->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection