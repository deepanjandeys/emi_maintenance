@extends('admin/layout');
@section('page_title','EMI List')
@section('emi_list','active')
@section('master_tran','report')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
    {{$ADMIN_TYPE=session()->get('ADMIN_TYPE')}}
</span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script> 
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<h2 class="title-1 m-b-10">EMI List</h2>

<div class="row">
    <div class="col-3 d-none">
<a href='{{url("$typeName/emis/edit_collection")}}' >
<button type="button" class="btn btn-success">Collect EMI</button>
</a>

    </div>
    <div class="col-2 d-none">
<a href='{{url("$typeName/order/trash")}}' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()">{{$a_search_text}}</a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style={{$displaySearch}} >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Bill Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="bill_id" id="bill_id" class="form-control" placeholder="Bill Id" value="{{$bill_id}}">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($product_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="product_ids" name="product_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Products)>1)
<option value="">(all) </option>
@endif
@foreach($Products as $list)
    {{$s=''}} 
    @foreach($product_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
                      </div>
<div class="row py-1">
                        <div class="col-lg-3">
                          Due Date From
                        <a href="javascript:void(0)" onclick="clear_due_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Due_Date_From" id="Due_Date_From" class="form-control" placeholder="EMI Due Date from" value="{{$Due_Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         Due Date to
                         <a href="javascript:void(0)" onclick="clear_due_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Due_Date_To" id="Due_Date_To" placeholder="EMI Due Date To" value="{{$Due_Date_To}}" class="form-control">
                        </div>
                      </div>
<div class="row py-1">
                        <div class="col-lg-3">
                          Collection Date From
                        <a href="javascript:void(0)" onclick="clear_collect_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Collect_Date_From" id="Collect_Date_From" class="form-control" placeholder="EMI Collection Date from" value="{{$Collect_Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         EMI Collection Date to
                         <a href="javascript:void(0)" onclick="clear_collect_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Collect_Date_To" id="Collect_Date_To" placeholder="EMI Collection Date To" value="{{$Collect_Date_To}}" class="form-control">
                        </div>
                      </div>      
<div class="row py-1">
                        <div class="col-lg-3">
                          Receive Date From
                        <a href="javascript:void(0)" onclick="clear_receive_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Receive_Date_From" id="Receive_Date_From" class="form-control" placeholder="EMI Receive Date from" value="{{$Receive_Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         EMI Receive Date to
                         <a href="javascript:void(0)" onclick="clear_receive_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Receive_Date_To" id="Receive_Date_To" placeholder="EMI Receive Date To" value="{{$Receive_Date_To}}" class="form-control">
                        </div>
                      </div>                                          
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="{{$cust_name}}">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="{{$cust_mobile}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                    
                        <div class="col-lg-3">
                          Village
                          @if($ADMIN_TYPE !=4)
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          @endif
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($village_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="village_ids" name="village_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Villages)>1)
<option value="">(all) </option>
@endif
@foreach($Villages as $list)
    {{$s=''}} 
    @foreach($village_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>    
</div>
<div class="col-lg-3">

                      Sale agents
                      @if($ADMIN_TYPE !=4)
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                    @endif
</div>
<div class="col-lg-3">

<div class="form-group">
@if(count($sale_agent_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif
<select id="sale_agent_ids" name="sale_agent_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($SalesAgents)>1)
<option value="">(all) </option>
@endif
@foreach($SalesAgents as $list)
    {{$s=''}} 
    @foreach($sale_agent_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-6 text-right"></div>
<div class="col-6 text-right">
<input type="radio" name="rdb" id="rdb1" value="1" @if($rdb==1)checked @endif><label for="rdb1" class="btn btn-success"> Not Collected</label>
<input type="radio" name="rdb" id="rdb2" value="2" @if($rdb==2)checked @endif><label class="btn btn-primary" for="rdb2"> Collected</label>
<input type="radio" name="rdb" id="rdb3" value="3" @if($rdb==3)checked @endif><label for="rdb3" class="btn btn-danger"> Received</label>
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="{{$rows}}" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='{{url("$typeName/emis")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<a href='{{url("/EMIExport")}}?{{$getURL}}' >
<button type="button" class="btn btn-primary">Export to Excel</button>
</a>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                            <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th style="display: none;">Action</th>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Paid Amount</th>
                                            <th>Cash</th>
                                            <th>Bank</th>
                                            <th>Due Amount</th>
                                            <th>Due Date</th>
                                            <th>Collect Date</th>
                                            <th>Receive Date</th>
                                            <th>Remarks</th>
                                            </tr>
             
                                        </thead>
                                        <tbody>
                                @foreach($emi_collections as $list)
                                <tr>
                                    <td style="display:none;">
                                        
                                    @if($ADMIN_TYPE==1)
                                <a href='{{url("$typeName/emis/emi_collection")}}/{{$list->id}}'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;View EMI&nbsp;&nbsp;</button>
                                    </a>
                                    @elseif($ADMIN_TYPE==3)
                                    <a href='{{url("$typeName/emis/emi_collection")}}/{{$list->id}}'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Recieve EMI&nbsp;&nbsp;</button>
                                    </a>
                                    @elseif($ADMIN_TYPE==4)
                                     @if($list->collect_time=='')
                                    <a href='{{url("$typeName/emis/emi_collection")}}/{{$list->id}}'>
                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Collect EMI&nbsp;&nbsp;</button>
                                    </a>
                                        @endif
                                    @endif
                                    </td>
                                    <td>{{$list->bill_id}}
                                    </td>
                                    <td>{{$list->emi_date}}</td>
                    <td>                                       {{$list->getBills[0]->getCustomers[0]->name}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->getVillages[0]->name??''}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->mobile??''}}</td>
                    <td style="text-align:right;">{{$list->EMI_Loan}}</td>
                    <td style="text-align:right;">{{$list->EMI_interest}}</td>
                    <td style="text-align:right;">{{$list->emi_amount}}</td>
                    <td style="text-align:right;">{{$list->fine_amount}}</td>
                    <td style="text-align:right;">{{$list->paid_amt}}</td>
                    <td style="text-align:right;">{{$list->cash}}</td>
                    <td style="text-align:right;">{{$list->bank}}</td>
                    <td style="text-align:right;">{{$list->due_amt}}</td>
                    <td>{{$list->emi_date}}</td>
                    <td>{{$list->collect_time}}</td>
                    <td>{{$list->receive_time}}</td>
                    <td>{{$list->remarks}}</td>
                </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $emi_collections->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Due_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Due_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#Collect_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Collect_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


$('#Receive_Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Receive_Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

@if($Due_Date_From=='')
    $('#Due_Date_From').val('');
@endif
@if($Due_Date_To=='')
    $('#Due_Date_To').val('');
@endif

@if($Collect_Date_From=='')
    $('#Collect_Date_From').val('');
@endif
@if($Collect_Date_To=='')
    $('#Collect_Date_To').val('');
@endif

@if($Receive_Date_From=='')
    $('#Receive_Date_From').val('');
@endif
@if($Receive_Date_To=='')
    $('#Receive_Date_To').val('');
@endif
});


function clear_due_date_from()
    {
    $('#Due_Date_From').val('');
    }
function clear_due_date_to()
    {
    $('#Due_Date_To').val('');
    }

function clear_collect_date_from()
    {
    $('#Collect_Date_From').val('');
    }
function clear_collect_date_to()
    {
    $('#Collect_Date_To').val('');
    }

function clear_receive_date_from()
    {
    $('#Receive_Date_From').val('');
    }
function clear_receive_date_to()
    {
    $('#Receive_Date_To').val('');
    }
</script>
@endsection