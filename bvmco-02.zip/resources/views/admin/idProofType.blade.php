@extends('admin/layout');
@section('page_title','IdProofType')
@section('idProofType_select','active')
@section('master_tran','master')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

@if (session('error'))
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  {{session('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Id Proof Type</h2>
<div class="row">
    <div class="col-3">
<a href="{{url('admin/idProofType/edit_idProofType')}}" >
<button type="button" class="btn btn-success">Add Id Proof Type</button>
</a>
    
    </div>
    <div class="col-2">
<a href="{{url('admin/idProofType/trash')}}" >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="{{url('admin/idProofType')}}" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($IdProofType as $list)
                                            <tr>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>
                                                    <a href="{{url('admin/idProofType/edit_idProofType/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Edit</button>
                                                    </a>
                                                    <a href="{{url('admin/idProofType/delete/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                    
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $IdProofType->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection