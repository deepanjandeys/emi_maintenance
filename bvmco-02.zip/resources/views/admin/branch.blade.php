@extends('admin/layout');
@section('page_title','Branch')
@section('Branch_select','active')
@section('master_tran','master')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Branch</h2>
<div class="row">
    <div class="col-3">
<a href="{{url('admin/branch/edit_branch')}}" >
<button type="button" class="btn btn-success">Add Branch</button>
</a>
    
    </div>
    <div class="col-2">
<a href="{{url('admin/branch/trash')}}" >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="{{url('admin/branch')}}" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>PIN</th>
                                                <th>Address</th>
                                                <th>Mobile</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($Branch as $list)
                                            <tr>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->pin}}</td>
                                                <td>{{$list->address}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    <a href="{{url('admin/branch/status/0/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Deactivate</button>
                                                    </a>
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                    <a href="{{url('admin/branch/status/1/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-primary">Activate</button>
                                                    </a>
                                                    @endif
                                                    
                                                </td>
                                                <td>
                                                    <a href="{{url('admin/branch/edit_branch/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">Edit</button>
                                                    </a>
                                                    <a href="{{url('admin/branch/delete/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                    
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $Branch->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection