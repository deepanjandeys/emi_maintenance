@extends('admin.pdf_layout')
@section('content')
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">

<div class="form-group">
<label for="bill_date" class="control-label mb-1">Bill Date</label>
<input id="bill_date" name="bill_date" type="text" value="{{$bill_date}}" class="form-control" aria-required="true" aria-invalid="false" required>
</div>
<div class="form-group">
<label for="customer_id" class="control-label mb-1">Customer</label>
<input list="customers" id="customer_id" name="customer_id" class="form-control" aria-required="true" aria-invalid="false"  >
<datalist id="customers">
@foreach($customers as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
</div>
<div class="form-group">
<label for="Customer_name" class="control-label mb-1">Customer Name</label>
<input id="Customer_name" type="text" class="form-control" tabindex="-1" readonly>
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">Address</label>
<input id="address" type="text" class="form-control" tabindex="-1" readonly>
</div>
<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile</label>
<input id="mobile" type="text" class="form-control" tabindex="-1" readonly>
</div>
<input type="hidden" id="arr">
<span id="spnCustOrders"></span>
<div class="form-group">
<label for="Sale_agent_id" class="control-label mb-1">Sale agent id</label>
<input list="SaleAgents" id="Sale_agent_id" name="Sale_agent_id" class="form-control" aria-required="true" aria-invalid="false"  >
<datalist id="SaleAgents">
@foreach($sales_agents as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
</div>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  >
<datalist id="products">
@foreach($products as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
</div>

<div class="form-group">
<label for="sale_price" class="control-label mb-1">Product price</label>
<input id="sale_price" name="sale_price" type="text" value="{{$sale_price}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>
<div class="form-group">
<label for="booking_advance" class="control-label mb-1">Booking Advance</label>
<input id="booking_advance" name="booking_advance" type="text" value="{{$booking_advance}}" class="form-control" aria-required="true" aria-invalid="false" required>
</div>

<div class="form-group">
<label for="down_payment" class="control-label mb-1">Current Down payment</label>
<input id="down_payment" name="down_payment" type="text" value="{{$down_payment}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>
<div class="form-group">
<label for="balanced_downpayment" class="control-label mb-1">Total Down payment</label>
<input id="balanced_downpayment" name="balanced_downpayment" type="text" value="{{$balanced_downpayment}}" class="form-control" aria-required="true" aria-invalid="false" required>
</div>
<div class="row">
    <div class="col-6">
<h6>Loan details</h6>
<div class="form-group">
<label for="LoanAmount" class="control-label mb-1">LoanAmount</label>
<input id="LoanAmount" name="LoanAmount" type="text" value="{{$LoanAmount}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>

<div class="form-group">
<label for="interestPercntage" class="control-label mb-1">Interest Percentage (%)</label>
<input id="interestPercntage" name="interestPercntage" type="number" value="{{$interestPercntage}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>
<div class="form-group">
<label for="IntOnLoan" class="control-label mb-1">Interest On Loan</label>
<input id="IntOnLoan" name="IntOnLoan" type="text" value="{{$IntOnLoan}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>

<div class="form-group">
<label for="EMI_mode" class="control-label mb-1">EMI Mode</label>
<select id="EMI_mode" name="EMI_mode" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
@foreach($calcmode as $list)
@if($EMI_mode==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
</div>
<div class="form-group">
<label for="EMI_in_Months" class="control-label mb-1">EMI in Months</label>
<input id="EMI_in_Months" name="EMI_in_Months" type="number" value="{{$EMI_in_Months}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI_period()" required>
</div>

<div class="form-group">
<label for="EMI_Period" class="control-label mb-1">EMI_Period</label>
<input id="EMI_Period" name="EMI_Period" type="text" value="{{$EMI_Period}}" class="form-control" aria-required="true" aria-invalid="false" >
</div>
<div class="form-group">
<label for="EMI" class="control-label mb-1">EMI</label>
<input id="EMI" name="EMI" type="text" value="{{$EMI}}" class="form-control" aria-required="true" aria-invalid="false" required>
</div>
        
    </div>
    <div class="col-6">
        <h6>EMI Details</h6>        
        <div class="table table-borderd table-responsive" style="height: 100vh;overflow-y: scroll;">
            <table>
                <thead>
                <tr>
                    <th>
                        Sl
                    </th>
                    <th>
                        Date
                    </th>
                    <th>
                        Amount
                    </th>
                    <th>
                        Fine
                    </th>
                    <th>
                        
                    </th>

                </tr>
    
                </thead>
                <tbody id="tbEMI">
                    <span class="d-none">{{$i=0}}</span>
                    @foreach($emi_collections as $ec)
                    <span class="d-none">{{@$i++}}</span>
                <tr>
                        <td>
                            {{$ec->id}}
                        </td>
                        <td>
                          <input type="text" value="{{$ec->emi_date}}" name="EMI_Date{{$i}}" class="EMI_date" >  
                        </td>
                        <td>
                            {{$ec->emi_amount}}
                        </td>
                        <td>
                            {{$ec->fine_amount}}
                        </td>
                </tr>    
                    @endforeach              
                </tbody>                
            </table>
        </div>
    </div>
</div>

<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
</div>
<div>

</div>
<input type="hidden" id="id" name="id" value="{{$id}}" >
<input type="hidden" id="order_id" name="order_id" value="{{$order_id}}" >
<input type="hidden" id="emi_collections_count" name="emi_collections_count" value="{{$emi_collections_count}}" >

<input type="hidden" id="branch_id" name="branch_id" value="1" >
</form>
</div>
</div>
</div>
</div>
@endsection