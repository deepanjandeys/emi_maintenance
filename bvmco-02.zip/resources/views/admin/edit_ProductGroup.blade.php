@extends('admin/layout');
@section('page_title','Edit Product Group')
@section('ProductGroup_select','active')
@section('master_tran','master')
@section('container')
<h2 class="title-1 m-b-10">Edit Product Group</h2>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<a href="{{url('admin/product_group')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card">
                                    <div class="card-body">
                                        <form action="{{route('product.manage_product_group_process')}}" method="post">
                                            @csrf()
                                            <div class="form-group">
                                                <label for="ProductGroup_name" class="control-label mb-1">Product Group Name</label>
                                                <input id="ProductGroup_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                
                                                    @error('name')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                                
                                            </div>
<span class="d-none">{{$loan_type=old('loan_type', $loan_type)}}</span>
                                            
                                            <div class="form-group">
                                                <label for="loan_type" class="control-label mb-1">Loan Type</label>
                                                
                                                <select id="loan_type" name="loan_type" class="form-control" aria-required="true" aria-invalid="false" required>
                                                        <option value="">select</option>
                                                        @foreach($loan_types as $list)
                                                            @if($loan_type==$list->id)
                                                        <option selected value="{{$list->id}}">{{$list->name}}</option>
                                                            @else
                                                        <option value="{{$list->id}}">{{$list->name}}</option>
                                                            @endif
                                                        @endforeach
                                                </select>
                                                 
                                                    @error('loan_type')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>                  
                                           <div class="form-group">
                                                <label for="status" class="control-label mb-1">status</label>
                                                    <select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
                                                        @foreach($statuses as $list)
                                                            @if($status==$list->id)
                                                        <option selected value="{{$list->id}}">{{$list->name}}</option>
                                                            @else
                                                        <option value="{{$list->id}}">{{$list->name}}</option>
                                                            @endif
                                                        @endforeach
                                                </select>
                                           
                                                    @error('status')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                            <input type="hidden" name="id" value="{{$id}}">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
@endsection