@extends('admin/layout');
@section('page_title','Village')
@section('Village_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif


@if (session('error'))
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  {{session('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

<h2 class="title-1 m-b-10">Village</h2>
<div class="row">
    <div class="col-3">
<a href='{{url("$typeName/village/edit_village")}}' >
<button type="button" class="btn btn-success">Add Village</button>
</a>
    
    </div>
    <div class="col-2">
<a href='{{url("$typeName/village/trash")}}' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="{{$rows}}" size="2"> per page
            <input type="search" name="search" class="form-control" placeholder="search by village name" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href='{{url("$typeName/village")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
<div class="row m-t-30">
<div class="col-md-12">
<!-- DATA TABLE-->
<div class="table-responsive m-b-40">
<table class="table table-borderless table-data3">
<thead>
<tr>
<th rowspan="2">Action</th>
<th rowspan="2">ID</th>
<th rowspan="2">Name</th>
<th rowspan="2">PIN</th>
<th rowspan="2">District</th>
<th rowspan="2">Sub-Division</th>
<th rowspan="2">Village Agent Name</th>
<th rowspan="2">Address</th>
<th rowspan="2">PIN</th>
<th rowspan="2">Mobile</th>
<th colspan="2">ID Proof</th>
<th colspan="2">Address Proof</th>
<th rowspan="2">Status</th>
</tr>
<tr>
<th>type</th>
<th>Image</th>
<th>Type</th>
<th>Image</th>
</tr>
</thead>
<tbody>
@foreach($village as $list)
<tr>
<td>
<a href='{{url("$typeName/village/edit_village/")}}/{{$list->id}}'>
<button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
</a>
<a href='{{url("$typeName/village/delete/")}}/{{$list->id}}'>
<button type="button" class="btn btn-danger">Trash</button>
</a>
</td>
<td>{{$list->id}}</td>
<td>{{$list->name}}</td>
<td>{{$list->pin}}</td>
<td>{{$list->district}}</td>
<td>{{$list->sub_division}}</td>
<td>{{$list->VillageAgents->name}}</td>
<td>{{$list->VillageAgents->address}}</td>
<td>{{$list->VillageAgents->pin}}</td>
<td>{{$list->VillageAgents->mobile}}</td>
<td>
@foreach($id_proof_types as $list1)
@if($list->VillageAgents->IdProofType==$list1->id)
    {{$list1->name}}
    @break
@endif
@endforeach
</td>
<td>
<img src="{{asset('/storage/media').'/'.$list->VillageAgents->IdProofImage}}" alt="{{asset('/storage/media').'/'.$list->VillageAgents->IdProofImage}}" style="width:100px;height:100px;" />
</td>
<td>
@foreach($address_proof_types as $list1)
@if($list->VillageAgents->AddressProofType == $list1->id)
    {{$list1->AddressProofType}}
    @break
@endif
@endforeach
</td>
<td>
<img src="{{asset('/storage/media').'/'.$list->VillageAgents->AddressProofImage}}" alt="{{asset('/storage/media').$list->VillageAgents->AddressProofImage}}" style="width: 100px;height: 100px;" />
</td>
<td>
@if($list->status==1)
<span class="text-primary"> Active</span>
<a href='{{url("$typeName/village/status/0/")}}/{{$list->id}}'>
<button type="button" class="btn btn-warning">Deactivate</button>
</a>
@elseif($list->status==0)
<span class="text-danger">Inactive</span>
<a href='{{url("$typeName/village/status/1/")}}/{{$list->id}}'>
<button type="button" class="btn btn-primary">Activate</button>
</a>
@endif
</td>
</tr>
@endforeach
</tbody>
</table>
</div>
{{
$village->links();
}}
<!-- END DATA TABLE-->
</div>
</div>
@endsection