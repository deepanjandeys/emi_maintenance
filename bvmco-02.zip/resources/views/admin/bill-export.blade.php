    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Date</th>
                                                <th>Customer ID</th>
                                                <th>Customer Name</th>
                                                <th>Address</th>
                                                <th>Sale agent</th>
                                                <th>Product</th>
                                                <th>Sale Price</th>
                                                <th>Down Payment</th>
                                                <th>EMI</th>
                                                <th>EMI Period</th>
                                                <th>Date</th>                  
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($bills as $list)
                                            <tr>
                                                <td>{{$list->id}} </td>
                                                <td>{{$list->bill_date??''}} </td>
                                                <td>{{$list->customer_id}}</td>
                                                <td>{{$list->getCustomers[0]->name??''}}</td>
                                                <td>{{$list->getCustomers[0]->address??''}}</td>
                                                <td>{{$list->getSalesAgent[0]->name??''}}</td>
                                                <td>{{$list->getProduct[0]->name??''}}</td>
                                                <td>{{$list->sale_price}}</td>
                                                <td>{{$list->down_payment}}</td>
                                                <td>{{$list->EMI}}</td>
                                                <td>{{$list->EMI_Period}}</td>
                                                <td>{{\Carbon\Carbon::parse($list->created_at)->format('d/m/Y')}}</td>
                                                
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>