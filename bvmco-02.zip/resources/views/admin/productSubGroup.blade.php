@extends('admin/layout');
@section('page_title','Product Sub Group')
@section('ProductSubGroup_select','active')
@section('master_tran','master')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
@if (session('error'))
    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
 <span class="badge badge-pill badge-danger">Error Message</span>
  {{session('error')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Product Sub Group</h2>
<div class="row">
    <div class="col-3">
<a href="{{url('admin/product_sub_group/edit_product_sub_group')}}" >
<button type="button" class="btn btn-success">Add Product Sub Group</button>
</a>
    
    </div>
    <div class="col-2">
<a href="{{url('admin/product_sub_group/trash')}}" >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
<form action="" method="get" >
    <div class="row">
        <div class="col-8">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-4">
        <button class="btn btn-primary">Search</button>   
        <a href="{{url('admin/product_sub_group')}}" >
            <button type="button" class="btn btn-primary">reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Sub Group Name</th>
                                                <th>Product Group</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($product_sub_group as $list)
                                            <tr>
                                                <td>
                                                    <a href="{{url('admin/product_sub_group/edit_product_sub_group/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                                    </a>
                                                    <a href="{{url('admin/product_sub_group/delete/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                    
                                                </td>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>                                   @foreach($product_groups as $list1)
                                                    @if($list->prod_group_id==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach
                                                </td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    <a href="{{url('admin/product_sub_group/status/0/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Deactivate</button>
                                                    </a>
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                    <a href="{{url('admin/product_sub_group/status/1/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-primary">Activate</button>
                                                    </a>
                                                    @endif
                                                    
                                                </td>
                                                
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $product_sub_group->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection