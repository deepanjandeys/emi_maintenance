@extends('admin/layout');
@section('page_title','BranchStock')
@section('BranchStock_select','active')
@section('master_tran','transaction')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Stock</h2>
<div class="row">
    <div class="col-2">
<a href="{{url('admin/branchStock/purchase')}}" >
<button type="button" class="btn btn-success">Purchase</button>
</a>
    
</div>
<div class="col-2">
<a href="{{url('admin/branchStock/stockTransfer')}}" class="d-none">
<button type="button" class="btn btn-success">Stock Transfer</button>
</a>
</div>
<div class="col-2">
<a href="{{url('admin/branchStockDetails')}}" >
<button type="button" class="btn btn-warning">Transaction Details</button>
</a>
</div>
<div class="col-6 d-none">
<form action="" method="get" >
    <div class="row">
        <div class="col-6">
            <input type="search" name="search" class="form-control" placeholder="type to search" value="{{$search}}">        
        </div>
        <div class="col-6">
        <button class="btn btn-primary">Search</button>   
        <a href="{{url('admin/branch')}}" >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
        </div>
    </div>
</form>
        
    </div>
</div>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Branch</th>
                                                <th>Product</th>
                                                <th>Stock</th>
                                        <th>last Updated</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($BranchStock as $list)
                                            <tr>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->getBranch[0]->name}}</td>
                                                <td>{{$list->getProduct[0]->name}}</td>
                                                <td>{{$list->stock}}</td>
                                                <td>{{$list->updated_at}}</td>
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $BranchStock->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection