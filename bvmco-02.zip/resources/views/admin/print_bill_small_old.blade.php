<style type="text/css">
a {
    background-color: #4CAF50;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    float: right;
}

a
{
    -webkit-appearance: button;
}
a
{
    overflow: visible;
}
</style>
<?php  
$emiDates='';
foreach($emi_collections as $ec)
{
    $emiDates.=$ec->emi_date.'%0A';
}
?>
<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
<center style="vertical-align: middle;">
<a href="rawbt:
%20%20%20%20%20%20XCL SHOPPING %0A%0A
Bill No. :       %20%20<?php echo $id; ?>%0A
Bill Date     :       %20%20<?php echo date('d/m/Y',strtotime($bill_date));?>%0A
<?php echo $Customer_name; ?>%0A
<?php echo $Address;?>%0A
Mob:%20<?php echo $mobile;?>%0A
Product: %20<?php echo $product_name;?>%0A
<?php echo $remarks;?>%0A
MRP. :<?php echo $sale_price;?>%0A
DP. :<?php echo $down_payment;?>%0A
INS.   :<?php echo $interestPercntage;?>%0A
FIN.   :<?php echo $IntOnLoan;?>%0A%0A
EMI.   :<?php echo $EMI;?>%0A%0A
INSTALLMENT  Dates %0A%0A
<?php echo $emiDates;?>
" class="styled printMobile" style="Font-Size:100px; Font-Weight: Bold;" id="print1" > Print </a><br/><br/><br/><br/><br/><br/>
<a href="./admin/bills"style="Font-Size:100px; Font-Weight: Bold;">Cancel</a>
</center>
<script>
//document.getElementById("print1").click();
//window.close();
</script>