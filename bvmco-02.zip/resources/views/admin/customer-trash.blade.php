@extends('admin/layout');
@section('page_title','Customer trash')
@section('customer_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none">{{$typeName=session()->get('typeName')}}</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Customer Trash</h2>
<a href='{{url("$typeName/customer")}}' >
<button type="button" class="btn btn-success">Go to Customer</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Name</th>
                                                <th>Mobile</th>
                                                <th>PIN</th>
                                                <th>Address</th>
                                                <th>Village</th>
                                                <th>Approved</th>
                                                <th>Status</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($data as $list)
                                            <tr>
                                                <td>
                                                    <a href='{{url("$typeName/customer/restore/")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    <a href='{{url("$typeName/customer/forceDelete/")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-danger">&nbsp;Delete&nbsp;</button>
                                                    </a>
                                                    
                                                </td>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->name}}</td>
                                                <td>{{$list->mobile}}</td>
                                                <td>{{$list->pin}}</td>
                                                <td>{{$list->address}}</td>
                                                <td>                                      @foreach($Villages as $list1)
                                                    @if($list->village_id==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach
                                                </td>
                                                <td>
                                                    @if($list->isApproved==1)
                                                    <span class="text-primary"> Approved</span>
                                                    
                                                    @elseif($list->isApproved==0)
                                                    <span class="text-danger">Disapproved</span>
                                                   
                                                    @endif
                                                    
                                                </td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                   
                                                    @endif
                                                    
                                                </td>
                                                
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection