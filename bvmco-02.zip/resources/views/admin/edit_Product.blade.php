@extends('admin/layout');
@section('page_title','Edit Product')
@section('product_select','active')
@section('master_tran','master')
@section('container')
<h2 class="title-1 m-b-10">Edit Product</h2>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<a href="{{url('admin/product')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
                            
    <div class="col-lg-12">
                        
<div class="card">
    <div class="card-body">
    <form action="{{route('product.manage_product_process')}}" method="post" enctype="multipart/form-data">
    @csrf()
<div class="form-group">
<label for="code" class="control-label mb-1">code</label>
<input id="code" name="code" type="text" value="{{old('code', $code)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('code')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="Product_name" class="control-label mb-1">Product Name</label>
<input id="Product_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('name')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$GroupId=old('GroupId', $GroupId)}}</span>

<div class="form-group">
<label for="description" class="control-label mb-1">Product Description</label>
<textarea id="description" name="description" class="form-control" aria-required="true" aria-invalid="false">{{old('description', $description)}}</textarea>
@error('description')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="GroupId" class="control-label mb-1">Group</label>
<select id="GroupId" name="GroupId" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($Groups as $list)
@if($GroupId==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('GroupId')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$SubGroupId=old('SubGroupId', $SubGroupId)}}</span>
<div class="form-group">
<label for="SubGroupId" class="control-label mb-1">Sub Group</label>
<select id="SubGroupId" name="SubGroupId" class="form-control" aria-required="false" aria-invalid="false" >
<option value="">select</option>
@foreach($subGroups as $list)
@if($SubGroupId==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('SubGroupId')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="MRP" class="control-label mb-1">MRP</label>
<input id="MRP" name="MRP" type="text" value="{{old('MRP', $MRP)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('MRP')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="image" class="control-label mb-1">Image</label>
<br>
<img for="image" id="imagePreview" src="{{$imagePath}}" alt="image">
<input id="image" name="image" type="file" class="form-control" aria-required="true" onchange="readURL(this)" aria-invalid="false" accept="image/*">
<input type="hidden" name="hdImage" value="{{$image}}">
@error('image')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('status')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="{{$id}}">
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
        
function readURL(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#imagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}

</script>
@endsection