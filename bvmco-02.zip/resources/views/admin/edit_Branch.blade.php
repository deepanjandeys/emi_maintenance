@extends('admin/layout');
@section('page_title','Edit Branch')
@section('Branch_select','active')
@section('master_tran','master')
@section('container')
<h2 class="title-1 m-b-10">Edit Branch</h2>
<a href="{{url('admin/branch')}}" >
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<button type="button" class="btn btn-success">Back</button>
</a>
         <div class="row m-t-30">
                            
                                <div class="col-lg-12">
                                    
                                <div class="card">
                                    <div class="card-body">
                                        <form action="{{route('product.manage_branch_process')}}" method="post">
                                            @csrf()
                                            <div class="form-group">
                                                <label for="Branch_name" class="control-label mb-1">Branch Name</label>
                                                <input id="Branch_name" name="name" type="text" value="{{$name}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                
                                                    @error('name')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                                
                                            </div>
                                            <div class="form-group">
                                                <label for="address" class="control-label mb-1">address</label>
                                                <input id="address" name="address" type="text" value="{{$address}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    @error('address')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>

                                            <div class="form-group">
                                                <label for="pin" class="control-label mb-1">pin</label>
                                                <input id="pin" name="pin" type="text" value="{{$pin}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    @error('pin')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>
                                            <div class="form-group">
                                                <label for="mobile" class="control-label mb-1">mobile</label>
                                                <input id="mobile" name="mobile" type="text" value="{{$mobile}}" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    @error('mobile')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>
                                            <div class="form-group">
                                                <label for="status" class="control-label mb-1">status</label>
                                                    <select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
                                                        @foreach($statuses as $list)
                                                            @if($status==$list->id)
                                                        <option selected value="{{$list->id}}">{{$list->name}}</option>
                                                            @else
                                                        <option value="{{$list->id}}">{{$list->name}}</option>
                                                            @endif
                                                        @endforeach
                                                </select>
                                           
                                                    @error('status')
                                                    <div class="alert alert-danger" role="alert">
                                                    {{$message}}
                                                    </div>
                                                    @enderror
                                            </div>
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                    Submit
                                                </button>
                                            </div>
                                            <input type="hidden" name="id" value="{{$id}}">
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
@endsection