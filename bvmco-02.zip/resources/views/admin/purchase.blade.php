@extends('admin/layout');
@section('page_title','Edit Branch Stock')
@section('BranchStock_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none">
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
</span>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<h2 class="title-1 m-b-10">Purchase</h2>
<a href="{{url('admin/branchStock')}}" >
<button type="button" class="btn btn-success">Back </button>
</a>

<script type="text/javascript">

function getBranchDetails(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getBranchDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnBranchName').html('<b>Name : </b>'+obj.name);
            $('#spnBranchAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnBranchMobile').html(' <b>Mobile</b> :'+obj.mobile);
            }
        else
        {
            $('#spnBranchName').html('');
            $('#spnBranchAddress').html('');
            $('#spnBranchMobile').html('');
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getProductDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnGroup').html(' <b>Group</b> :'+obj.GroupId);
            $('#spnSubGroup').html(' <b>Sub Group</b> :'+obj.SubGroupId);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#spnProdSubGroupName').html(' <b>Product Sub Group :</b>'+obj.product_sub_group_name);
            $('#sale_price').val(obj.MRP);
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnGroup').html('');
            $('#spnSubGroup').html('');
            $('#spnProdGroupName').html('');
            $('#spnProdSubGroupName').html('');
            $('#sale_price').val('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
</script>

<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action="{{route('manage_branchStock_process')}}" method="post">
@csrf()
<div class="form-group d-none">
<label for="branch_id" class="control-label mb-1">Branch id</label>
<input list="Branches" id="branch_id" name="branch_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getBranchDetails(this.value)" value="1" required>
<datalist id="Branches">
@foreach($Branches as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
<span id="spnBranchName"></span>
<span id="spnBranchAddress"></span>
 <span id="spnBranchMobile"></span>
 @error('Sale_agent_id')
 <div class="alert alert-danger" role="alert">
 {{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
<datalist id="products">
@foreach($products as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
<span id="spnProdName"></span>
<span id="spnCode"></span>
<span id="spnImage"></span>
<span id="spnGroup"></span>
<span id="spnProdGroupName"></span>
<span id="spnSubGroup"></span>
<span id="spnProdSubGroupName"></span>
@error('product_id')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="qty" class="control-label mb-1">Quantity</label>
<input id="qty" name="qty" type="text" value="" class="form-control" aria-required="true" aria-invalid="false" required>
@error('qty')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="purchase_date" class="control-label mb-1">Purchase Date</label>
<input id="purchase_date" name="purchase_date" type="text" value="{{$purchase_date}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('purchase_date')
<div class="alert alert-danger" role="alert">
{{$message}}
</div> 
@enderror
</div>

<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="{{$id}}">
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
    

docReady(function() {

$('#purchase_date').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

});
</script>
@endsection