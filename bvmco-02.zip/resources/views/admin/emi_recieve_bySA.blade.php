@extends('admin/layout');
@section('page_title','EMI Receive')
@section('emi_receive','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
    {{$ADMIN_TYPE=session()->get('ADMIN_TYPE')}}
</span>
<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
var totalAmount=0;
var str='';
function checkAll()
{
    //debugger;
    if($('#chkAll').prop('checked'))
    {
        $(".chk").prop('checked', true);      
    }
    else
    {
        $(".chk").prop('checked', false);      
    }

    var chks = $('.chk');
    var value=0;
    totalAmount =0;

     $.each(chks, function() {
        var $this = $(this);
        if($this.is(":checked")) {
            
            value = parseFloat($('#spnPaidAmt' + $this.val()).html().replace(/,/g, ''));

        totalAmount +=value;
                }
            }); 
   $('#tdTotalAmount').html(totalAmount.toFixed(2));
}

function chk_click(v)
{
    //console.log(v);
    var value=parseFloat($('#spnPaidAmt'+v).html().replace(/,/g, ''));

    if($('#chk'+v).prop('checked'))
    {
        //$(".chk").prop('checked', true);      
        totalAmount +=value;
    }
    else
    {
        //$(".chk").prop('checked', false);      
        totalAmount -=value;
    }
    //console.log('totalAmount '+totalAmount);
    $('#tdTotalAmount').html(totalAmount.toFixed(2));
}    
</script> 
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<h2 class="title-1 m-b-10">EMI Receive by Sale Agent</h2>
<div class="row">
    <div class="col-3 d-none">
<a href='{{url("$typeName/emis/edit_collection")}}' >
<button type="button" class="btn btn-success">Collect EMI</button>
</a>
    
    </div>
    <div class="col-2 d-none">
<a href='{{url("$typeName/order/trash")}}' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()">{{$a_search_text}}</a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style={{$displaySearch}} >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Bill Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="bill_id" id="bill_id" class="form-control" placeholder="Bill Id" value="{{$bill_id}}">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($product_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="product_ids" name="product_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Products)>1)
<option value="">(all) </option>
@endif
@foreach($Products as $list)
    {{$s=''}} 
    @foreach($product_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                        <a href="javascript:void(0)" onclick="clear_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="EMI Collect Date from" value="{{$Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         Date to
                         <a href="javascript:void(0)" onclick="clear_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="EMI Collect Date To" value="{{$Date_To}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="{{$cust_name}}">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="{{$cust_mobile}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                    
                        <div class="col-lg-3">
                          Village
                          @if($ADMIN_TYPE !=4)
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          @endif
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($village_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="village_ids" name="village_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Villages)>1)
<option value="">(all) </option>
@endif
@foreach($Villages as $list)
    {{$s=''}} 
    @foreach($village_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" 
class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>    
</div>
<div class="col-lg-3">

                      Sale agents
                      @if($ADMIN_TYPE !=4)
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                    @endif
</div>
<div class="col-lg-3">

<div class="form-group">
@if(count($sale_agent_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif
<select id="sale_agent_ids" name="sale_agent_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($SalesAgents)>1)
<option value="">(all) </option>
@endif
@foreach($SalesAgents as $list)
    {{$s=''}} 
    @foreach($sale_agent_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-6 text-right">
    Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="{{$rows}}" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='{{url("$typeName/emis")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
<form action='{{route("$typeName.manage_emi_receive")}}' method="post">
@csrf()                            
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th><input type="checkbox" id="chkAll" onclick="checkAll()"><label for="chk">check All</label></th>
                                            <th>Paid Amount</th>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Due Amount</th>
                                            </tr>
            
                                        </thead>
                                        <tbody>
                                @foreach($emi_collections as $list)
                                        <tr>
                                    <td>
                                        <input type="checkbox" id="chk{{$list->id}}" name="chk{{$list->id}}" value="{{$list->id}}" onclick="chk_click(this.value)" class="chk">
                                    </td>
                                    <td style="text-align:right;"><span id="spnPaidAmt{{$list->id}}">{{$list->paid_amt}}</span></td>
                                    <td>{{$list->bill_id}}
                                    </td>
                                    <td>{{$list->emi_date}}</td>
                    <td>                                       {{$list->getBills[0]->getCustomers[0]->name}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->getVillages[0]->name??''}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->mobile??''}}</td>
                    <td style="text-align:right;">{{$list->EMI_Loan}}</td>
                    <td style="text-align:right;">{{$list->EMI_interest}}</td>
                    <td style="text-align:right;">{{$list->emi_amount}}</td>
                    <td style="text-align:right;">{{$list->fine_amount}}</td>
                    
                    <td style="text-align:right;">{{$list->due_amt}}</td>
                </tr>
                                            @endforeach
@if(count($emi_collections))                                        
            <tr>
                <td>Total</td>
                <td id="tdTotalAmount" style="text-align:right;">
                </td>                
                <td colspan="2">
<input id="receive_time" name="receive_time" type="text" class="form-control text-right" aria-required="true" aria-invalid="false" required>
                </td>
                <td colspan="3">
                    <input type="submit" name="submit" class="btn btn-success">            
                </td>
                <td colspan="5"></td>
            </tr>
@endif
                                        </tbody>

                                    </table>
        
                                </div>
                                {{
                                    $emi_collections->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

$('#receive_time').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });

@if($Date_From=='')
    $('#Date_From').val('');
@endif
@if($Date_To=='')
    $('#Date_To').val('');
@endif
});

function clear_date_from()
    {
    $('#Date_From').val('');
    }
function clear_date_to()
    {
    $('#Date_To').val('');
    }

</script>
@endsection