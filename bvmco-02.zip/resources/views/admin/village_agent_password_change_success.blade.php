@extends('admin/layout');
@section('page_title','Village Agent Password Change successfully')
@section('login_select','active')
@section('container')
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title-1 m-b-10">{{Config::get('constants.SITE_NAME')}} Village Agent Password changed Successfully</h1>   
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label">{{$name}} </label>
              </div>
              Now go to <a href="/"> Home </a> and login again
              <input type="hidden" name="id" value="{{$id}}">
            </div>
        </div>
     
    </section>
@endsection