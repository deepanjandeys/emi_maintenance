@extends('admin/layout');
@section('page_title','Place Order')
@section('order_select','active')
@section('master_tran','transaction')
@section('container')
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<h2 class="title-1 m-b-10">Place Order</h2>
<a href="{{url('sale_agent/product_list')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
<script type="text/javascript">
function getCustomerDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getCustomerDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log('getCustomerDetails '+data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
         $('#Customer_name').val(obj.name);
         $('#address').val(obj.address);
         $('#mobile').val(obj.mobile);
        }
        else  
        {
         $('#Customer_name').val('');
         $('#address').val('');
         $('#mobile').val('');      
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function getSaleAgentDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getSaleAgentDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log('getSaleAgentDetails '+data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnName').html('<b>Name : </b>'+obj.name);
            $('#spnAddress').html(' <b>Address : </b>'+obj.address);
            $('#spnMobile').html(' <b>Mobile</b> :'+obj.mobile);
         /*   $('#spnBranch').html(' <b>Branch ID :</b>'+obj.branch_id + ' <b> Branch Name </b>'+obj.branch_name);
            $('#branch_id').val(obj.branch_id);
            */
        }
        else
        {
            $('#spnName').html('');
            $('#spnAddress').html('');
            $('#spnMobile').html('');
            //$('#spnBranch').html('');
            //$('#branch_id').val(0);
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}

function getProductDetails(value) {
   $.ajax({
    type: "POST",
    url: '/getProductDetails',
    data: { id: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log('getProductDetails '+data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
            $('#spnProdName').html('<b>Name : </b>'+obj.name);
            $('#spnCode').html(' <b>Code : </b>'+obj.code);
            $('#spnImage').html('<img src="'+obj.path+obj.image+'" style="width:100px;"/>');
            $('#spnCategory').html(' <b>GroupId</b> :'+obj.GroupId);
            $('#spnProdGroupName').html(' <b>Product Group :</b>'+obj.product_group_name);
            $('#sale_price').val(obj.MRP);
            $('#spnLoanType').html('<b>Loan Type : </b> '+obj.loan_type_name);
            if(obj.loan_type==1)
            {
                $('#divIntest').hide();
            }
            else 
            {
                $('#divIntest').show();
            }
            getStockDetails();
            //calculate_LoanAmount();
            //calculate_EMI();
        }
        else
        {
            $('#spnProdName').html('');
            $('#spnCode').html('');
            $('#spnImage').html('');
            $('#spnCategory').html('');
            $('#spnProdGroupName').html('');
            $('#sale_price').val('');
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function getStockDetails() {
    var branch_id=$('#branch_id').val();
    var product_id =$('#product_id').val();
   $.ajax({
    type: "POST",
    url: '/getStockDetails',
    data: { branch_id: branch_id, product_id:product_id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        console.log('getStockDetails ' +data);
        const obj = JSON.parse(JSON.stringify(data));
      if(obj.found=='1')
        {
          $('#spnAvlStock').html('<span style="color:green;font-weight:bold;">Available stock </span>'+'<span style="color:blue;font-weight:bold;" id="spnAvlStockQty">'+obj.stock+'</span>');
          //$('#submit-button').show();
        }
        else
        {
           $('#spnAvlStock').html('<span style="color:red;font-weight:bold;">stock is not Available </span>');
           //$('#submit-button').hide();
        }
   },
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}
function calculate_LoanAmount()
{
    var sale_price  = parseFloat($('#sale_price').val());
    if(isNaN(sale_price))
        sale_price=0;

    var down_payment= parseFloat($('#down_payment').val());
    if(isNaN(down_payment))
        down_payment=0;
    var LoanAmount  = sale_price - down_payment;

    $('#LoanAmount').val(LoanAmount);
    calculate_Interest();
}
function calculate_EMI()
{
    
    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;

    var IntOnLoan   = parseFloat($('#IntOnLoan').val());
    if(isNaN(IntOnLoan))
        IntOnLoan=0;
    
    var EMI_Period  = parseInt($('#EMI_Period').val());
    if(isNaN(EMI_Period))
        EMI_Period=0;
    if(EMI_Period==0)
    {
        EMI_Period=1;
    }

    var EMI_mode    = $('#EMI_mode').val();
    var EMI=0;

    if(EMI_mode==1)
    {   // daily
        EMI=(LoanAmount+IntOnLoan)/(EMI_Period*30);
    }
    else if(EMI_mode==2)
    {
        // weekly
        EMI=(LoanAmount+IntOnLoan)/(EMI_Period*4);
    }
    else if(EMI_mode==3)
    {
        // Fort night
        EMI=(LoanAmount+IntOnLoan)/(EMI_Period*2);
    }
    else if(EMI_mode==4)
    {
        // Mobthly
        EMI=(LoanAmount+IntOnLoan)/EMI_Period;
    }

    $('#EMI').val(EMI.toFixed(2));
    calculate_Interest();
}

function calculate_EMI_period()
{
    
    var EMI_in_Months   = parseInt($('#EMI_in_Months').val());
    if(isNaN(EMI_in_Months))
        EMI_in_Months=0;
    
    var EMI_mode    = $('#EMI_mode').val();
    var EMI_Period=0;

    if(EMI_mode==1)
    {   // daily
        EMI_Period =EMI_in_Months*30;
    }
    else if(EMI_mode==2)
    {
        // weekly
        EMI_Period =EMI_in_Months*4;
    }
    else if(EMI_mode==3)
    {
        // Fort night
        EMI_Period =EMI_in_Months*2;
    }
    else if(EMI_mode==4)
    {
        // Mobthly
        EMI_Period =EMI_in_Months;
    }

    $('#EMI_Period').val(EMI_Period);
}

function calculate_Interest()
{
    //debugger;
    var LoanAmount  = parseFloat($('#LoanAmount').val());
    if(isNaN(LoanAmount))
        LoanAmount=0;
    
    var interestPercntage  = parseInt($('#interestPercntage').val());
    if(isNaN(interestPercntage))
        interestPercntage=0;
  
    var IntOnLoan   = 0;
    if(interestPercntage>0)
        IntOnLoan=LoanAmount * interestPercntage /100;

    $('#IntOnLoan').val(IntOnLoan.toFixed(2));
}

</script>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action="{{route('sale_agent.manage_order_process')}}" method="post">
@csrf()
<div class="form-group">
<label for="order_date" class="control-label mb-1">Order Date</label>
<input id="order_date" name="order_date" type="text" value="{{$order_date}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('order_date')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="customer_id" class="control-label mb-1">Customer</label>
<input list="customers" id="customer_id" name="customer_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getCustomerDetails(this.value)" required>
<datalist id="customers">
@foreach($customers as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
@error('customer_id')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="Customer_name" class="control-label mb-1">Customer Name</label>
<input id="Customer_name" type="text" class="form-control" tabindex="-1" readonly>
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">Address</label>
<input id="address" type="text" class="form-control" tabindex="-1" readonly>
</div>
<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile</label>
<input id="mobile" type="text" class="form-control" tabindex="-1" readonly>
</div>
<div class="form-group">
<label for="Sale_agent_id" class="control-label mb-1">Sale agent id</label>
<input list="SaleAgents" id="Sale_agent_id" name="Sale_agent_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getSaleAgentDetails(this.value)" required>
<datalist id="SaleAgents">
@foreach($sales_agents as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
<span id="spnName"></span>
<span id="spnAddress"></span>
<span id="spnMobile"></span>
<span id="spnBranch"></span>
@error('Sale_agent_id')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="product_id" class="control-label mb-1">Product</label>
<input list="products" id="product_id" name="product_id" class="form-control" aria-required="true" aria-invalid="false"  onchange="getProductDetails(this.value)" required>
<datalist id="products">
@foreach($products as $list)
<option value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</datalist>
<span id="spnProdName"></span>
<span id="spnCode"></span>
<span id="spnImage"></span>
<span id="spnCategory"></span>
<span id="spnProdGroupName"></span>
@error('product_id')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span id="spnAvlStock"></span>
<div class="form-group">
<label for="sale_price" class="control-label mb-1">Product price</label>
<input id="sale_price" name="sale_price" type="text" value="{{$sale_price}}" class="form-control" onchange="calculate_LoanAmount()" aria-required="true" aria-invalid="false" required>
@error('sale_price')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="down_payment" class="control-label mb-1">Down payment</label>
<input id="down_payment" name="down_payment" type="text" value="{{$down_payment}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_LoanAmount()" required>
@error('down_payment')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="LoanAmount" class="control-label mb-1">LoanAmount</label>
<input id="LoanAmount" name="LoanAmount" type="text" value="{{$LoanAmount}}" class="form-control" aria-required="true" aria-invalid="false" required onchange="calculate_EMI()">
@error('LoanAmount')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="interestPercntage" class="control-label mb-1">Interest Percentage (%)</label>
<input id="interestPercntage" name="interestPercntage" type="number" value="{{$interestPercntage}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_Interest()" required>
@error('interestPercntage')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="IntOnLoan" class="control-label mb-1">Interest On Loan</label>
<input id="IntOnLoan" name="IntOnLoan" type="text" value="{{$IntOnLoan}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
@error('IntOnLoan')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="EMI_mode" class="control-label mb-1">EMI Mode</label>
<select id="EMI_mode" name="EMI_mode" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
<option value="">select</option>
@foreach($calcmode as $list)
@if($EMI_mode==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('EMI_mode')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="EMI_in_Months" class="control-label mb-1">EMI in Months</label>
<input id="EMI_in_Months" name="EMI_in_Months" type="number" value="{{$EMI_in_Months}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI_period()" required>
@error('EMI_in_Months')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>

<div class="form-group">
<label for="EMI_Period" class="control-label mb-1">EMI_Period</label>
<input id="EMI_Period" name="EMI_Period" type="text" value="{{$EMI_Period}}" class="form-control" aria-required="true" aria-invalid="false" onchange="calculate_EMI()" required>
@error('EMI_Period')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="EMI" class="control-label mb-1">EMI</label>
<input id="EMI" name="EMI" type="text" value="{{$EMI}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('EMI')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="booking_advance" class="control-label mb-1">Booking Advance</label>
<input id="booking_advance" name="booking_advance" type="text" value="{{$booking_advance}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('booking_advance')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('status')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div>

<button id="submit-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" id="id" name="id" value="{{$id}}" >
<input type="hidden" id="branch_id" name="branch_id" value="1" >
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
docReady(function() {
    // DOM is loaded and ready for manipulation here
    getCustomerDetails(<?php echo $customer_id; ?>);
    getSaleAgentDetails(<?php echo $Sale_agent_id; ?>);
    getProductDetails(<?php echo $product_id; ?>);
    $('#customer_id').val(<?php echo $customer_id; ?>);
    $('#product_id').val(<?php echo $product_id; ?>);
    $('#Sale_agent_id').val(<?php echo $Sale_agent_id; ?>);
});

</script>
@endsection