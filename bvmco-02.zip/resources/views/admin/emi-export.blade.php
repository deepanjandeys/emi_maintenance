    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                            <th>Bill ID</th>
                                            <th>EMI Date</th>
                                            <th>Customer</th>
                                            <th>Village</th>
                                            <th>Mobile</th>
                                            <th>EMI Loan</th>
                                            <th>EMI Interest</th>
                                            <th>Total EMI</th>
                                            <th>Fine</th>
                                            <th>Paid Amount</th>
                                            <th>Due Amount</th>
                                            <th>Due Date</th>
                                            <th>Collect Date</th>
                                            <th>Receive Date</th>
                                                              
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($emis as $list)
                                            <tr>
                                               <td>{{$list->bill_id}}
                                    </td>
                                    <td>{{$list->emi_date}}</td>
                    <td>                                       {{$list->getBills[0]->getCustomers[0]->name}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->getVillages[0]->name??''}}</td>
                    <td>{{$list->getBills[0]->getCustomers[0]->mobile??''}}</td>
                    <td style="text-align:right;">{{$list->EMI_Loan}}</td>
                    <td style="text-align:right;">{{$list->EMI_interest}}</td>
                    <td style="text-align:right;">{{$list->emi_amount}}</td>
                    <td style="text-align:right;">{{$list->fine_amount}}</td>
                    <td style="text-align:right;">{{$list->paid_amt}}</td>
                    <td style="text-align:right;">{{$list->due_amt}}</td>
                    <td>{{\Carbon\Carbon::parse($list->emi_date)->format('d/m/Y')}}</td>
                    <td>{{\Carbon\Carbon::parse($list->collect_time)->format('d/m/Y')}}</td>
                    <td>{{\Carbon\Carbon::parse($list->receive_time)->format('d/m/Y')}}</td>
                                                                
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>