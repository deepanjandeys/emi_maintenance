@extends('admin/layout');
@section('page_title','Product Sub Group Trash')
@section('ProductSubGroup_select','active')
@section('master_tran','master')
@section('container')

@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Product Sub Group Trash</h2>
<a href="{{url('admin/product_sub_group')}}" >
<button type="button" class="btn btn-success">Go to Product Sub Group</button>
</a>
<div class="row m-t-30">
    <div class="col-md-12">
<!-- DATA TABLE-->
    <div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
    <thead>
    <tr>
    <th>ID</th>
    <th>Sub Group Name</th>
    <th>Product Group</th>
    <th>Action</th>
    </tr>
    </thead>
    <tbody>
    @foreach($data as $list)
    <tr>
    <td>{{$list->id}}</td>
    <td>{{$list->name}}</td>
    <td>{{$list->prod_group_id}}</td>
    <td>
<a href="{{url('admin/product_sub_group/restore/')}}/{{$list->id}}">
    <button type="button" class="btn btn-success">Restore</button>
    </a>
<a href="{{url('admin/product_sub_group/forceDelete/')}}/{{$list->id}}">
<button type="button" class="btn btn-danger">Delete</button>
</a>
</td>
</tr>
@endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection