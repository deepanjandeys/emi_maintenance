@extends('admin/layout');
@section('page_title','Edit Sales Agent')
@section('sale_agent_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none"> 
@if($id>0)
    {{$password_required=""}}
    {{$password_class="d-none"}}
@else
    {{$password_required="required"}}
    {{$password_class=""}}
@endif
{{$AJAX_ROOT=Config::get('constants.AJAX_ROOT')}}
</span>
<script type="text/javascript">
function getCheckMobileUnique(value) {
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/getCheckMobileUnique',
    data: { mobile: value, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#spnIsMobileNoUsedEarlier').html(obj.message);
            $('#spnIsMobileNoUsedEarlier').show();
        }
        else 
        {
            $('#spnIsMobileNoUsedEarlier').html('');
            $('#spnIsMobileNoUsedEarlier').hide();
        }
   },   
    error: function (data, textStatus, errorThrown) {
        console.log(data);
 
    },
});
}

function setDefaultPasswordSA(id) {
    if (confirm("do You wabt to reset password to default password !") == false) 
    { 
  return;
    } 
   $.ajax({
    type: "POST",
    url: '/{{$AJAX_ROOT}}/setDefaultPasswordSA',
    data: { id: id, _token: '{{csrf_token()}}' },
    success: function (data) 
    {
        //console.log(' ** '+ data);
        const obj = JSON.parse(JSON.stringify(data));
        if(obj.found=='1')
        {
            $('#divPwd'+id).html(obj.msg);
           
            }
        else
        {
            $('#divPwd'+id).html('');
           
        }
    
    },
    error: function (data, textStatus, errorThrown) {
        console.log(data+' '+textStatus+' '+errorThrown);
 
    },
});
}
</script>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<h2 class="title-1 m-b-10">Edit Sales Agent</h2>
<a href="{{url('admin/sale_agent')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
<form action="{{route('product.manage_sale_agent_process')}}" method="post">
@csrf()
<div class="form-group">
<label for="SaleAgent_name" class="control-label mb-1">Sales Agent Name</label>
<input id="SaleAgent_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('name')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">address</label>
<input id="address" name="address" type="text" value="{{old('address', $address)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('address')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="pin" class="control-label mb-1">pin</label>
<input id="pin" name="pin" type="text" value="{{old('pin', $pin)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('pin')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="mobile" class="control-label mb-1">mobile</label>
<input id="mobile" name="mobile" type="text" value="{{old('mobile', $mobile)}}" class="form-control" onchange="getCheckMobileUnique(this.value)" aria-required="true" aria-invalid="false" required>
<span id="spnIsMobileNoUsedEarlier" class="text-danger font-weight-bold"style="display:none;"></span>
@error('mobile')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="email" class="control-label mb-1">email</label>
<input id="email" name="email" type="text" value="{{old('email', $email)}}" class="form-control" aria-required="true" aria-invalid="false" >
@error('email')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>


@if($id==0)
<div class="form-group {{$password_class}}">
<label for="password" class="control-label mb-1">Password</label>
<input id="password" name="password" type="text" value="{{$password}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('password')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
@else
<a href="javascript:void(0)" 
  onclick="setDefaultPasswordSA({{$id}})">Reset Password</a>
<div id="divPwd{{$id}}"></div>
@endif


<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('status')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="{{$id}}">
<input type="hidden" name="admin_id" value="{{$admin_id}}">
</form>
</div>
</div>
</div>
</div>
@endsection