@extends('admin/layout');
@section('page_title','Order')
@section('order_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
    {{$ADMIN_TYPE=session()->get('ADMIN_TYPE')}}
</span>

<script type="text/javascript">
    function set_multiple_village()
    {
        $('#village_ids').attr('multiple','multiple');
        $('#spnVillageMessage').show();
    }

    function set_multiple_sale_agent()
    {
        $('#sale_agent_ids').attr('multiple','multiple');
        $('#spnSaleAgentMessage').show();
    }

    function set_multiple_product()
    {
        if($('#a_product').html()=='Select multiple product')
        {
            $('#product_ids').attr('multiple','multiple');
            $('#spnProductMessage').show();
            $('#a_product').html('Select Single product');
        }
        else 
        {
            $('#product_ids').attr('multiple','none');
            $('#spnProductMessage').hide();
            $('#a_product').html('Select multiple product');
        }
        
    }
    
</script> 
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif

<h2 class="title-1 m-b-10">Orders</h2>
<div class="row">
    <div class="col-3">
<a href='{{url("$typeName/order/edit_order")}}' >
<button type="button" class="btn btn-success">Add Order</button>
</a>
    
    </div>
    <div class="col-2">
<a href='{{url("$typeName/order/trash")}}' >
<button type="button" class="btn btn-danger">go to Trash</button>
</a>
        
    </div>
    <div class="col-7">
        <a id="a_search" class="btn btn-warning text-danger font-weight-bold" href="javascript:void(0)" onclick="show_hide_search()">{{$a_search_text}}</a>
    </div>

        <div class="col-lg-12">

<form action="" method="get" >    
                   <!-- Table with stripped rows -->
                   <div id="divSearch" class="bg-warning text-danger font-weight-bold" style={{$displaySearch}} >
        <fieldset class="p-2 rounded"><legend>Search</legend>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Order Id
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="id" id="id" class="form-control" placeholder="Order Id" value="{{$id}}">
                        </div>
                                          <div class="col-lg-3">
                          Product
                          <a href="javascript:void(0)" id="a_product" onclick="set_multiple_product()">Select multiple product</a>
                          <span id="spnProductMessage" style="display:none;">use Ctrl+ Click to select multiple product</span>
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($product_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="product_ids" name="product_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Products)>1)
<option value="">(all) </option>
@endif
@foreach($Products as $list)
    {{$s=''}} 
    @foreach($product_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
                      </div>
            <div class="row py-1">
                        <div class="col-lg-3">
                          Date From
                          <br>
                          <a href="javascript:void(0)" onclick="clear_date_from()">Clear Date form</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_From" id="Date_From" class="form-control" placeholder="Order Date from" value="{{$Date_From}}">
                        </div>
                        <div class="col-lg-3">
                         Date to<br>
                         <a href="javascript:void(0)" onclick="clear_date_to()">Clear Date to</a>
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="Date_To" id="Date_To" placeholder="Order Date To" value="{{$Date_To}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        <div class="col-lg-3">
                          Customer Name
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_name" id="cust_name" class="form-control" placeholder="Customer Name" value="{{$cust_name}}">
                        </div>
                        <div class="col-lg-3">
                         Mobile Number
                        </div>
                        <div class="col-lg-3 col-sm-9 col-xs-9">
                          <input type="text" name="cust_mobile" id="cust_mobile" placeholder=" Customer Mobile Number" value="{{$cust_mobile}}" class="form-control">
                        </div>
                      </div>
                      <div class="row py-1">
                        
                        <div class="col-lg-3">
                          Village
                          @if($ADMIN_TYPE !=4)
                          <a href="javascript:void(0)" id="a_village" onclick="set_multiple_village()">Select multiple village</a>
                          <span id="spnVillageMessage" style="display:none;">use Ctrl+ Click to select multiple Village</span>
                          @endif
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($village_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="village_ids" name="village_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
@if(count($Villages)>1)
<option value="">(all) </option>
@endif
@foreach($Villages as $list)
    {{$s=''}} 
    @foreach($village_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-lg-3">
<label for="status" class="control-label mb-1">status</label>    
</div>
<div class="col-lg-3">
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" >
<option value="">select</option>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>    
</div>
                  <div class="col-lg-3">
                          Sale agents
                          @if($ADMIN_TYPE==1)
                          <a href="javascript:void(0)" onclick="set_multiple_sale_agent()">Select multiple sale agent</a>
                          <span id="spnSaleAgentMessage" style="display:none;">use Ctrl+ Click to select multiple sale agent</span>
                          @endif
                        </div>
                        <div class="col-lg-3">
                        <div class="form-group">
@if(count($sale_agent_ids)>1)
    {{$m='multiple'}}
@else
    {{$m=''}}
@endif


<select id="sale_agent_ids" name="sale_agent_ids[]" {{$m}} class="form-control" aria-required="true" aria-invalid="false" >
<option value="">(all) </option>
@foreach($SalesAgents as $list)
    {{$s=''}} 
    @foreach($sale_agent_ids as $list1)
        @if($list1==$list->id)
            {{$s='selected'}}
            @break;
        @endif
    @endforeach
<option {{$s}} value="{{$list->id}}">{{$list->name}}</option>
@endforeach
</select>
</div>
</div>
<div class="col-6 text-right">
Rows <input type="text" style="text-align: right; padding-right: 10px;" name="rows" value="{{$rows}}" size="2"> per page
    <button class="btn btn-primary">Search</button>   
    <a href='{{url("$typeName/orders")}}' >
            <button type="button" class="btn btn-primary">Reset</button>
        </a>     
</div>
</div>

</fieldset>
</div>
</form>
</div>

</div>
<div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Order Date</th>
                                                <th>Product</th>
                                                <th>Customer ID/Name</th>
                                                <th>Village</th>
                                                <th>Sale Agent Code/Name</th>
                                                <th>Sale Price</th>
                                                <th>Down Payment</th>
                                                <th>Advance Booking</th>
                                                <th>EMI</th>
                                                <th>EMI Mode</th>
                                                <th>EMI Period</th>
                                                <th>Status</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($orders as $list)
                                        <span class="d-none">
                                            @if(isset($list->bill_id))
                                                {{$btnClass="btn-primary"}}
                                                {{$actionBill="Edit "}}
                                            @else
                                                {{$btnClass="btn-warning"}}
                                                {{$actionBill="Generate "}}
                                            @endif
                                            </span>    
                                            <tr>
                                                <td>
                                                    @if($list->bill_id=='')
                                                    <a href='{{url("$typeName/order/edit_order")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-success">&nbsp;&nbsp;Edit&nbsp;&nbsp;</button>
                                                    </a>
                                                    @endif
                                                </td>
                                                <td>{{$list->id}}
                                                 <a href='{{url("$typeName/bill/edit_bill")}}/{{$list->bill_id??"0"}}/{{$list->id}}'>
                                                    <button type="button" title="{{$actionBill}}" class="btn {{$btnClass}}">&nbsp;&nbsp;Bill&nbsp;&nbsp;</button>
                                                    </a> {{$actionBill}}
                                                </td>
                                                <td>{{$list->order_date}}</td>
                                                <td>{{$list->getProduct[0]->name}}</td>
                                                <td>{{$list->customer_id}}/ {{$list->getCustomers[0]->name}} {{$list->getCustomers[0]->mobile}}</td>
                                                <td>{{$list->getCustomers[0]->getVillages[0]->name}}  {{$list->getCustomers[0]->address}}</td>
                                                <td>{{$list->getSalesAgent[0]->id}}/ {{$list->getSalesAgent[0]->name}}</td>        
                                                <td>{{$list->sale_price}}</td>
                                                <td  style="text-align:right;font-weight: bold;">{{$list->down_payment}}</td>
                                                <td style="text-align:right;font-weight: bold;">{{$list->booking_advance}}</td>
                                                <td>{{$list->EMI}}</td>
                                                <td>                                        @foreach($calcmode as $list1)
                                                    @if($list->EMI_mode==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach</td>
                                                <td>{{$list->EMI_Period}}</td>
                                                <td>
                                                    @if($list->status==1)
                                                    <span class="text-primary"> Active</span>
                                                    <a href="{{url('admin/order/status/0/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-warning">Deactivate</button>
                                                    </a>
                                                    @elseif($list->status==0)
                                                    <span class="text-danger">Inactive</span>
                                                    <a href="{{url('admin/order/status/1/')}}/{{$list->id}}">
                                                    <button type="button" class="btn btn-primary">Activate</button>
                                                    </a>
                                                    @endif
                                                    
                                                </td>
                                                <td>
                                                    @if($list->bill_id=='')
                                                    <a href='{{url("$typeName/order/delete")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-danger">Trash</button>
                                                    </a>
                                                    @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                          <tr>
                                              <td colspan="9" style="text-align:right;color: red;font-weight: bold;">
                                                  Total Advance Booking
                                              </td>
                                              <td style="text-align:right;color: blue;font-weight: bold;">{{$sumAdvBooking}}</td>
                                              <td colspan="5"></td>
                                          </tr>  
                                        </tbody>

                                    </table>
                                </div>
                                {{
                                    $orders->links();
                                }}
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
<script type="text/javascript">
    docReady(function() {
$('#Date_From').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });
$('#Date_To').daterangepicker({
      singleDatePicker: true,
      showDropdowns: true,
      
       locale: {
        format: 'DD-MM-YYYY'
      }
    });


@if($Date_From=='')
    $('#Date_From').val('');
@endif
@if($Date_To=='')
    $('#Date_To').val('');
@endif

});


function clear_date_from()
    {
    $('#Date_From').val('');
    }
function clear_date_to()
    {
    $('#Date_To').val('');
    }

</script>

@endsection