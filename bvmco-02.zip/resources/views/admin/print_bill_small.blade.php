<?php  
$emiDates='';
foreach($emi_collections as $ec)
{
    $emiDates.=$ec->emi_date.'%0A';
}
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        .container {
            background-color: #f5deb3;
            width: 200px;
            height: 250px;
            border: 2px solid black;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .button {
            width: 150px;
            height: 50px;
            margin: 10px;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        .print {
            background-color: #28a745;
        }
        .cancel {
            background-color: #ff7043;
        }
    </style>
</head>
<body>
    <center>
    <div class="container">
<a href="rawbt:
%20%20%20%20%20%20XCL SHOPPING %0A%0A
Bill No. :       %20%20<?php echo $id; ?>%0A
Bill Date     :       %20%20<?php echo date('d/m/Y',strtotime($bill_date));?>%0A
<?php echo $Customer_name; ?>%0A
<?php echo $Address;?>%0A
Mob:%20<?php echo $mobile;?>%0A
Product: %20<?php echo $product_name;?>%0A
<?php echo $remarks;?>%0A
MRP. :<?php echo $sale_price;?>%0A
DP. :<?php echo $down_payment;?>%0A
INS.   :<?php echo $interestPercntage;?>%0A
FIN.   :<?php echo $IntOnLoan;?>%0A%0A
EMI.   :<?php echo $EMI;?>%0A%0A
INSTALLMENT  Dates %0A%0A
<?php echo $emiDates;?>
"><button class="button print" id="print1">Print</button></a>
<a href="/admin/bills"><button class="button cancel">Cancel</button></a>
</div>
</center>
<script type="text/javascript">
//document.getElementById("print1").click();
//window.close();
</script>

</body>
</html>
