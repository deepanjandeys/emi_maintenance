@extends('admin/layout');
@section('page_title','Edit Product Sub Group')
@section('ProductSubGroup_select','active')
@section('master_tran','master')
@section('container')
<h2 class="title-1 m-b-10">Edit Product Sub Group</h2>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      

<a href="{{url('admin/product_sub_group')}}" >
<button type="button" class="btn btn-success">Back</button>
</a>
 <div class="row m-t-30">
     <div class="col-lg-12">
         <div class="card">
            <div class="card-body">
            <form action="{{route('product.manage_product_sub_group_process')}}" method="post">
            @csrf()
        <div class="form-group">
        <label for="ProductGroup_name" class="control-label mb-1">Product Sub Group Name</label>
        <input id="ProductGroup_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
        @error('name')
        <div class="alert alert-danger" role="alert">
        {{$message}}
        </div>
        @enderror
        </div>
<span class="d-none">{{$prod_group_id=old('prod_group_id', $prod_group_id)}}</span>        
    <div class="form-group">
    <label for="prod_group_id" class="control-label mb-1">Product Group</label>
    <select id="prod_group_id" name="prod_group_id" class="form-control" aria-required="true" aria-invalid="false" required>
    <option>select</option>
    @foreach($product_groups as $list)
    @if($prod_group_id==$list->id)
    <option selected value="{{$list->id}}">{{$list->name}}</option>
    @else
    <option value="{{$list->id}}">{{$list->name}}</option>
    @endif
    @endforeach
    </select>
    @error('prod_group_id')
    <div class="alert alert-danger" role="alert">
    {{$message}}
    </div>
    @enderror
    </div>
    <div class="form-group">
    <label for="status" class="control-label mb-1">status</label>
    <select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
    @foreach($statuses as $list)
    @if($status==$list->id)
    <option selected value="{{$list->id}}">{{$list->name}}</option>
    @else
    <option value="{{$list->id}}">{{$list->name}}</option>
    @endif
    @endforeach
    </select>
    @error('status')
    <div class="alert alert-danger" role="alert">
    {{$message}}
    </div>
    @enderror
    </div>
    <div>
    <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
    Submit</button>
    </div>
    <input type="hidden" name="id" value="{{$id}}">
                                        </form>
                                    </div>
                                </div>
                            </div>              
                        </div>
@endsection