@extends('admin/layout');
@section('page_title','Admin Change Password')
@section('login_select','active')
@section('container')
<script type="text/javascript">
  function SignUp_click()
  {
    window.location='/sign_up';
  }
  
 </script>
<section class="get_in_touch">
        <h1 class="title">{{Config::get('constants.SITE_NAME')}} Admin Reset Password</h1>
        <form action="{{route('admin.admin_password_set')}}" method="post">
            @csrf
        <div class="container">
           @if (session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="user" class="label">User </label>
              </div>
              <div class="form-field col-lg-4">
                  <label for="user" class="label">{{$name}} </label>
              </div>
              <input type="hidden" name="id" value="{{$id}}">
            </div>
            <div class="contact-form row d-none">
              <div class="form-field col-lg-4">
                  <label for="password" class="label">Old Password</label>
              </div>
              <div class="form-field col-lg-8">
                <input type="password" name="password" id="password" class="input-text" value="{{old('password')}}">
              </div>
            </div>
            <div class="contact-form row">
              <div class="form-field col-lg-4">
                  <label for="newPassword" class="label">New Password</label>
              </div>
              <div class="form-field col-lg-8">
                <input type="password" name="newPassword" id="newPassword" class="input-text" value="{{old('newPassword')}}">
              </div>
            </div>
            <div class="row">
              <div class="col-lg-6">
              @error('password')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror
              </div>
              <div class="col-lg-6">
              @error('newPassword')
                   <div class="alert alert-danger" role="alert">
                    {{$message}}
                    </div>
                    @enderror

              </div>
              
            </div>
            <div class="contact-form row">
              
               <div class="form-field col-lg-6">
                
               </div>
               <div class="form-field col-lg-6">
                <input class="submit-btn" type="submit" value="Reset" name="Reset">
               </div>
            </div>
        </div>
      </form>
    </section>
@endsection