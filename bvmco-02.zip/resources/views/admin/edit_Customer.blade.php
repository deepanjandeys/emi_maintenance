@extends('admin/layout');
@section('page_title','Edit Customer')
@section('customer_select','active')
@section('master_tran','master')
@section('container')
<span class="d-none"> 
@if($id>0)
    {{$image_required=""}}
@else
    {{$image_required="required"}}
@endif
{{$typeName=session()->get('typeName')}}</span>
<h2 class="title-1 m-b-10">Edit Customer</h2>
@if($errors->any())
    <div class="text-danger font-weight-bold">There are some error Occured during save data, please fix the error</div>
@endif      
<a href='{{url("$typeName/customer")}}' >
<button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
<form action='{{route("$typeName.manage_customer_process")}}' method="post"  enctype="multipart/form-data">
@csrf()
<div class="form-group">
<label for="Customer_name" class="control-label mb-1">Customer Name</label>
<input id="Customer_name" name="name" type="text" value="{{old('name', $name)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('name')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="address" class="control-label mb-1">Address</label>
<input id="address" name="address" type="text" value="{{old('address', $address)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('address')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="pin" class="control-label mb-1">PIN</label>
<input id="pin" name="pin" type="text" value="{{old('pin', $pin)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('pin')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="mobile" class="control-label mb-1">Mobile</label>
<input id="mobile" name="mobile" type="text" value="{{old('mobile', $mobile)}}" class="form-control" aria-required="true" aria-invalid="false" required>
@error('mobile')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$village_id=old('village_id', $village_id)}}</span>
<div class="form-group">
<label for="village_id" class="control-label mb-1">Village</label>
<select id="village_id" name="village_id" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($Villages as $list)
@if($village_id==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('village_id')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$IdProofType=old('IdProofType', $IdProofType)}}</span>
<div class="form-group">
<label for="IdProofType" class="control-label mb-1">id proof type </label>

<select id="IdProofType" name="IdProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($id_proof_types as $list)
@if($IdProofType==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('IdProofType')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="file" class="control-label mb-1">Id Proof Image</label>
<br>
<img for="IdProofImage" id="IdProofImagePreview" src="{{$IDProofImagePath}}" alt="ID Proof Image"> 
<input id="IdProofImage" name="IdProofImage" type="file" class="form-control" aria-required="true" aria-invalid="false" accept="image/*" onchange="readURLidProof(this)" {{$image_required}}>
<input type="text" name="hdIdProofImage" value="{{$IdProofImage}}">
@error('IdProofImage')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<span class="d-none">{{$AddressProofType=old('AddressProofType', $AddressProofType)}}</span>
<div class="form-group">
<label for="AddressProofType" class="control-label mb-1">Address proof type </label>

<select id="AddressProofType" name="AddressProofType" class="form-control" aria-required="true" aria-invalid="false" required>
<option value="">select</option>
@foreach($address_proof_types as $list)
@if($AddressProofType==$list->id)
<option selected value="{{$list->id}}">{{$list->AddressProofType}}</option>
@else
<option value="{{$list->id}}">{{$list->AddressProofType}}</option>
@endif
@endforeach
</select>
@error('AddressProofType')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="file" class="control-label mb-1">Address Proof Image</label>
<br>
<img for="AddressProofImage" id="AddressProofImagePreview" src="{{$AddressProofImagePath}}" alt="Address Proof Image">
<input id="AddressProofImage" name="AddressProofImage" type="file" class="form-control" onchange="readURLaddress(this)" accept="image/*" aria-required="true" aria-invalid="false" {{$image_required}}>
<input type="hidden" name="hdAddressProofImage" value="{{$AddressProofImage}}">
@error('AddressProofImage')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="isApproved" class="control-label mb-1">Approved</label>
<select id="isApproved" name="isApproved" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($isApproved==$list->id)s
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('isApproved')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div class="form-group">
<label for="status" class="control-label mb-1">status</label>
<select id="status" name="status" class="form-control" aria-required="true" aria-invalid="false" required>
@foreach($statuses as $list)
@if($status==$list->id)
<option selected value="{{$list->id}}">{{$list->name}}</option>
@else
<option value="{{$list->id}}">{{$list->name}}</option>
@endif
@endforeach
</select>
@error('status')
<div class="alert alert-danger" role="alert">
{{$message}}
</div>
@enderror
</div>
<div>
<button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
Submit
</button>
</div>
<input type="hidden" name="id" value="{{$id}}">
</form>
</div>
</div>
</div>
</div>
<script type="text/javascript">
    
function readURLidProof(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#IdProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}

function readURLaddress(input) {
    //alert(input.files[0]);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    
    reader.onload = function(e) {
      $('#AddressProofImagePreview').attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]);
  }
}

</script>
@endsection