@extends('admin/layout');
@section('page_title','Order')
@section('bill_select','active')
@section('master_tran','transaction')
@section('container')
<span class="d-none"> 
    {{$typeName=session()->get('typeName')}}
</span>
@if(session()->has('message'))
<div class="sufee-alert alert with-close alert-success alert-dismissible fade show">
 <span class="badge badge-pill badge-success">Message</span>
  {{session('message')}}
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
@endif
<h2 class="title-1 m-b-10">Bill Trash</h2>
<a href='{{url("$typeName/bills")}}' >
<button type="button" class="btn btn-success">Go to Bill</button>
</a>
         <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>Action</th>
                                                <th>ID</th>
                                                <th>Bill date</th>
                                                <th>Customer ID</th>
                                            <th>Customer Name</th>
                                                <th>Address</th>
                                                <th>Sale Price</th>
                                            <th>Down Payment</th>
                                                <th>EMI</th>
                                                <th>EMI Mode</th>
                                                <th>EMI Period</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($data as $list)
                                            <tr>
                                                <td>
                                                    <a href='{{url("$typeName/bill/restore")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-success">Restore</button>
                                                    </a>
                                                    
                                                    <a href='{{url("$typeName/bill/forceDelete")}}/{{$list->id}}'>
                                                    <button type="button" class="btn btn-danger">&nbsp;Delete&nbsp;</button>
                                                    </a>
                                                    
                                                </td>
                                                <td>{{$list->id}}</td>
                                                <td>{{$list->bill_date}}</td>
                                                <td>{{$list->customer_id}}</td>
                                                <td>{{$list->getCustomers[0]->name}}</td>
                                                <td>{{$list->getCustomers[0]->address}}</td>
                                                <td>{{$list->sale_price}}</td>
                                                <td>{{$list->down_payment}}</td>
                                                <td>{{$list->EMI}}</td>
                                                <td>@foreach($calcmode as $list1)
                                                    @if($list->EMI_mode==$list1->id)
                                                        {{$list1->name}}
                                                    @break
                                                    @endif
                                                @endforeach</td>
                                                <td>{{$list->EMI_Period}}</td>
                                                
                                                
                                            </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
@endsection