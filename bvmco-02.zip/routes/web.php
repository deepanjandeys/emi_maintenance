<?php
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\VillageController;
use App\Http\Controllers\SalesAgentController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductGroupController;
use App\Http\Controllers\ProductSubGroupController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\BillController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\IdProofTypeController;
use App\Http\Controllers\AddressProofTypeController;
use App\Http\Controllers\BranchStockController;
use App\Http\Controllers\BranchStockDetailsController;
use App\Http\Controllers\AjaxController;
use App\Http\Controllers\EMICollectionController;
use App\Http\Controllers\UserExportController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});
/*
Route::get('data', [IndexController::class,'index'])->middleware('gourd');
Route::get('group', [IndexController::class,'group'])->middleware('gourd');
*/
Route::get('data', [IndexController::class,'index']);
Route::get('group', [IndexController::class,'group']);
Route::get('/UserExport', [UserExportController::class,'export']);
Route::get('/BillExport', [BillController::class,'export']);
Route::get('/EMIExport', [EMICollectionController::class,'export']);
Route::get('no-access', function () {
    echo 'no access';
});
Route::get('login', function () 
{
    session()->put('user_id',1);
});
Route::group(['middleware'=>'admin_auth'],function()
    {
        Route::get('admin/dashboard', [AdminController::class,'dashboard']);
////////////////////////////////////

        Route::get('admin/product_group', [ProductGroupController::class,'index']);
        Route::get('admin/product_group/edit_product_group', [ProductGroupController::class,'edit_product_group']);
        Route::get('admin/product_group/edit_product_group/{id}', [ProductGroupController::class,'edit_product_group']);
        Route::get('admin/product_group/delete/{id}', [ProductGroupController::class,'delete']);
        Route::get('admin/product_group/trash', [ProductGroupController::class,'trash']);
        Route::get('admin/product_group/forceDelete/{id}', [ProductGroupController::class,'forceDelete']);
        Route::get('admin/product_group/restore/{id}', [ProductGroupController::class,'restore']);

        Route::get('admin/product_group/status/{status}/{id}', [ProductGroupController::class,'status']);
        Route::post('admin/prodcuct_group/manage_product_group_process', [ProductGroupController::class,'manage_product_group_process'])->name('product.manage_product_group_process');
////////////////////////////////////
Route::get('admin/product_sub_group', [ProductSubGroupController::class,'index']);
        Route::get('admin/product_sub_group/edit_product_sub_group', [ProductSubGroupController::class,'edit_product_sub_group']);
        Route::get('admin/product_sub_group/edit_product_sub_group/{id}', [ProductSubGroupController::class,'edit_product_sub_group']);
        Route::get('admin/product_sub_group/delete/{id}', [ProductSubGroupController::class,'delete']);
        Route::get('admin/product_sub_group/trash', [ProductSubGroupController::class,'trash']);
        Route::get('admin/product_sub_group/forceDelete/{id}', [ProductSubGroupController::class,'forceDelete']);
        Route::get('admin/product_sub_group/restore/{id}', [ProductSubGroupController::class,'restore']);

        Route::get('admin/product_sub_group/status/{status}/{id}', [ProductSubGroupController::class,'status']);
        Route::post('admin/prodcuct_sub_group/manage_product_sub_group_process', [ProductSubGroupController::class,'manage_product_sub_group_process'])->name('product.manage_product_sub_group_process');
////////////////////////////////////
        Route::get('admin/branch', [BranchController::class,'index']);
        Route::get('admin/branch/edit_branch', [BranchController::class,'edit_branch']);
        Route::get('admin/branch/edit_branch/{id}', [BranchController::class,'edit_branch']);
        Route::get('admin/branch/delete/{id}', [BranchController::class,'delete']);
        Route::get('admin/branch/trash', [BranchController::class,'trash']);
        Route::get('admin/branch/forceDelete/{id}', [BranchController::class,'forceDelete']);
        Route::get('admin/branch/restore/{id}', [BranchController::class,'restore']);

        Route::get('admin/branch/status/{status}/{id}', [BranchController::class,'status']);
        Route::post('admin/branch/manage_branch_process', [BranchController::class,'manage_branch_process'])->name('product.manage_branch_process');
////////////////////////////////////

        Route::get('admin/product', [ProductController::class,'index']);
        Route::get('admin/product/edit_product', [ProductController::class,'edit_product']);
        Route::get('admin/product/edit_product/{id}', [ProductController::class,'edit_product']);
        Route::get('admin/product/delete/{id}', [ProductController::class,'delete']);
        Route::get('admin/product/trash', [ProductController::class,'trash']);
        Route::get('admin/product/forceDelete/{id}', [ProductController::class,'forceDelete']);
        Route::get('admin/product/restore/{id}', [ProductController::class,'restore']);

        Route::get('admin/product/status/{status}/{id}', [ProductController::class,'status']);
        Route::post('admin/prodcuct/manage_product_process', [ProductController::class,'manage_product_process'])->name('product.manage_product_process');

////////////////////////////////////

        Route::get('admin/sale_agent', [SalesAgentController::class,'list']);
        Route::get('admin/sale_agent/edit_sale_agent', [SalesAgentController::class,'edit_sale_agent']);
        Route::get('admin/sale_agent/edit_sale_agent/{id}', [SalesAgentController::class,'edit_sale_agent']);
        Route::get('admin/sale_agent/delete/{id}', [SalesAgentController::class,'delete']);
        Route::get('admin/sale_agent/trash', [SalesAgentController::class,'trash']);
        Route::get('admin/sale_agent/forceDelete/{id}', [SalesAgentController::class,'forceDelete']);
        Route::get('admin/sale_agent/restore/{id}', [SalesAgentController::class,'restore']);

        Route::get('admin/sale_agent/status/{status}/{id}', [SalesAgentController::class,'status']);
        Route::post('admin/sale_agent/manage_sale_agent_process', [SalesAgentController::class,'manage_sale_agent_process'])->name('product.manage_sale_agent_process');
////////////////////////////////////

        Route::get('admin/customer', [CustomerController::class,'index']);
        Route::get('admin/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('admin/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('admin/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('admin/customer/trash', [CustomerController::class,'trash']);
        Route::get('admin/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('admin/customer/restore/{id}', [CustomerController::class,'restore']);

        Route::get('admin/customer/status/{status}/{id}', [CustomerController::class,'status']);
        Route::get('admin/customer/approve/{approve}/{id}', [CustomerController::class,'approve']);
        Route::post('admin/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('admin.manage_customer_process');
////////////////////////////////////////////////////////////////////////

        Route::get('admin/village', [VillageController::class,'list']);
        Route::get('admin/village/edit_village', [VillageController::class,'edit_village']);
        Route::get('admin/village/edit_village/{id}', [VillageController::class,'edit_village']);
        Route::get('admin/village/delete/{id}', [VillageController::class,'delete']);
        Route::get('admin/village/trash', [VillageController::class,'trash']);
        Route::get('admin/village/forceDelete/{id}', [VillageController::class,'forceDelete']);
        Route::get('admin/village/restore/{id}', [VillageController::class,'restore']);

        Route::get('admin/village/status/{status}/{id}', [VillageController::class,'status']);
        Route::post('admin/village/manage_village_process', [VillageController::class,'manage_village_process'])->name('admin.manage_village_process');
//////////////////////////////////// ///////////////////////////////////

        Route::get('admin/orders', [OrderController::class,'index']);
        Route::get('admin/order/edit_order', [OrderController::class,'edit_order']);
        Route::get('admin/order/edit_order/{id}', [OrderController::class,'edit_order']);
        Route::get('admin/order/delete/{id}', [OrderController::class,'delete']);
        Route::get('admin/order/trash', [OrderController::class,'trash']);
        Route::get('admin/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
        Route::get('admin/order/restore/{id}', [OrderController::class,'restore']);

        Route::get('admin/order/status/{status}/{id}', [OrderController::class,'status']);
        Route::post('admin/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('admin.manage_order_process');
////////////////////////////////////
///////////////////////////////////

        Route::get('admin/bills', [BillController::class,'index']);
        Route::get('admin/bill/edit_bill', [BillController::class,'edit_bill']);
        Route::get('admin/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
        Route::get('admin/bill/print_bill/{id}', [BillController::class,'print_bill']);
        Route::get('admin/bill/print_bill_to_pdf/{id}', [BillController::class,'print_bill_to_pdf']);
        Route::get('admin/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
        Route::get('admin/bill/view_bill/{id}', [BillController::class,'view_bill']);
        Route::get('admin/bill/delete/{id}', [BillController::class,'delete']);
        Route::get('admin/bill/trash', [BillController::class,'trash']);
        Route::get('admin/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
        Route::get('admin/bill/restore/{id}', [BillController::class,'restore']);

        Route::get('admin/bill/status/{status}/{id}', [BillController::class,'status']);
        Route::post('admin/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('admin.manage_bill_process');
        Route::get('admin/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
////////////////////////////////////

        Route::get('admin/idProofType', [IdProofTypeController::class,'index']);
        Route::get('admin/idProofType/edit_idProofType', [IdProofTypeController::class,'edit_idProofType']);
        Route::get('admin/idProofType/edit_idProofType/{id}', [IdProofTypeController::class,'edit_idProofType']);
        Route::get('admin/idProofType/delete/{id}', [IdProofTypeController::class,'delete']);
        Route::get('admin/idProofType/trash', [IdProofTypeController::class,'trash']);
        Route::get('admin/idProofType/forceDelete/{id}', [IdProofTypeController::class,'forceDelete']);
        Route::get('admin/idProofType/restore/{id}', [IdProofTypeController::class,'restore']);

        Route::get('admin/idProofType/status/{status}/{id}', [IdProofTypeController::class,'status']);
        Route::post('admin/idProofType/manage_idProofType_process', [IdProofTypeController::class,'manage_idProofType_process'])->name('product.manage_idProofType_process');

////////////////////////////////////

        Route::get('admin/addressProofType', [AddressProofTypeController::class,'index']);
        Route::get('admin/addressProofType/edit_addressProofType', [AddressProofTypeController::class,'edit_addressProofType']);
        Route::get('admin/addressProofType/edit_addressProofType/{id}', [AddressProofTypeController::class,'edit_addressProofType']);
        Route::get('admin/addressProofType/delete/{id}', [AddressProofTypeController::class,'delete']);
        Route::get('admin/addressProofType/trash', [AddressProofTypeController::class,'trash']);
        Route::get('admin/addressProofType/forceDelete/{id}', [AddressProofTypeController::class,'forceDelete']);
        Route::get('admin/addressProofType/restore/{id}', [AddressProofTypeController::class,'restore']);

        Route::get('admin/addressProofType/status/{status}/{id}', [AddressProofTypeController::class,'status']);
        Route::post('admin/addressProofType/manage_addressProofType_process', [AddressProofTypeController::class,'manage_addressProofType_process'])->name('product.manage_addressProofType_process');
///////////////////////////////////////////////

        Route::get('admin/branchStock', [BranchStockController::class,'index']);
        Route::get('admin/branchStock/purchase', [BranchStockController::class,'purchase']); 
        Route::get('admin/branchStock/stockTransfer', [BranchStockController::class,'stockTransfer']);
        Route::post('admin/branchStock/manage_branchStock_process', [BranchStockController::class,'manage_branchStock_process'])->name('manage_branchStock_process');
        Route::post('admin/branchStock/manage_branchStock_transfer', [BranchStockController::class,'manage_branchStock_transfer'])->name('manage_branchStock_transfer');
////////////////////////////////////////////////

        Route::get('admin/branchStockDetails', [BranchStockDetailsController::class,'index']);
        Route::get('admin/emis/', [EMICollectionController
                ::class,'index']);
        Route::get('admin/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
        Route::post('admin/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('admin.manage_emi_collect');
        Route::get('admin/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
////////////////////////////////////////////////////////////
//Route::get('/csrf',[AjaxController::class,'csrf'])->name('csrf');

////////////////////////////
    Route::get('admin/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->flash('error','logout successfully');
            return redirect('admin');
    });
//Route::get('admin/category.insert', [CategoryController::class,'insert'])->name('category.insert');
    }
);
Route::get('admin', [AdminController::class,'index']);
Route::post('admin/auth', [AdminController::class,'auth'])->name('admin.auth');
//////////////////////
Route::post('admin/forgetPassword', [AdminController::class,'forgetPassword'])->name('admin.forget.password');
Route::get('admin/forget_password', function () {
    return view('admin.admin_forget_password');
});
Route::get('admin/changePassword/{id}', [AdminController::class,'reset']);

Route::get('admin/forget_password_success/{id}',[AdminController::class,'forget_password_success']);

Route::get('admin/ResetPassword/{id}', [AdminController::class,'admin_password_reset']);
Route::post('admin/ResetPassword/Set', [AdminController::class,'manage_password_reset'])->name('admin.admin_password_set');
        
Route::get('admin/password_change_success/{id}', [AdminController::class,'admin_password_change_success']);
////////////////////
Route::get('/clear', function () {
Artisan::call('optimize:clear');
Artisan::call('route:clear');
Artisan::call('cache:clear');
Artisan::call('config:cache');
Artisan::call('config:clear');
Artisan::call('view:clear');
Artisan::call('storage:link', [] );
Artisan::call('storage:link');
Artisan::call('view:clear');
//Artisan::call('clear:compiled');
    echo "clear";
});

    
Route::post('/getCustomerDetails',[AjaxController::class,'getCustomerDetails'])->name('getCustomerDetails');
Route::post('/getBookingDetails',[AjaxController::class,'getBookingDetails'])->name('getBookingDetails');
Route::post('/getSaleAgentDetails',[AjaxController::class,'getSaleAgentDetails'])->name('getSaleAgentDetails');
Route::post('/getProductDetails',[AjaxController::class,'getProductDetails'])->name('getProductDetails');

Route::post('/getBranchDetails',[AjaxController::class,'getBranchDetails'])->name('getBranchDetails');

Route::post('/getStockDetails',[AjaxController::class,'getStockDetails'])->name('getStockDetails');
Route::post('/getCheckMobileUnique',[AjaxController::class,'getCheckMobileUnique'])->name('getCheckMobileUnique');
Route::post('/setDefaultPasswordVA',[AjaxController::class,'setDefaultPasswordVA'])->name('setDefaultPasswordVA');
Route::post('/setDefaultPasswordSA',[AjaxController::class,'setDefaultPasswordSA'])->name('setDefaultPasswordSA');
Route::post('/getBillLastEMI',[AjaxController::class,'getBillLastEMI'])->name('getBillLastEMI');
Route::post('/calculate_emi_clear',[AjaxController::class,'calculate_emi_clear'])->name('calculate_emi_clear');
Route::post('/clearAllEMI',[AjaxController::class,'clearAllEMI'])->name('clearAllEMI');

Route::group(['middleware'=>'sale_agent_auth'],function()
{
////////////////////////////////////
        Route::get('sale_agent/dashboard', [SalesAgentController::class,'dashboard']);
        Route::get('sale_agent/customer', [CustomerController::class,'index']);
        Route::get('sale_agent/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('sale_agent/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('sale_agent/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('sale_agent/customer/trash', [CustomerController::class,'trash']);
        Route::get('sale_agent/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('sale_agent/customer/restore/{id}', [CustomerController::class,'restore']);
        /*
        Route::get('sale_agent/customer/status/{status}/{id}', [CustomerController::class,'status']);
        Route::get('sale_agent/customer/approve/{approve}/{id}', [CustomerController::class,'approve']);
        */
        Route::post('sale_agent/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('sale_agent.manage_customer_process');
        Route::get('sale_agent/village', [VillageController::class,'list']);
        Route::get('sale_agent/village/edit_village', [VillageController::class,'edit_village']);
        Route::get('sale_agent/village/edit_village/{id}', [VillageController::class,'edit_village']);
        Route::get('sale_agent/village/delete/{id}', [VillageController::class,'delete']);
        Route::get('sale_agent/village/trash', [VillageController::class,'trash']);
        Route::get('sale_agent/village/forceDelete/{id}', [VillageController::class,'forceDelete']);
        Route::get('sale_agent/village/restore/{id}', [VillageController::class,'restore']);

        Route::get('sale_agent/village/status/{status}/{id}', [VillageController::class,'status']);
        Route::post('sale_agent/village/manage_village_process', [VillageController::class,'manage_village_process'])->name('sale_agent.manage_village_process');
        
        Route::post('sale_agent/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('sale_agent.manage_order_process');

        Route::get('sale_agent/Sales_Billing_Details', [OrderController::class,'Sales_Billing_Details']);

        Route::get('sale_agent/order_success/{id}', [OrderController::class,'order_success']);
 
Route::get('sale_agent/product_list', [ProductController::class,'product_list']);
Route::get('sale_agent/order/place_order/{sale_agent_id?}/{product_id?}', [OrderController::class,'place_order']);
Route::get('sale_agent/orders/', [OrderController::class,'index']);
///////

Route::get('sale_agent/order/edit_order', [OrderController::class,'edit_order']);
Route::get('sale_agent/order/edit_order/{id}', [OrderController::class,'edit_order']);
Route::get('sale_agent/order/delete/{id}', [OrderController::class,'delete']);
Route::get('sale_agent/order/trash', [OrderController::class,'trash']);
Route::get('sale_agent/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
Route::get('sale_agent/order/restore/{id}', [OrderController::class,'restore']);
///////////

Route::get('sale_agent/bill/edit_bill', [BillController::class,'edit_bill']); 
Route::get('sale_agent/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
Route::get('sale_agent/bill/print_bill/{id}', [BillController::class,'print_bill']);
Route::get('sale_agent/bill/print_bill_to_pdf/{id}', [BillController::class,'print_bill_to_pdf']);
Route::get('sale_agent/bill/view_bill/{id}', [BillController::class,'view_bill']);
Route::get('sale_agent/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
Route::get('sale_agent/bill/delete/{id}', [BillController::class,'delete']);
Route::get('sale_agent/bill/trash', [BillController::class,'trash']);
Route::get('sale_agent/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
Route::get('sale_agent/bill/restore/{id}', [BillController::class,'restore']);
Route::get('sale_agent/bills/', [BillController::class,'index']);
 Route::post('sale_agent/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('sale_agent.manage_bill_process');
 Route::get('sale_agent/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
 Route::get('sale_agent/emis/', [EMICollectionController::class,'index']); 
 Route::get('sale_agent/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
 Route::post('sale_agent/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('sale_agent.manage_emi_collect');
 Route::post('sale_agent/emis/add_emi_collect_details', [EMICollectionController::class,'add_emi_collect_details'])->name('sale_agent.add_emi_collect_details');
 
 Route::get('sale_agent/emis/receive', [EMICollectionController::class,'receive']);
 Route::post('sale_agent/emis/manage_emi_receive', [EMICollectionController::class,'manage_emi_receive'])->name('sale_agent.manage_emi_receive');

 Route::get('sale_agent/emis/emi_submitted/{emi_id?}', [EMICollectionController::class,'emi_submitted']);
 Route::get('sale_agent/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
Route::get('copyDataToDetails', [EMICollectionController::class,'copyDataToDetails']);
 

/*
Route::get('sale_agent/EMI_calculator',[EMI_Calculation::class,'index'])->name('EMI_calculator');*/
////////////////////////////
    Route::get('sale_agent/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('sale_agent');
    });
//////////////////////////
});
Route::get('sale_agent', [SalesAgentController::class,'index']);
Route::post('sale_agent/forgetPassword', [SalesAgentController::class,'forgetPassword'])->name('sale_agent.forget.password');
Route::get('sale_agent/forget_password', function () {
    return view('admin.sale_agent_forget_password');
});
Route::get('sale_agent/changePassword/{id}', [SalesAgentController::class,'reset']);

Route::get('sale_agent/forget_password_success/{id}',[SalesAgentController::class,'forget_password_success']);

Route::get('sale_agent/ResetPassword/{id}', [SalesAgentController::class,'sale_agent_password_reset']);
Route::post('sale_agent/ResetPassword/Set', [SalesAgentController::class,'manage_password_reset'])->name('sale_agent.sale_agent_password_set');
        
Route::get('sale_agent/password_change_success/{id}', [SalesAgentController::class,'sale_agent_password_change_success']);

///////////////////

Route::group(['middleware'=>'village_agent_auth'],function()
{
////////////////////////////////////
        Route::get('village_agent/dashboard', [VillageController::class,'dashboard']);
        Route::get('village_agent/customer', [CustomerController::class,'index']);
        Route::get('village_agent/customer/edit_customer', [CustomerController::class,'edit_customer']);
        Route::get('village_agent/customer/edit_customer/{id}', [CustomerController::class,'edit_customer']);
        Route::get('village_agent/customer/delete/{id}', [CustomerController::class,'delete']);
        Route::get('village_agent/customer/trash', [CustomerController::class,'trash']);
        Route::get('village_agent/customer/forceDelete/{id}', [CustomerController::class,'forceDelete']);
        Route::get('village_agent/customer/restore/{id}', [CustomerController::class,'restore']);
        Route::post('village_agent/customer/manage_customer_process', [CustomerController::class,'manage_customer_process'])->name('village_agent.manage_customer_process');

        Route::post('village_agent/order/manage_order_process', [OrderController::class,'manage_order_process'])->name('village_agent.manage_order_process');

        Route::get('village_agent/Sales_Billing_Details', [OrderController::class,'Sales_Billing_Details']);

        Route::get('village_agent/order_success/{id}', [OrderController::class,'order_success']);
 
Route::get('village_agent/product_list', [ProductController::class,'product_list']);
Route::get('village_agent/order/place_order/{village_agent_id?}/{product_id?}', [OrderController::class,'place_order']);
Route::get('village_agent/orders/', [OrderController::class,'index']);
///////

Route::get('village_agent/order/place_order/{sale_agent_id?}/{product_id?}', [OrderController::class,'place_order']);

Route::get('village_agent/order/edit_order', [OrderController::class,'edit_order']);
Route::get('village_agent/order/edit_order/{id}', [OrderController::class,'edit_order']);
Route::get('village_agent/order/delete/{id}', [OrderController::class,'delete']);
Route::get('village_agent/order/trash', [OrderController::class,'trash']);
Route::get('village_agent/order/forceDelete/{id}', [OrderController::class,'forceDelete']);
Route::get('village_agent/order/restore/{id}', [OrderController::class,'restore']);
///////////

Route::get('village_agent/bill/edit_bill', [BillController::class,'edit_bill']);
Route::get('village_agent/bill/edit_bill/{id}', [BillController::class,'edit_bill']);
Route::get('village_agent/bill/print_bill/{id}', [BillController::class,'print_bill']);
Route::get('village_agent/bill/edit_bill/{id}/{order_id?}', [BillController::class,'edit_bill']);
Route::get('village_agent/bill/delete/{id}', [BillController::class,'delete']);
Route::get('village_agent/bill/trash', [BillController::class,'trash']);
Route::get('village_agent/bill/forceDelete/{id}', [BillController::class,'forceDelete']);
Route::get('village_agent/bill/restore/{id}', [BillController::class,'restore']);
Route::get('village_agent/bills/', [BillController::class,'index']);
 Route::post('village_agent/bill/manage_bill_process', [BillController::class,'manage_bill_process'])->name('village_agent.manage_bill_process');
 Route::get('village_agent/bill/final_submit/{final_submit}/{id}', [BillController::class,'final_submit']);
Route::get('village_agent/emis/', [EMICollectionController::class,'index']);
Route::get('village_agent/emis/emi_collection/{id?}', [EMICollectionController::class,'emi_collection']);
Route::post('village_agent/emis/manage_emi_collect', [EMICollectionController::class,'manage_emi_collect'])->name('village_agent.manage_emi_collect');
Route::post('village_agent/emis/add_emi_collect_details', [EMICollectionController::class,'add_emi_collect_details'])->name('village_agent.add_emi_collect_details');
 Route::get('village_agent/emis/emi_submitted/{emi_id?}', [EMICollectionController::class,'emi_submitted']);
 Route::get('village_agent/emis/print_emi/{id}', [EMICollectionController::class,'print_emi']);
/*
Route::get('village_agent/EMI_calculator',[EMI_Calculation::class,'index'])->name('EMI_calculator');
*/
////////////////////////////
    Route::get('village_agent/logout', function () {
            session()->forget('ADMIN_LOGIN');
            session()->forget('ADMIN_ID');
            session()->forget('ADMIN_TYPE');
            session()->forget('ADMIN_NAME');
            session()->forget('ADMIN_IMAGE');
            session()->forget('ADMIN_REFER_ID');
                        
            session()->flash('error','logout successfully');
            return redirect('village_agent');
    });
});

Route::get('village_agent', [VillageController::class,'index']);
Route::post('village_agent/forgetPassword', [VillageController::class,'forgetPassword'])->name('village_agent.forget.password');
Route::get('village_agent/forget_password', function () {
    return view('admin.village_agent_forget_password');
});
Route::get('village_agent/changePassword/{id}', [VillageController::class,'reset']);

Route::get('village_agent/forget_password_success/{id}',[VillageController::class,'forget_password_success']);

Route::get('village_agent/ResetPassword/{id}', [VillageController::class,'village_agent_password_reset']);
Route::post('village_agent/ResetPassword/Set', [VillageController::class,'manage_password_reset'])->name('village_agent.village_agent_password_set');
        
Route::get('village_agent/password_change_success/{id}', [VillageController::class,'village_agent_password_change_success']);

